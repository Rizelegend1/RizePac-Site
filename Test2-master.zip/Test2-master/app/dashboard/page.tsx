"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion } from "framer-motion"
import {
  Users,
  BarChart3,
  Settings,
  LogOut,
  ChevronRight,
  Search,
  Clock,
  Globe,
  Monitor,
  User,
  Copy,
  CheckCircle,
  RefreshCw,
  Edit2,
  Eye,
  EyeOff,
  ArrowUpDown,
  AlertCircle,
  ExternalLink,
  TrendingUp,
  Share2,
  Zap,
  MessageSquare,
  HelpCircle,
  Info,
  X,
} from "lucide-react"
import Link from "next/link"
import { PurpleParticleCanvas } from "@/components/purple-particle-canvas"
import { useRouter } from "next/navigation"

// Types
interface ClickData {
  id: string
  ip: string
  location: string
  device: string
  referrer: string
  timestamp: string
  userAgent?: string
}

interface ReferralData {
  id: string
  displayName: string
  timestamp: string
  clicks: number
}

interface LeaderboardEntry {
  id: string
  displayName: string
  clicks: number
  isAnonymous: boolean
}

export default function Dashboard() {
  const router = useRouter()
  const [webhookUrl, setWebhookUrl] = useState("")
  const [userId, setUserId] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [activeTab, setActiveTab] = useState("clicks")
  const [displayName, setDisplayName] = useState("")
  const [isAnonymous, setIsAnonymous] = useState(true)
  const [clickData, setClickData] = useState<ClickData[]>([])
  const [referrals, setReferrals] = useState<ReferralData[]>([])
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [totalClicks, setTotalClicks] = useState(0)
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("timestamp")
  const [sortDirection, setSortDirection] = useState("desc")
  const [copied, setCopied] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [isEditingName, setIsEditingName] = useState(false)
  const [gamepassLink, setGamepassLink] = useState("")
  const [isSubmittingGamepass, setIsSubmittingGamepass] = useState(false)
  const [gamepassSubmitted, setGamepassSubmitted] = useState(false)
  const [error, setError] = useState("")
  const containerRef = useRef<HTMLDivElement>(null)

  // Check for authentication on load
  useEffect(() => {
    const storedWebhook = localStorage.getItem("dashboard_webhook")
    const storedUserId = localStorage.getItem("dashboard_userId")

    if (storedWebhook && storedUserId) {
      setWebhookUrl(storedWebhook)
      setUserId(storedUserId)
      verifyWebhook(storedWebhook, storedUserId)
    } else {
      setIsLoading(false)
    }
  }, [])

  // Verify webhook
  const verifyWebhook = async (webhook: string, id: string) => {
    setIsLoading(true)
    try {
      // In a real app, this would verify with the server
      // For now, we'll simulate a successful verification
      // In production, this would be an actual API call

      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 800))

      // Get stored data from localStorage
      const clickCount = localStorage.getItem(`clickCount_${id}`) || "0"
      const storedGamepass = localStorage.getItem(`gamepass_${id}`)

      setIsAuthenticated(true)
      setDisplayName(`User-${id}`)
      setIsAnonymous(true)
      setGamepassSubmitted(!!storedGamepass)
      setGamepassLink(storedGamepass || "")
      setTotalClicks(Number.parseInt(clickCount, 10))

      // Load dashboard data
      loadDashboardData(webhook, id)
    } catch (error) {
      console.error("Error verifying webhook:", error)
      setIsAuthenticated(false)
      setIsLoading(false)
      localStorage.removeItem("dashboard_webhook")
      localStorage.removeItem("dashboard_userId")
    }
  }

  // Handle login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!webhookUrl || !userId) {
      setError("Please enter both your webhook URL and link ID")
      return
    }

    await verifyWebhook(webhookUrl, userId)

    if (isAuthenticated) {
      localStorage.setItem("dashboard_webhook", webhookUrl)
      localStorage.setItem("dashboard_userId", userId)
    }
  }

  // Load dashboard data
  const loadDashboardData = async (webhook: string, id: string) => {
    try {
      // Get click data from localStorage or create realistic data
      // In a real app, this would be an API call
      const clickCount = Number.parseInt(localStorage.getItem(`clickCount_${id}`) || "0", 10)
      setTotalClicks(clickCount)

      // Generate realistic click data based on the click count
      const clicks = generateRealisticClickData(clickCount, id)
      setClickData(clicks)

      // Get referrals - in a real app this would be from an API
      // For now, we'll create some realistic referral data
      const referrals = generateRealisticReferrals(id)
      setReferrals(referrals)

      // Get leaderboard - in a real app this would be from an API
      const leaderboard = await fetchLeaderboard(id)
      setLeaderboard(leaderboard)

      setIsLoading(false)
    } catch (error) {
      console.error("Error loading dashboard data:", error)
      setIsLoading(false)
    }
  }

  // Generate realistic click data
  const generateRealisticClickData = (count: number, userId: string): ClickData[] => {
    const clicks: ClickData[] = []
    const now = new Date()

    // If we have no clicks, return empty array
    if (count === 0) return []

    // Create a distribution of clicks over the past few days
    // More recent days have more clicks
    const dayDistribution = [0.5, 0.3, 0.15, 0.05] // 50% today, 30% yesterday, etc.

    for (let i = 0; i < count; i++) {
      // Determine which day this click happened
      const dayIndex = weightedRandomIndex(dayDistribution)
      const clickDate = new Date(now)
      clickDate.setDate(clickDate.getDate() - dayIndex)

      // Random time within that day
      clickDate.setHours(Math.floor(Math.random() * 24))
      clickDate.setMinutes(Math.floor(Math.random() * 60))
      clickDate.setSeconds(Math.floor(Math.random() * 60))

      // Generate a realistic IP address
      const ip = `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`

      // Generate realistic location
      const locations = [
        "United States",
        "United Kingdom",
        "Canada",
        "Germany",
        "France",
        "Australia",
        "Japan",
        "Brazil",
        "India",
        "Netherlands",
      ]
      const location = locations[Math.floor(Math.random() * locations.length)]

      // Generate realistic device
      const devices = ["Windows PC", "Mac", "iPhone", "Android Device", "iPad", "Linux"]
      const device = devices[Math.floor(Math.random() * devices.length)]

      // Generate realistic referrer
      const referrers = [
        "Direct",
        "Discord",
        "Twitter",
        "Instagram",
        "TikTok",
        "YouTube",
        "Facebook",
        "Reddit",
        "Google",
        "Bing",
      ]
      const referrer = referrers[Math.floor(Math.random() * referrers.length)]

      clicks.push({
        id: `click-${i}-${userId}`,
        ip,
        location,
        device,
        referrer,
        timestamp: clickDate.toISOString(),
      })
    }

    // Sort by timestamp, newest first
    return clicks.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
  }

  // Helper function for weighted random selection
  const weightedRandomIndex = (weights: number[]): number => {
    const totalWeight = weights.reduce((sum, weight) => sum + weight, 0)
    let random = Math.random() * totalWeight

    for (let i = 0; i < weights.length; i++) {
      random -= weights[i]
      if (random <= 0) return i
    }

    return weights.length - 1
  }

  // Generate realistic referrals
  const generateRealisticReferrals = (userId: string): ReferralData[] => {
    // For demo purposes, generate 0-3 referrals
    const referralCount = Math.floor(Math.random() * 4)
    const referrals: ReferralData[] = []
    const now = new Date()

    for (let i = 0; i < referralCount; i++) {
      // Generate a random timestamp within the last 14 days
      const timestamp = new Date(now)
      timestamp.setDate(timestamp.getDate() - Math.floor(Math.random() * 14))

      // Generate a random ID
      const adjectives = ["cool", "epic", "mega", "super", "hyper", "ultra", "pro", "elite", "royal", "swift"]
      const nouns = ["gamer", "ninja", "wizard", "master", "legend", "beast", "hawk", "tiger", "dragon", "wolf"]
      const randomAdjective = adjectives[Math.floor(Math.random() * adjectives.length)]
      const randomNoun = nouns[Math.floor(Math.random() * nouns.length)]
      const randomNum = Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")
      const id = `${randomAdjective}-${randomNoun}-${randomNum}`

      // Generate display name
      const displayName = `${randomAdjective.charAt(0).toUpperCase() + randomAdjective.slice(1)}${randomNoun.charAt(0).toUpperCase() + randomNoun.slice(1)}`

      // Generate random click count (1-30)
      const clicks = Math.floor(Math.random() * 30) + 1

      referrals.push({
        id,
        displayName,
        timestamp: timestamp.toISOString(),
        clicks,
      })
    }

    // Sort by timestamp, newest first
    return referrals.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
  }

  // Fetch leaderboard data
  const fetchLeaderboard = async (currentUserId: string): Promise<LeaderboardEntry[]> => {
    // In a real app, this would be an API call
    // For now, we'll create a realistic leaderboard with the current user included

    const leaderboard: LeaderboardEntry[] = []

    // Add 15-20 random entries
    const entryCount = Math.floor(Math.random() * 6) + 15

    // Create a list of realistic usernames
    const usernames = [
      "ClickMaster",
      "LinkLegend",
      "RobuxKing",
      "ClickGod",
      "LinkNinja",
      "MoneyMaker",
      "RobuxHunter",
      "ClickPro",
      "LinkWizard",
      "RobuxChamp",
      "ClickBeast",
      "LinkMaster",
      "RobuxLord",
      "ClickNinja",
      "LinkGod",
      "MoneyNinja",
      "RobuxWizard",
      "ClickChamp",
      "LinkPro",
      "RobuxMaster",
    ]

    // Shuffle the usernames
    const shuffledUsernames = [...usernames].sort(() => Math.random() - 0.5)

    // Generate entries
    for (let i = 0; i < entryCount; i++) {
      // Generate a random ID
      const adjectives = ["cool", "epic", "mega", "super", "hyper", "ultra", "pro", "elite", "royal", "swift"]
      const nouns = ["gamer", "ninja", "wizard", "master", "legend", "beast", "hawk", "tiger", "dragon", "wolf"]
      const randomAdjective = adjectives[Math.floor(Math.random() * adjectives.length)]
      const randomNoun = nouns[Math.floor(Math.random() * nouns.length)]
      const randomNum = Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")
      const id = `${randomAdjective}-${randomNoun}-${randomNum}`

      // Use a username from our list
      const displayName = shuffledUsernames[i % shuffledUsernames.length]

      // Generate random click count (50-200)
      // Top entries have more clicks
      const baseClicks = 200 - i * 10
      const variation = Math.floor(Math.random() * 20) - 10
      const clicks = Math.max(50, baseClicks + variation)

      // Random anonymity status
      const isAnonymous = Math.random() > 0.7

      leaderboard.push({
        id,
        displayName,
        clicks,
        isAnonymous,
      })
    }

    // Add the current user with their actual click count
    const currentUserClickCount = Number.parseInt(localStorage.getItem(`clickCount_${currentUserId}`) || "0", 10)

    // Find the right position for the current user based on click count
    let userAdded = false
    for (let i = 0; i < leaderboard.length; i++) {
      if (currentUserClickCount > leaderboard[i].clicks) {
        leaderboard.splice(i, 0, {
          id: currentUserId,
          displayName: `User-${currentUserId}`,
          clicks: currentUserClickCount,
          isAnonymous: true,
        })
        userAdded = true
        break
      }
    }

    // If the user has fewer clicks than everyone, add them at the end
    if (!userAdded) {
      leaderboard.push({
        id: currentUserId,
        displayName: `User-${currentUserId}`,
        clicks: currentUserClickCount,
        isAnonymous: true,
      })
    }

    // Sort by clicks, highest first
    return leaderboard.sort((a, b) => b.clicks - a.clicks)
  }

  // Handle refresh
  const handleRefresh = async () => {
    if (isRefreshing) return

    setIsRefreshing(true)
    await loadDashboardData(webhookUrl, userId)
    setIsRefreshing(false)
  }

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem("dashboard_webhook")
    localStorage.removeItem("dashboard_userId")
    setIsAuthenticated(false)
    setWebhookUrl("")
    setUserId("")
  }

  // Handle name update
  const handleNameUpdate = async () => {
    try {
      // In a real app, this would update on the server
      // For now, we'll just update the local state
      setIsEditingName(false)

      // Update the user's entry in the leaderboard
      const updatedLeaderboard = leaderboard.map((entry) => {
        if (entry.id === userId) {
          return {
            ...entry,
            displayName: displayName || `User-${userId}`,
            isAnonymous,
          }
        }
        return entry
      })

      setLeaderboard(updatedLeaderboard)
    } catch (error) {
      console.error("Error updating profile:", error)
    }
  }

  // Handle gamepass submission
  const handleGamepassSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!gamepassLink) {
      setError("Please enter your Roblox gamepass link")
      return
    }

    if (!gamepassLink.includes("roblox.com/game-pass/") && !gamepassLink.includes("roblox.com/catalog/")) {
      setError("Please enter a valid Roblox gamepass link")
      return
    }

    setIsSubmittingGamepass(true)

    try {
      // In a real app, this would be an API call
      // For now, we'll just update localStorage
      localStorage.setItem(`gamepass_${userId}`, gamepassLink)

      // Simulate API delay
      await new Promise((resolve) => setTimeout(resolve, 800))

      setGamepassSubmitted(true)
      setError("")
    } catch (error) {
      console.error("Error submitting gamepass:", error)
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmittingGamepass(false)
    }
  }

  // Copy link to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Filter and sort click data
  const filteredClicks = clickData
    .filter((click) => {
      if (!searchTerm) return true
      return (
        click.ip.includes(searchTerm) ||
        click.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        click.device.toLowerCase().includes(searchTerm.toLowerCase()) ||
        click.referrer.toLowerCase().includes(searchTerm.toLowerCase())
      )
    })
    .sort((a, b) => {
      if (sortBy === "timestamp") {
        return sortDirection === "asc"
          ? new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
          : new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
      }
      if (sortBy === "location") {
        return sortDirection === "asc" ? a.location.localeCompare(b.location) : b.location.localeCompare(a.location)
      }
      if (sortBy === "device") {
        return sortDirection === "asc" ? a.device.localeCompare(b.device) : b.device.localeCompare(a.device)
      }
      return 0
    })

  // Toggle sort
  const toggleSort = (column: string) => {
    if (sortBy === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortBy(column)
      setSortDirection("asc")
    }
  }

  // Mobile optimization styles
  useEffect(() => {
    // Set viewport height for mobile browsers
    const setVh = () => {
      const vh = window.innerHeight * 0.01
      document.documentElement.style.setProperty("--vh", `${vh}px`)
    }

    // Call the function on initial load
    setVh()

    // Add event listener for resize
    window.addEventListener("resize", setVh)

    // Clean up
    return () => window.removeEventListener("resize", setVh)
  }, [])

  // Login screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen w-full bg-black overflow-hidden">
        <div className="fixed inset-0 z-0">
          <PurpleParticleCanvas />
        </div>
        <div
          className="min-h-screen w-full flex flex-col items-center justify-center p-4 relative z-10"
          style={{ minHeight: "calc(var(--vh, 1vh) * 100)" }}
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-md"
          >
            <div className="bg-black/80 backdrop-blur-md border border-purple-500/30 rounded-lg shadow-xl overflow-hidden">
              <div className="p-6 border-b border-purple-500/20 bg-gradient-to-r from-purple-900/30 to-black">
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <BarChart3 className="text-purple-400 w-6 h-6" />
                  Dashboard Login
                </h1>
                <p className="text-gray-300 mt-2 text-sm">Access your link statistics and manage your account.</p>
              </div>

              <div className="p-6">
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center min-h-[200px]">
                    <RefreshCw className="w-10 h-10 text-purple-500 animate-spin mb-4" />
                    <p className="text-gray-400">Verifying credentials...</p>
                  </div>
                ) : (
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div>
                      <label htmlFor="webhook" className="block text-sm font-medium text-gray-300 mb-1">
                        Your Discord Webhook URL
                      </label>
                      <input
                        type="text"
                        id="webhook"
                        value={webhookUrl}
                        onChange={(e) => setWebhookUrl(e.target.value)}
                        placeholder="https://discord.com/api/webhooks/..."
                        className="w-full px-4 py-2 bg-black/60 border border-purple-500/30 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                        required
                        autoComplete="off"
                        autoCapitalize="off"
                        spellCheck="false"
                      />
                    </div>

                    <div>
                      <label htmlFor="userId" className="block text-sm font-medium text-gray-300 mb-1">
                        Your Link ID
                      </label>
                      <input
                        type="text"
                        id="userId"
                        value={userId}
                        onChange={(e) => setUserId(e.target.value)}
                        placeholder="your-link-id"
                        className="w-full px-4 py-2 bg-black/60 border border-purple-500/30 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                        required
                        autoComplete="off"
                        autoCapitalize="off"
                        spellCheck="false"
                      />
                      <p className="mt-1 text-xs text-gray-400">
                        This is the unique identifier from your link (e.g., cool-ninja-123)
                      </p>
                    </div>

                    {error && (
                      <div className="bg-red-900/20 border border-red-500/30 rounded-md p-3 flex items-start gap-2">
                        <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-red-300">{error}</p>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white py-2 px-4 rounded-md font-medium flex items-center justify-center gap-2 transition-colors"
                    >
                      Login to Dashboard
                    </button>

                    <div className="text-center">
                      <Link
                        href="/make-money"
                        className="text-purple-400 hover:text-purple-300 text-sm transition-colors"
                      >
                        Don't have a link? Generate one here
                      </Link>
                    </div>
                  </form>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    )
  }

  // Dashboard
  return (
    <div className="min-h-screen w-full bg-black overflow-hidden">
      <div className="fixed inset-0 z-0">
        <PurpleParticleCanvas />
      </div>

      <div className="relative z-10 flex h-screen" style={{ height: "calc(var(--vh, 1vh) * 100)" }}>
        {/* Sidebar - always visible on desktop, collapsible on mobile */}
        <div className="w-64 h-full bg-black/90 backdrop-blur-md border-r border-purple-500/20 z-40 hidden md:block">
          <div className="p-4 border-b border-purple-500/20 bg-gradient-to-r from-purple-900/30 to-black/50">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <BarChart3 className="text-purple-400 w-5 h-5" />
              Dashboard
            </h2>
            <p className="text-xs text-gray-400 mt-1">Manage your link and track clicks</p>
          </div>

          <div className="p-4">
            <div className="mb-6">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Your Link</p>
              <div className="bg-black/60 border border-purple-500/30 rounded-md p-2 flex items-center justify-between">
                <span className="text-sm text-gray-300 truncate">shockify.lol/{userId}</span>
                <button
                  onClick={() => copyToClipboard(`https://shockify.lol/${userId}`)}
                  className="text-purple-400 hover:text-purple-300 transition-colors"
                  title="Copy to clipboard"
                >
                  {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <div className="mt-2 bg-purple-900/20 rounded-md p-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-400">Total Clicks:</span>
                  <span className="text-sm font-medium text-white">{totalClicks}/100</span>
                </div>
                <div className="w-full bg-purple-900/30 rounded-full h-1.5 mt-1">
                  <div
                    className="bg-purple-500 h-1.5 rounded-full"
                    style={{ width: `${Math.min((totalClicks / 100) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>

            <nav className="space-y-1">
              <button
                onClick={() => setActiveTab("clicks")}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
                  activeTab === "clicks"
                    ? "bg-purple-900/50 text-white"
                    : "text-gray-400 hover:bg-purple-900/20 hover:text-gray-200"
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Click Analytics</span>
                {activeTab !== "clicks" && <ChevronRight className="w-4 h-4 ml-auto" />}
              </button>

              <button
                onClick={() => setActiveTab("referrals")}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
                  activeTab === "referrals"
                    ? "bg-purple-900/50 text-white"
                    : "text-gray-400 hover:bg-purple-900/20 hover:text-gray-200"
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Referrals</span>
                {activeTab !== "referrals" && <ChevronRight className="w-4 h-4 ml-auto" />}
              </button>

              <button
                onClick={() => setActiveTab("leaderboard")}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
                  activeTab === "leaderboard"
                    ? "bg-purple-900/50 text-white"
                    : "text-gray-400 hover:bg-purple-900/20 hover:text-gray-200"
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span>Leaderboard</span>
                {activeTab !== "leaderboard" && <ChevronRight className="w-4 h-4 ml-auto" />}
              </button>

              <button
                onClick={() => setActiveTab("tips")}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
                  activeTab === "tips"
                    ? "bg-purple-900/50 text-white"
                    : "text-gray-400 hover:bg-purple-900/20 hover:text-gray-200"
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>Tips & Tricks</span>
                {activeTab !== "tips" && <ChevronRight className="w-4 h-4 ml-auto" />}
              </button>

              <button
                onClick={() => setActiveTab("settings")}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
                  activeTab === "settings"
                    ? "bg-purple-900/50 text-white"
                    : "text-gray-400 hover:bg-purple-900/20 hover:text-gray-200"
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Settings</span>
                {activeTab !== "settings" && <ChevronRight className="w-4 h-4 ml-auto" />}
              </button>
            </nav>
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-purple-500/20">
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-2 px-3 py-2 text-gray-400 hover:text-gray-200 hover:bg-purple-900/20 rounded-md transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        {/* Mobile sidebar - fixed position, always visible */}
        <div className="fixed bottom-0 left-0 right-0 bg-black/90 border-t border-purple-500/20 z-50 md:hidden">
          <div className="flex justify-around items-center">
            <button
              onClick={() => setActiveTab("clicks")}
              className={`flex flex-col items-center justify-center py-3 px-4 ${
                activeTab === "clicks" ? "text-purple-400" : "text-gray-400"
              }`}
            >
              <Users className="w-5 h-5" />
              <span className="text-xs mt-1">Clicks</span>
            </button>
            <button
              onClick={() => setActiveTab("referrals")}
              className={`flex flex-col items-center justify-center py-3 px-4 ${
                activeTab === "referrals" ? "text-purple-400" : "text-gray-400"
              }`}
            >
              <Share2 className="w-5 h-5" />
              <span className="text-xs mt-1">Referrals</span>
            </button>
            <button
              onClick={() => setActiveTab("leaderboard")}
              className={`flex flex-col items-center justify-center py-3 px-4 ${
                activeTab === "leaderboard" ? "text-purple-400" : "text-gray-400"
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span className="text-xs mt-1">Ranks</span>
            </button>
            <button
              onClick={() => setActiveTab("tips")}
              className={`flex flex-col items-center justify-center py-3 px-4 ${
                activeTab === "tips" ? "text-purple-400" : "text-gray-400"
              }`}
            >
              <Zap className="w-5 h-5" />
              <span className="text-xs mt-1">Tips</span>
            </button>
            <button
              onClick={() => setActiveTab("settings")}
              className={`flex flex-col items-center justify-center py-3 px-4 ${
                activeTab === "settings" ? "text-purple-400" : "text-gray-400"
              }`}
            >
              <Settings className="w-5 h-5" />
              <span className="text-xs mt-1">Settings</span>
            </button>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-hidden flex flex-col pb-16 md:pb-0">
          {/* Header */}
          <header className="bg-black/70 backdrop-blur-md border-b border-purple-500/20 p-4 flex items-center justify-between">
            <h1 className="text-xl font-bold text-white">
              {activeTab === "clicks" && "Click Analytics"}
              {activeTab === "referrals" && "Referrals"}
              {activeTab === "leaderboard" && "Leaderboard"}
              {activeTab === "tips" && "Tips & Tricks"}
              {activeTab === "settings" && "Settings"}
            </h1>

            <div className="flex items-center gap-2">
              <button
                onClick={handleRefresh}
                className="bg-purple-900/50 hover:bg-purple-900/70 text-white p-2 rounded-md transition-colors"
                title="Refresh data"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
              </button>

              <div className="bg-purple-900/50 px-3 py-1 rounded-md flex items-center gap-2">
                <User className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-white">{isAnonymous ? "Anonymous" : displayName}</span>
              </div>
            </div>
          </header>

          {/* Content area */}
          <div className="flex-1 overflow-auto p-4">
            {/* Click Analytics */}
            {activeTab === "clicks" && (
              <div className="space-y-4">
                <div className="bg-black/70 backdrop-blur-md border border-purple-500/30 rounded-lg p-4">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                    <h2 className="text-lg font-medium text-white">Click Analytics</h2>

                    <div className="flex flex-col sm:flex-row gap-2">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 w-4 h-4" />
                        <input
                          type="text"
                          placeholder="Search clicks..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-9 pr-4 py-1.5 bg-black/60 border border-purple-500/30 rounded-md text-white text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50 w-full"
                        />
                      </div>

                      <button
                        onClick={handleRefresh}
                        className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1.5 rounded-md text-sm flex items-center gap-1 transition-colors"
                      >
                        <RefreshCw className={`w-4 h-4 ${isRefreshing ? "animate-spin" : ""}`} />
                        Refresh
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-purple-500/20">
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">
                            <button
                              onClick={() => toggleSort("timestamp")}
                              className="flex items-center gap-1 hover:text-white transition-colors"
                            >
                              Time
                              <ArrowUpDown className="w-3 h-3" />
                            </button>
                          </th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">IP</th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">
                            <button
                              onClick={() => toggleSort("location")}
                              className="flex items-center gap-1 hover:text-white transition-colors"
                            >
                              Location
                              <ArrowUpDown className="w-3 h-3" />
                            </button>
                          </th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">
                            <button
                              onClick={() => toggleSort("device")}
                              className="flex items-center gap-1 hover:text-white transition-colors"
                            >
                              Device
                              <ArrowUpDown className="w-3 h-3" />
                            </button>
                          </th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">Referrer</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredClicks.length > 0 ? (
                          filteredClicks.map((click, index) => (
                            <tr
                              key={index}
                              className="border-b border-purple-500/10 hover:bg-purple-900/10 transition-colors"
                            >
                              <td className="px-4 py-2 text-sm text-gray-300 whitespace-nowrap">
                                <div className="flex items-center gap-1">
                                  <Clock className="w-3 h-3 text-purple-400" />
                                  {new Date(click.timestamp).toLocaleString()}
                                </div>
                              </td>
                              <td className="px-4 py-2 text-sm text-gray-300 font-mono">{click.ip}</td>
                              <td className="px-4 py-2 text-sm text-gray-300">
                                <div className="flex items-center gap-1">
                                  <Globe className="w-3 h-3 text-purple-400" />
                                  {click.location}
                                </div>
                              </td>
                              <td className="px-4 py-2 text-sm text-gray-300">
                                <div className="flex items-center gap-1">
                                  <Monitor className="w-3 h-3 text-purple-400" />
                                  {click.device}
                                </div>
                              </td>
                              <td className="px-4 py-2 text-sm text-gray-300 truncate max-w-[200px]">
                                {click.referrer}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={5} className="px-4 py-8 text-center text-gray-400">
                              {searchTerm
                                ? "No clicks match your search criteria"
                                : "No clicks recorded yet. Share your link to start tracking!"}
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  <div className="mt-4 text-center text-sm text-gray-400">
                    Showing {filteredClicks.length} of {clickData.length} clicks
                  </div>
                </div>

                {/* Progress card */}
                <div className="bg-black/70 backdrop-blur-md border border-purple-500/30 rounded-lg p-4">
                  <h2 className="text-lg font-medium text-white mb-3">Progress Tracker</h2>
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1 bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-400">Clicks Progress</span>
                        <span className="text-white font-medium">{totalClicks}/100</span>
                      </div>
                      <div className="w-full bg-purple-900/30 rounded-full h-2">
                        <div
                          className="bg-purple-500 h-2 rounded-full"
                          style={{ width: `${Math.min((totalClicks / 100) * 100, 100)}%` }}
                        ></div>
                      </div>
                      <p className="mt-2 text-xs text-gray-400">
                        {totalClicks >= 100
                          ? "Congratulations! You've reached your goal!"
                          : `${100 - totalClicks} more clicks needed to reach your goal`}
                      </p>
                    </div>

                    <div className="flex-1 bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-400">Estimated Earnings</span>
                        <span className="text-white font-medium">{Math.floor((totalClicks / 100) * 15000)} Robux</span>
                      </div>
                      <div className="w-full bg-purple-900/30 rounded-full h-2">
                        <div
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${Math.min((totalClicks / 100) * 100, 100)}%` }}
                        ></div>
                      </div>
                      <p className="mt-2 text-xs text-gray-400">Earn 15,000 Robux when you reach 100 clicks</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Referrals */}
            {activeTab === "referrals" && (
              <div className="space-y-4">
                <div className="bg-black/70 backdrop-blur-md border border-purple-500/30 rounded-lg p-4">
                  <h2 className="text-lg font-medium text-white mb-4">Your Referrals</h2>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-purple-500/20">
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">User</th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">Date Joined</th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">Their Clicks</th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">Your Benefit</th>
                        </tr>
                      </thead>
                      <tbody>
                        {referrals.length > 0 ? (
                          referrals.map((referral, index) => (
                            <tr
                              key={index}
                              className="border-b border-purple-500/10 hover:bg-purple-900/10 transition-colors"
                            >
                              <td className="px-4 py-2 text-sm text-gray-300">{referral.displayName}</td>
                              <td className="px-4 py-2 text-sm text-gray-300">
                                {new Date(referral.timestamp).toLocaleDateString()}
                              </td>
                              <td className="px-4 py-2 text-sm text-gray-300">{referral.clicks}</td>
                              <td className="px-4 py-2 text-sm text-green-400">+{referral.clicks} clicks</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={4} className="px-4 py-8 text-center text-gray-400">
                              No referrals yet. Share your referral link to earn bonus clicks!
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="bg-black/70 backdrop-blur-md border border-purple-500/30 rounded-lg p-4">
                  <h2 className="text-lg font-medium text-white mb-3">Your Referral Link</h2>
                  <p className="text-sm text-gray-300 mb-3">
                    Share this link to earn double profits! Every click on your referrals' links counts for you too!
                  </p>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={`https://shockify.lol/make-money?ref=${userId}`}
                      readOnly
                      className="w-full px-3 py-2 bg-black/60 border border-purple-500/30 rounded-md text-white text-sm focus:outline-none"
                    />
                    <button
                      onClick={() => copyToClipboard(`https://shockify.lol/make-money?ref=${userId}`)}
                      className="bg-purple-600 hover:bg-purple-700 text-white p-2 rounded-md flex-shrink-0 transition-colors"
                      title="Copy to clipboard"
                    >
                      {copied ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Leaderboard */}
            {activeTab === "leaderboard" && (
              <div className="space-y-4">
                <div className="bg-black/70 backdrop-blur-md border border-purple-500/30 rounded-lg p-4">
                  <h2 className="text-lg font-medium text-white mb-4">Global Leaderboard</h2>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-purple-500/20">
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">Rank</th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">User</th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">Clicks</th>
                          <th className="px-4 py-2 text-xs font-medium text-gray-400">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {leaderboard.map((entry, index) => (
                          <tr
                            key={index}
                            className={`border-b border-purple-500/10 hover:bg-purple-900/10 transition-colors ${
                              entry.id === userId ? "bg-purple-900/20" : ""
                            }`}
                          >
                            <td className="px-4 py-2 text-sm">
                              <span
                                className={`font-bold ${
                                  index === 0
                                    ? "text-yellow-400"
                                    : index === 1
                                      ? "text-gray-300"
                                      : index === 2
                                        ? "text-amber-600"
                                        : "text-gray-400"
                                }`}
                              >
                                #{index + 1}
                              </span>
                            </td>
                            <td className="px-4 py-2 text-sm text-gray-300">
                              {entry.isAnonymous ? "Anonymous User" : entry.displayName}
                              {entry.id === userId && (
                                <span className="ml-2 text-xs bg-purple-900/50 text-purple-300 px-1.5 py-0.5 rounded">
                                  You
                                </span>
                              )}
                            </td>
                            <td className="px-4 py-2 text-sm text-gray-300">{entry.clicks}</td>
                            <td className="px-4 py-2 text-sm">
                              {entry.clicks >= 100 ? (
                                <span className="text-green-400 flex items-center gap-1">
                                  <CheckCircle className="w-3 h-3" /> Completed
                                </span>
                              ) : (
                                <span className="text-yellow-400 flex items-center gap-1">
                                  <RefreshCw className="w-3 h-3" /> In Progress
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Tips & Tricks */}
            {activeTab === "tips" && (
              <div className="space-y-4">
                <div className="bg-black/70 backdrop-blur-md border border-purple-500/30 rounded-lg p-4">
                  <h2 className="text-lg font-medium text-white mb-4">Tips & Tricks to Get More Clicks</h2>

                  <div className="space-y-4">
                    <div className="bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-purple-800/50 p-2 rounded-full">
                          <Share2 className="w-5 h-5 text-purple-300" />
                        </div>
                        <div>
                          <h3 className="text-white font-medium mb-1">Share on Social Media</h3>
                          <p className="text-sm text-gray-300">
                            Post your link on Discord, Twitter, Instagram, TikTok, and other social media platforms. The
                            more places you share, the more clicks you'll get!
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-purple-800/50 p-2 rounded-full">
                          <MessageSquare className="w-5 h-5 text-purple-300" />
                        </div>
                        <div>
                          <h3 className="text-white font-medium mb-1">Use Engaging Messages</h3>
                          <p className="text-sm text-gray-300">
                            When sharing your link, use attention-grabbing messages like "Free Robux giveaway!" or
                            "Limited-time Robux event!" to increase click-through rates.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-purple-800/50 p-2 rounded-full">
                          <Users className="w-5 h-5 text-purple-300" />
                        </div>
                        <div>
                          <h3 className="text-white font-medium mb-1">Leverage the Referral System</h3>
                          <p className="text-sm text-gray-300">
                            Share your referral link with friends who also want to earn Robux. Every click they get
                            counts for you too, doubling your earnings!
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-purple-800/50 p-2 rounded-full">
                          <TrendingUp className="w-5 h-5 text-purple-300" />
                        </div>
                        <div>
                          <h3 className="text-white font-medium mb-1">Target Popular Communities</h3>
                          <p className="text-sm text-gray-300">
                            Share your link in Roblox-related Discord servers, forums, and groups where people are
                            actively looking for Robux opportunities.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-purple-800/50 p-2 rounded-full">
                          <ExternalLink className="w-5 h-5 text-purple-300" />
                        </div>
                        <div>
                          <h3 className="text-white font-medium mb-1">Create Shortened Links</h3>
                          <p className="text-sm text-gray-300">
                            Use URL shorteners like bit.ly or TinyURL to make your link look cleaner and more
                            trustworthy when sharing.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-purple-800/50 p-2 rounded-full">
                          <HelpCircle className="w-5 h-5 text-purple-300" />
                        </div>
                        <div>
                          <h3 className="text-white font-medium mb-1">Offer Help & Support</h3>
                          <p className="text-sm text-gray-300">
                            Tell people you can help them with Roblox-related questions or issues if they click your
                            link. Being helpful increases trust and click rates.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-900/20 rounded-lg p-4">
                      <div className="flex items-start gap-3">
                        <div className="bg-purple-800/50 p-2 rounded-full">
                          <Info className="w-5 h-5 text-purple-300" />
                        </div>
                        <div>
                          <h3 className="text-white font-medium mb-1">Important Note</h3>
                          <p className="text-sm text-gray-300">
                            Remember to check your dashboard regularly to track your progress. Once you reach 100
                            clicks, your gamepass will be automatically purchased!
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Settings */}
            {activeTab === "settings" && (
              <div className="space-y-4">
                <div className="bg-black/70 backdrop-blur-md border border-purple-500/30 rounded-lg p-4">
                  <h2 className="text-lg font-medium text-white mb-4">Profile Settings</h2>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">Display Name</label>
                      {isEditingName ? (
                        <div className="flex items-center gap-2">
                          <input
                            type="text"
                            value={displayName}
                            onChange={(e) => setDisplayName(e.target.value)}
                            className="px-3 py-2 bg-black/60 border border-purple-500/30 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                            placeholder="Enter display name"
                          />
                          <button
                            onClick={handleNameUpdate}
                            className="bg-purple-600 hover:bg-purple-700 text-white p-2 rounded-md transition-colors"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setIsEditingName(false)}
                            className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-md transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center justify-between">
                          <div className="px-3 py-2 bg-black/60 border border-purple-500/30 rounded-md text-white text-sm w-full">
                            {displayName || "Not set"}
                          </div>
                          <button
                            onClick={() => setIsEditingName(true)}
                            className="ml-2 bg-purple-900/50 hover:bg-purple-900/70 text-white p-2 rounded-md transition-colors"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">Leaderboard Privacy</label>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setIsAnonymous(false)}
                          className={`px-3 py-2 rounded-md text-sm flex items-center gap-1 transition-colors ${
                            !isAnonymous
                              ? "bg-purple-600 text-white"
                              : "bg-black/60 border border-purple-500/30 text-gray-400 hover:text-white"
                          }`}
                        >
                          <Eye className="w-4 h-4" />
                          Public
                        </button>
                        <button
                          onClick={() => setIsAnonymous(true)}
                          className={`px-3 py-2 rounded-md text-sm flex items-center gap-1 transition-colors ${
                            isAnonymous
                              ? "bg-purple-600 text-white"
                              : "bg-black/60 border border-purple-500/30 text-gray-400 hover:text-white"
                          }`}
                        >
                          <EyeOff className="w-4 h-4" />
                          Anonymous
                        </button>
                      </div>
                      <p className="mt-1 text-xs text-gray-400">
                        {isAnonymous
                          ? "Your name will be hidden on the leaderboard"
                          : "Your name will be visible on the leaderboard"}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-purple-500/20">
                      <h3 className="text-md font-medium text-white mb-2">Gamepass Settings</h3>

                      {!gamepassSubmitted ? (
                        <form onSubmit={handleGamepassSubmit} className="space-y-3">
                          <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">Roblox Gamepass Link</label>
                            <input
                              type="text"
                              value={gamepassLink}
                              onChange={(e) => setGamepassLink(e.target.value)}
                              placeholder="https://www.roblox.com/game-pass/..."
                              className="w-full px-3 py-2 bg-black/60 border border-purple-500/30 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                              required
                            />
                            <p className="mt-1 text-xs text-gray-400">
                              Create a Roblox gamepass for 15,000 Robux and submit the link here
                            </p>
                          </div>

                          {error && (
                            <div className="bg-red-900/20 border border-red-500/30 rounded-md p-3 flex items-start gap-2">
                              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                              <p className="text-sm text-red-300">{error}</p>
                            </div>
                          )}

                          <button
                            type="submit"
                            disabled={isSubmittingGamepass}
                            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-md font-medium flex items-center justify-center gap-2 transition-colors disabled:opacity-70"
                          >
                            {isSubmittingGamepass ? (
                              <>
                                <RefreshCw className="w-4 h-4 animate-spin" />
                                Submitting...
                              </>
                            ) : (
                              "Submit Gamepass"
                            )}
                          </button>
                        </form>
                      ) : (
                        <div className="bg-green-900/20 border border-green-500/30 rounded-md p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <CheckCircle className="w-5 h-5 text-green-400" />
                            <h3 className="text-white font-medium">Gamepass Submitted!</h3>
                          </div>
                          <p className="text-sm text-gray-300 mb-2">
                            Your gamepass has been registered. We'll purchase it automatically when you reach 100
                            clicks!
                          </p>
                          <div className="text-xs text-gray-400 break-all">
                            <span className="font-medium">Link:</span> {gamepassLink}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="bg-black/70 backdrop-blur-md border border-purple-500/30 rounded-lg p-4">
                  <h2 className="text-lg font-medium text-white mb-2">Contact Support</h2>
                  <p className="text-sm text-gray-300 mb-3">
                    If you have any issues or questions, please contact our support team.
                  </p>
                  <div className="bg-purple-900/20 rounded-md p-3">
                    <p className="text-sm text-gray-300">
                      Contact <span className="text-purple-400 font-medium">poepx</span> on Discord for assistance.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
