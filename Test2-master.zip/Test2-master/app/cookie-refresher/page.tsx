import CookieRefresher from "@/components/cookie-refresher"
import { RedParticleCanvas } from "@/components/red-particle-canvas"

export default function CookieRefresherPage() {
  return (
    <>
      <RedParticleCanvas />
      <CookieRefresher />
    </>
  )
}
