"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  Play,
  DollarSign,
  CheckCircle,
  Download,
  Upload,
  AlertCircle,
  ChevronRight,
  BookOpen,
  Video,
  LinkIcon,
  Star,
  ThumbsUp,
  X,
  Info,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react"

// Import the purple particle canvas for the background effect
import PurpleParticleCanvas from "@/components/purple-particle-canvas"
import { submitEditingForm } from "../actions/submit-editing-form"

export default function EditingPage() {
  const [showTutorial, setShowTutorial] = useState(false)
  const [isSubmittingLink, setIsSubmittingLink] = useState(false)
  const [submissionMessage, setSubmissionMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const mainVideoRef = useRef<HTMLVideoElement>(null)
  const videoContainerRef = useRef<HTMLDivElement>(null)
  const [activeStep, setActiveStep] = useState<number | null>(null)
  const [activeTab, setActiveTab] = useState("overview")

  // Add a new state for the stor.ge link
  const [storgeLink, setStorgeLink] = useState("")

  // Video URLs
  const mainVideoUrl = "https://stor.ge/p6NtXjqK.MOV"
  const exampleVideoUrl = "https://stor.ge/XLfECDso.MOV"

  // Add these after the existing video URLs
  const mainVideoFallbackUrl = "https://stor.ge/p6NtXjqK.mp4" // Fallback URL if needed
  const exampleVideoFallbackUrl = "https://stor.ge/XLfECDso.mp4" // Fallback URL if needed

  // Tutorial data
  const tutorialData = {
    id: "video-editing-tutorial",
    name: "Professional Video Editing",
    emoji: "🎬",
    description:
      "Learn how to edit videos professionally to earn 8,000 Robux. This comprehensive guide covers all aspects of video editing from basic cuts to advanced effects.",
    category: "Technical",
    difficulty: "intermediate",
    author: "Shockify Team",
    rating: 4.8,
    successRate: "95% approval rate",
    lastUpdated: "2 days ago",
    downloads: 1243,
    isNew: true,
    features: [
      "Professional transitions between clips",
      "Color grading and enhancement",
      "Background music integration",
      "Text overlays and animations",
      "Visual effects and filters",
      "High-quality export settings",
    ],
    requirements: [
      "Video editing software (Adobe Premiere Pro, Final Cut Pro, DaVinci Resolve, etc.)",
      "Basic knowledge of video editing techniques",
      "Ability to download the source video and upload your edited version",
      "Roblox account to receive payment",
      "Discord account for communication",
    ],
    tags: ["Video Editing", "Robux", "Tutorial", "Premiere Pro", "DaVinci Resolve", "Final Cut Pro"],
    effectiveness: 5,
    steps: [
      {
        title: "Download the Source Video",
        instructions: [
          "Click the 'Download Video' button on the editing page",
          "Save the video file to your computer",
          "Make sure the video plays correctly before proceeding",
          "Note any specific elements you want to enhance",
        ],
      },
      {
        title: "Import into Your Editing Software",
        instructions: [
          "Open your preferred video editing software",
          "Create a new project with 1080p resolution at 30fps",
          "Import the downloaded video into your project",
          "Organize your project files and create necessary sequences",
        ],
      },
      {
        title: "Apply Basic Edits",
        instructions: [
          "Trim unnecessary parts from the beginning and end",
          "Cut out any mistakes or unwanted sections",
          "Arrange clips in a logical and engaging sequence",
          "Adjust the pacing to maintain viewer interest",
        ],
      },
      {
        title: "Add Transitions and Effects",
        instructions: [
          "Apply smooth transitions between clips (dissolves, wipes, etc.)",
          "Add motion effects like zoom, pan, or rotation where appropriate",
          "Apply color grading to enhance the visual appeal",
          "Use filters to create a consistent look throughout the video",
        ],
      },
      {
        title: "Incorporate Audio Elements",
        instructions: [
          "Add background music that matches the mood of the video",
          "Adjust audio levels to ensure music doesn't overpower other sounds",
          "Add sound effects to enhance specific moments",
          "Normalize audio to maintain consistent volume levels",
        ],
      },
      {
        title: "Add Text and Graphics",
        instructions: [
          "Create title screens with engaging typography",
          "Add lower thirds or captions where needed",
          "Include animated text elements for emphasis",
          "Insert graphical elements that enhance the content",
        ],
      },
      {
        title: "Export Final Video",
        instructions: [
          "Choose MP4 format with H.264 codec for best compatibility",
          "Set resolution to 1080p or higher",
          "Use a high bitrate (8-12 Mbps) for quality output",
          "Ensure audio is exported at 48kHz, 320kbps",
        ],
      },
      {
        title: "Submit Your Edited Video",
        instructions: [
          "Return to the editing page on our website",
          "Fill out all required fields in the submission form",
          "Upload your final edited video or provide a stor.ge link",
          "Submit your work and wait for review and payment",
        ],
      },
    ],
    tips: [
      "Watch professional editing tutorials on YouTube to learn advanced techniques",
      "Use keyboard shortcuts to speed up your editing workflow",
      "Save your project frequently to avoid losing work",
      "Create multiple versions of your edit to give yourself options",
      "Preview your video on different devices to ensure it looks good everywhere",
    ],
    warnings: [
      "Don't use copyrighted music without proper licensing",
      "Avoid over-editing that might distract from the content",
      "Don't compress the video too much as it reduces quality",
      "Make sure to meet all requirements to ensure payment",
      "Don't share the original video with others",
    ],
  }

  // Function to preload videos and set initial time
  const preloadVideo = (videoElement: HTMLVideoElement | null, startTime = 3) => {
    if (!videoElement) return

    const handleCanPlay = () => {
      videoElement.currentTime = startTime
    }

    const handleError = (e: Event) => {
      console.error("Video error:", e)
      // The error UI will be handled by the onError event on the video element
    }

    videoElement.addEventListener("canplay", handleCanPlay, { once: true })
    videoElement.addEventListener("error", handleError, { once: true })

    // Force load if needed
    if (videoElement.readyState >= 2) {
      handleCanPlay()
    } else {
      videoElement.load()
    }

    // Return cleanup function
    return () => {
      videoElement.removeEventListener("canplay", handleCanPlay)
      videoElement.removeEventListener("error", handleError)
    }
  }

  useEffect(() => {
    // Preload main video
    const mainVideoCleanup = preloadVideo(mainVideoRef.current)

    // Preload example video
    const exampleVideoCleanup = preloadVideo(videoRef.current)

    // Clean up
    return () => {
      if (mainVideoRef.current) {
        mainVideoRef.current.pause()
      }
      if (videoRef.current) {
        videoRef.current.pause()
      }
      mainVideoCleanup && mainVideoCleanup()
      exampleVideoCleanup && exampleVideoCleanup()
    }
  }, [])

  const playVideo = () => {
    if (videoRef.current) {
      try {
        const playPromise = videoRef.current.play()
        if (playPromise !== undefined) {
          playPromise.catch((error) => {
            console.error("Error playing video:", error)
            // Handle autoplay restrictions
            if (error.name === "NotAllowedError") {
              alert("Autoplay is disabled. Please click the video controls to play.")
            }
          })
        }
      } catch (error) {
        console.error("Error playing video:", error)
      }
    }
  }

  const pauseVideo = () => {
    if (videoRef.current) {
      videoRef.current.pause()
    }
  }

  // Add a handler for the stor.ge link input
  const handleStorgeLinkChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setStorgeLink(e.target.value)
  }

  // Add a handler for the form submission
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Create FormData from the form
    const form = e.target as HTMLFormElement
    const formData = new FormData(form)

    // Add the storgeLink to the formData if it exists
    if (storgeLink) {
      formData.set("storgeLink", storgeLink)
    }

    setIsSubmittingLink(true)
    try {
      const result = await submitEditingForm(formData)
      setSubmissionMessage({
        type: result.success ? "success" : "error",
        text: result.message,
      })

      if (result.success) {
        // Reset form on success
        form.reset()
        setStorgeLink("")
      }
    } catch (error) {
      setSubmissionMessage({
        type: "error",
        text: "An error occurred. Please try again.",
      })
    } finally {
      setIsSubmittingLink(false)
    }
  }

  const renderStarRating = (rating: number) => {
    const fullStars = Math.floor(rating)
    const hasHalfStar = rating % 1 >= 0.5
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0)

    return (
      <div className="flex items-center">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`full-${i}`} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
        ))}
        {hasHalfStar && (
          <div className="relative">
            <Star className="w-4 h-4 text-yellow-400" />
            <div className="absolute inset-0 overflow-hidden w-1/2">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            </div>
          </div>
        )}
        {[...Array(emptyStars)].map((_, i) => (
          <Star key={`empty-${i}`} className="w-4 h-4 text-yellow-400" />
        ))}
        <span className="ml-2 text-sm">{rating.toFixed(1)}</span>
      </div>
    )
  }

  const getCategoryColor = (category: string): string => {
    const lowerCategory = category.toLowerCase()
    switch (lowerCategory) {
      case "technical":
        return "text-green-400 border-green-400/30 bg-green-400/10"
      default:
        return "text-blue-400 border-blue-400/30 bg-blue-400/10"
    }
  }

  const getDifficultyColor = (difficulty: string): string => {
    const lowerDifficulty = difficulty.toLowerCase()
    switch (lowerDifficulty) {
      case "beginner":
        return "text-green-400 border-green-400/50 bg-green-500/20"
      case "intermediate":
        return "text-yellow-400 border-yellow-400/50 bg-yellow-500/20"
      case "advanced":
        return "text-red-400 border-red-400/50 bg-red-500/20"
      default:
        return "text-gray-400 border-gray-400/50 bg-gray-500/20"
    }
  }

  const toggleStep = (index: number) => {
    if (activeStep === index) {
      setActiveStep(null)
    } else {
      setActiveStep(index)
    }
  }

  return (
    <div className="relative min-h-screen bg-black text-white overflow-hidden">
      {/* Background Canvas */}
      <div className="fixed inset-0 z-0">
        <PurpleParticleCanvas />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Back Button */}
        <div className="mb-6">
          <Link
            href="/"
            className="flex items-center text-purple-400 hover:text-white transition-colors gap-1 bg-black/80 px-3 py-1.5 rounded-md border border-purple-500/20 hover:border-purple-500/40 relative overflow-hidden group"
          >
            <ArrowLeft className="w-4 h-4 relative z-10" />
            <span className="relative z-10 font-medium">Back to Home</span>
            <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
          </Link>
        </div>

        {/* Main Content */}
        <div className="bg-black/80 rounded-xl p-6 max-w-4xl mx-auto border border-purple-500/30 shadow-lg">
          {/* Header */}
          <h1 className="text-3xl md:text-4xl font-bold text-center mb-6 text-purple-300 uppercase tracking-wider">
            EDIT THIS VIDEO AND GET 8K ROBUX
          </h1>

          {/* Description */}
          <div className="mb-8">
            <p className="text-gray-300 text-center">
              Download the video below, edit it according to our requirements, and submit your edited version to earn
              8,000 Robux! We're looking for creative editors to transform this footage into something amazing.
            </p>
          </div>

          {/* Video to Edit Section */}
          <div className="bg-black/80 p-4 rounded-lg border border-purple-500/20 mb-6">
            <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
              <Video className="w-5 h-5 text-purple-400" />
              Video to Edit
            </h3>

            <div className="aspect-video bg-black/50 rounded-lg overflow-hidden mb-4 relative">
              {/* Loading indicator */}
              <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10 video-loading">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent"></div>
              </div>

              {/* Error message */}
              <div className="absolute inset-0 flex items-center justify-center bg-black/70 z-10 hidden video-error">
                <div className="text-center p-4">
                  <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-2" />
                  <p className="text-red-400">Video failed to load. Please try again.</p>
                  <button
                    onClick={() => {
                      document.querySelector(".video-error")?.classList.add("hidden")
                      document.querySelector(".video-loading")?.classList.remove("hidden")
                      if (mainVideoRef.current) {
                        mainVideoRef.current.load()
                      }
                    }}
                    className="mt-3 px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-md text-white"
                  >
                    Try Again
                  </button>
                </div>
              </div>

              <video
                ref={mainVideoRef}
                className="w-full h-full object-contain"
                poster="/video-editing-workspace.png"
                preload="auto"
                controls
                controlsList="download"
                onLoadedData={() => {
                  document.querySelector(".video-loading")?.classList.add("hidden")
                }}
                onError={() => {
                  document.querySelector(".video-loading")?.classList.add("hidden")
                  document.querySelector(".video-error")?.classList.remove("hidden")
                }}
              >
                <source src={mainVideoUrl} type="video/quicktime" />
                <source src={mainVideoUrl} type="video/mp4" />
                <source src={mainVideoUrl} type="video/webm" />
                Your browser does not support the video tag.
              </video>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-between items-center">
              <div>
                <p className="text-sm text-gray-300">Download this video and edit it according to the requirements</p>
              </div>
              <a
                href={mainVideoUrl}
                download="video-to-edit.mp4"
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg flex items-center gap-2 text-white font-medium"
              >
                <Download className="w-4 h-4" />
                Download Video
              </a>
            </div>
          </div>

          {/* Payment Info */}
          <div className="bg-black/80 p-4 rounded-lg border border-purple-500/20 mb-6">
            <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              Payment Details
            </h3>
            <div className="flex items-center justify-between mb-2 pb-2 border-b border-gray-700">
              <span className="text-gray-300">Payment Amount:</span>
              <span className="font-bold text-green-400">8,000 Robux</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Payment Method:</span>
              <span className="font-medium text-white">Roblox Game Pass</span>
            </div>

            {/* Tutorial Button */}
            <button
              onClick={() => setShowTutorial(true)}
              className="w-full mt-4 px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md flex items-center justify-center gap-2 transition-colors shadow-lg transform hover:translate-y-[-2px] transition-transform duration-200"
            >
              <BookOpen className="w-5 h-5" />
              <span className="font-bold">VIEW STEP-BY-STEP TUTORIAL</span>
              <ChevronRight className="w-5 h-5 ml-1 group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Text for vouches moved under the button */}
            <div className="mt-4 text-center">
              <p className="text-gray-300 mb-2">If you do not trust it, check out all my verified vouches:</p>
              <Link
                href="/vouches"
                className="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md flex items-center justify-center gap-2 transition-colors shadow-lg transform hover:translate-y-[-2px] transition-transform duration-200"
              >
                <ThumbsUp className="w-5 h-5" />
                <span className="font-bold">VIEW VERIFIED VOUCHES</span>
                <ChevronRight className="w-5 h-5 ml-1 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>

          {/* Submission Message */}
          {submissionMessage && (
            <div
              className={`mb-6 p-4 rounded-lg border ${
                submissionMessage.type === "success"
                  ? "bg-green-900/20 border-green-500/30 text-green-400"
                  : "bg-red-900/20 border-red-500/30 text-red-400"
              }`}
            >
              <div className="flex items-start gap-3">
                {submissionMessage.type === "success" ? (
                  <CheckCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                ) : (
                  <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                )}
                <p>{submissionMessage.text}</p>
              </div>
            </div>
          )}

          {/* Stor.ge Link Option */}
          <div className="relative mb-6">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-blue-500/20 blur-xl opacity-30"></div>
            <div className="relative bg-black/80 border border-purple-500/30 rounded-lg p-4">
              <h4 className="text-lg font-medium mb-3 flex items-center gap-2">
                <LinkIcon className="w-5 h-5 text-purple-400" />
                Submit Your Stor.ge Video Link
              </h4>
              <div className="flex gap-3">
                <input
                  type="text"
                  value={storgeLink}
                  onChange={handleStorgeLinkChange}
                  placeholder="https://stor.ge/your-video-link"
                  className="flex-1 px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (!storgeLink) {
                      setSubmissionMessage({
                        type: "error",
                        text: "Please enter a valid stor.ge link",
                      })
                      return
                    }
                    // Just update the input field, actual submission happens with the form
                    setSubmissionMessage({
                      type: "success",
                      text: "Link added! Complete the form below and submit.",
                    })
                  }}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors flex items-center gap-2"
                >
                  <LinkIcon className="w-4 h-4" />
                  <span>Add Link</span>
                </button>
              </div>

              {/* How to upload instructions */}
              <div className="mt-4 bg-black/80 p-3 rounded-lg border border-purple-500/20">
                <h5 className="text-sm font-medium mb-2 text-purple-300">How to upload your video:</h5>
                <ol className="text-sm text-gray-300 list-decimal pl-5 space-y-1">
                  <li>
                    Go to{" "}
                    <a
                      href="https://stor.ge"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purple-400 hover:underline"
                    >
                      https://stor.ge
                    </a>
                  </li>
                  <li>Upload your video file</li>
                  <li>When uploaded, copy the link</li>
                  <li>Paste the link in the field above and click Submit</li>
                </ol>
              </div>
            </div>
          </div>

          <form onSubmit={handleFormSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label htmlFor="name" className="block font-medium">
                  Your Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  required
                  className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="discord" className="block font-medium">
                  Discord Username
                </label>
                <input
                  type="text"
                  id="discord"
                  name="discord"
                  required
                  className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label htmlFor="robloxUsername" className="block font-medium">
                Roblox Username (for payment)
              </label>
              <input
                type="text"
                id="robloxUsername"
                name="robloxUsername"
                required
                className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="description" className="block font-medium">
                Describe the edits you made to the video
              </label>
              <textarea
                id="description"
                name="description"
                rows={4}
                required
                className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                placeholder="Describe the effects, transitions, and other edits you applied..."
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={isSubmittingLink}
              className="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md flex items-center justify-center gap-2 transition-colors shadow-lg font-medium disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isSubmittingLink ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5" />
                  <span>Submit Your Edited Video</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Preview Video Section */}
        <div className="mt-12 bg-black/80 rounded-xl p-6 max-w-4xl mx-auto border border-purple-500/30 shadow-lg">
          <h2 className="text-2xl font-bold mb-6 text-center text-purple-300 flex items-center justify-center gap-2">
            <Play className="text-purple-400 w-6 h-6" />
            Example of Edited Video
            <Play className="text-purple-400 w-6 h-6" />
          </h2>

          <p className="text-gray-300 text-center mb-8">
            Here's an example of how your edited video could look. We're looking for creative effects, smooth
            transitions, and professional color grading.
          </p>

          <div className="bg-black/80 rounded-lg p-3 border border-purple-500/20 hover:border-purple-500/40 transition-all">
            <div
              ref={videoContainerRef}
              className="aspect-video bg-black/50 rounded-lg overflow-hidden mb-3 relative cursor-pointer"
            >
              {/* Loading indicator */}
              <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10 example-loading">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent"></div>
              </div>

              {/* Error message */}
              <div className="absolute inset-0 flex items-center justify-center bg-black/70 z-10 hidden example-error">
                <div className="text-center p-4">
                  <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-2" />
                  <p className="text-red-400">Video failed to load. Please try again.</p>
                  <button
                    onClick={() => {
                      document.querySelector(".example-error")?.classList.add("hidden")
                      document.querySelector(".example-loading")?.classList.remove("hidden")
                      if (videoRef.current) {
                        videoRef.current.load()
                      }
                    }}
                    className="mt-3 px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-md text-white"
                  >
                    Try Again
                  </button>
                </div>
              </div>

              <div className="absolute inset-0 flex items-center justify-center z-10 play-button">
                <button
                  onClick={playVideo}
                  className="w-16 h-16 rounded-full bg-purple-600/80 flex items-center justify-center hover:bg-purple-600 transition-colors"
                >
                  <Play className="w-8 h-8 text-white ml-1" />
                </button>
              </div>

              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                preload="auto"
                onPlay={(e) => {
                  const parent = e.currentTarget.parentElement
                  if (parent) {
                    const playButton = parent.querySelector(".play-button")
                    if (playButton) playButton.classList.add("hidden")
                  }
                }}
                onPause={(e) => {
                  const parent = e.currentTarget.parentElement
                  if (parent) {
                    const playButton = parent.querySelector(".play-button")
                    if (playButton) playButton.classList.remove("hidden")
                  }
                }}
                onLoadedData={() => {
                  document.querySelector(".example-loading")?.classList.add("hidden")
                }}
                onError={() => {
                  document.querySelector(".example-loading")?.classList.add("hidden")
                  document.querySelector(".example-error")?.classList.remove("hidden")
                }}
                controls
              >
                <source src={exampleVideoUrl} type="video/quicktime" />
                <source src={exampleVideoUrl} type="video/mp4" />
                <source src={exampleVideoUrl} type="video/webm" />
                Your browser does not support the video tag.
              </video>
            </div>
            <h3 className="font-bold text-lg text-purple-300">Professional Edit Example</h3>
            <p className="text-gray-400 text-sm">This shows the type of quality we're looking for in your submission</p>
          </div>

          <div className="mt-8 text-center">
            <p className="text-gray-300 mb-4">Ready to start editing? Download the source video and get creative!</p>
            <a
              href={mainVideoUrl}
              download="video-to-edit.mp4"
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md inline-flex items-center gap-2 transition-colors shadow-lg"
            >
              <Download className="w-5 h-5" />
              <span>Download Source Video</span>
            </a>
          </div>
        </div>
      </div>

      {/* Method Detail Modal - EXACTLY like the /methods page */}
      {showTutorial && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowTutorial(false)}></div>

          <div
            className="relative w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col border border-purple-500/30 rounded-xl bg-gradient-to-br from-black/95 to-purple-900/20"
            onClick={(e) => e.stopPropagation()}
            style={{ boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
          >
            {/* Header */}
            <div className="p-5 border-b border-purple-500/20 flex justify-between items-center bg-gradient-to-r from-purple-900/40 to-black sticky top-0 z-10">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                {tutorialData.emoji && <span className="text-2xl">{tutorialData.emoji}</span>}
                <span className="purple-glow">{tutorialData.name}</span>
                {tutorialData.isNew && (
                  <span className="ml-2 bg-gradient-to-r from-purple-600 to-purple-400 text-white text-xs px-2 py-0.5 rounded-full shadow-md">
                    New
                  </span>
                )}
              </h2>
              <button
                onClick={() => setShowTutorial(false)}
                className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10 relative overflow-hidden group"
                aria-label="Close details"
              >
                <X className="w-6 h-6 relative z-10" />
                <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100"></div>
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6 custom-scrollbar">
              {/* Effectiveness Rating at Top */}
              <div className="flex flex-col sm:flex-row gap-4 items-start">
                <div className="flex-1 order-2 sm:order-1">
                  <div className="flex flex-col gap-3">
                    <div className="bg-gradient-to-br from-black/60 to-purple-900/10 border border-purple-500/20 rounded-lg p-3 shadow-md">
                      <h3 className="text-lg font-semibold text-purple-400 mb-2 flex items-center gap-2">
                        <Star className="w-5 h-5" /> Effectiveness Rating
                      </h3>
                      <div className="flex items-center gap-3">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-6 h-6 ${
                                i < (tutorialData.effectiveness || 0)
                                  ? "text-yellow-400 fill-yellow-400"
                                  : "text-gray-600"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-lg font-bold text-white">
                          {tutorialData.effectiveness ? `${tutorialData.effectiveness}/5` : "N/A"}
                        </span>
                      </div>

                      {/* Success Rate */}
                      {tutorialData.successRate && (
                        <div className="mt-3">
                          <h4 className="text-sm font-semibold text-purple-400 mb-1 flex items-center gap-1">
                            <Star className="w-4 h-4" /> Success Rate:
                          </h4>
                          <div className="text-sm text-white bg-black/40 px-3 py-1.5 rounded-md border border-purple-500/20 inline-block shadow-inner">
                            {tutorialData.successRate}
                          </div>
                        </div>
                      )}

                      <div className="mt-3">
                        <h4 className="text-sm font-semibold text-purple-400 mb-1 flex items-center gap-1">
                          <Info className="w-4 h-4" /> Tags:
                        </h4>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {tutorialData.tags.map((tag, index) => (
                            <span
                              key={index}
                              className="text-xs px-2 py-1 rounded-md border shadow-sm bg-purple-500/10 text-purple-400 border-purple-500/20"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="sm:w-64 space-y-4 order-1 sm:order-2">
                  {/* Stats */}
                  <div className="border border-purple-500/20 rounded-lg p-4 bg-gradient-to-br from-black/60 to-purple-900/10 shadow-md">
                    <h3 className="text-sm font-semibold text-purple-400 mb-3 flex items-center gap-1">
                      <Info className="w-4 h-4" /> Information
                    </h3>

                    <div className="space-y-2 text-sm">
                      {tutorialData.author && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">Author:</span>
                          <span className="text-white">{tutorialData.author}</span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-gray-400">Downloads:</span>
                        <span className="text-white">{tutorialData.downloads.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Rating:</span>
                        <span className="text-white flex items-center">
                          {tutorialData.rating.toFixed(1)}
                          <Star className="w-3.5 h-3.5 text-yellow-400 ml-1" />
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Difficulty:</span>
                        <span className={getDifficultyColor(tutorialData.difficulty).split(" ")[0]}>
                          {tutorialData.difficulty.charAt(0).toUpperCase() + tutorialData.difficulty.slice(1)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Category:</span>
                        <span className={getCategoryColor(tutorialData.category).split(" ")[0]}>
                          {tutorialData.category.charAt(0).toUpperCase() + tutorialData.category.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Detailed Tutorial Section */}
              <div className="mt-6">
                <div className="bg-gradient-to-r from-purple-900/30 to-black/60 border-l-4 border-purple-500 rounded-lg p-5 mb-6 shadow-lg">
                  <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                    {tutorialData.emoji && <span className="text-2xl">{tutorialData.emoji}</span>}
                    {tutorialData.name} Tutorial
                  </h2>

                  <div className="mb-6">
                    <h3 className="text-lg font-semibold text-purple-400 mb-2 flex items-center gap-2">
                      <Info className="w-5 h-5" />
                      How It Works
                    </h3>
                    <p className="text-gray-200 bg-black/80 p-4 rounded-lg border border-purple-500/20 shadow-inner">
                      {tutorialData.description}
                    </p>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-lg font-semibold text-purple-400 mb-2 flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5" />
                      Requirements
                    </h3>
                    <ul className="space-y-2 bg-black/80 p-4 rounded-lg border border-purple-500/20 shadow-inner">
                      {tutorialData.requirements?.map((req, index) => (
                        <li key={index} className="flex items-start gap-2 text-gray-200">
                          <div className="mt-1 flex-shrink-0">
                            <div className="w-2 h-2 rounded-full bg-purple-400"></div>
                          </div>
                          <span>{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Tutorial Steps */}
                  <div className="space-y-6">
                    {tutorialData.steps?.map((step, stepIndex) => (
                      <div
                        key={stepIndex}
                        className="bg-black/80 rounded-lg border border-purple-500/20 overflow-hidden shadow-md"
                      >
                        <div className="bg-gradient-to-r from-purple-900/30 to-black/60 p-3 border-b border-purple-500/20">
                          <h3 className="font-semibold text-white flex items-center gap-2">
                            <span className="bg-gradient-to-r from-purple-600 to-purple-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold shadow-md">
                              {stepIndex + 1}
                            </span>
                            {step.title}
                          </h3>
                        </div>
                        <div className="p-4">
                          <ul className="space-y-3">
                            {step.instructions.map((item, itemIndex) => (
                              <li key={itemIndex} className="flex items-start gap-2 text-gray-200">
                                <CheckCircle2 className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Tips Section */}
                  {tutorialData.tips && (
                    <div className="mt-6 bg-black/80 rounded-lg border border-yellow-500/20 p-4 shadow-md">
                      <h3 className="text-lg font-semibold text-yellow-400 mb-3 flex items-center gap-2">
                        <Sparkles className="w-5 h-5" />
                        Important Tips
                      </h3>
                      <ul className="space-y-2">
                        {tutorialData.tips.map((tip, index) => (
                          <li key={index} className="flex items-start gap-2 text-gray-200">
                            <div className="mt-1 flex-shrink-0">
                              <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
                            </div>
                            <span>{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Warnings Section */}
                  {tutorialData.warnings && (
                    <div className="mt-4 bg-black/80 rounded-lg border border-red-500/20 p-4 shadow-md">
                      <h3 className="text-lg font-semibold text-red-400 mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5" />
                        Warnings
                      </h3>
                      <ul className="space-y-2">
                        {tutorialData.warnings.map((warning, index) => (
                          <li key={index} className="flex items-start gap-2 text-gray-200">
                            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                            <span>{warning}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx global>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(139, 92, 246, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(139, 92, 246, 0.3);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(139, 92, 246, 0.5);
        }
      `}</style>
    </div>
  )
}
