"use client"

import { useEffect, useState } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Loader2 } from "lucide-react"
import { PurpleParticleCanvas } from "@/components/purple-particle-canvas"

export default function RedirectPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [countdown, setCountdown] = useState(3)
  const [error, setError] = useState("")
  const [processingClick, setProcessingClick] = useState(true)

  useEffect(() => {
    const id = searchParams.get("id")

    if (!id) {
      router.push("https://shockify.lol")
      return
    }

    // Update click count in localStorage
    try {
      // Get current count
      const currentCount = Number.parseInt(localStorage.getItem(`clickCount_${id}`) || "0", 10)
      const newCount = currentCount + 1

      // Update localStorage
      localStorage.setItem(`clickCount_${id}`, newCount.toString())

      // Update global counter if available
      if (typeof window !== "undefined" && window.clickCounters) {
        window.clickCounters[id] = newCount
      }

      console.log(`Click registered! Current count: ${newCount}`)

      // Get webhook URL from localStorage
      const webhookUrl = localStorage.getItem(`webhook_${id}`)

      // Send notification to webhook
      if (webhookUrl) {
        sendWebhookNotification(webhookUrl, id, newCount)
          .then(() => {
            console.log("Webhook notification sent successfully")
            setProcessingClick(false)
          })
          .catch((error) => {
            console.error("Failed to send webhook notification:", error)
            setProcessingClick(false)
          })
      } else {
        setProcessingClick(false)
      }
    } catch (error) {
      console.error("Error updating click count:", error)
      setError("There was an error processing your request.")
      setProcessingClick(false)
    }

    // Countdown and redirect
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          router.push("https://shockify.lol")
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [searchParams, router])

  const sendWebhookNotification = async (webhookUrl, id, clickCount) => {
    try {
      // Use our API route to send the webhook to avoid CORS issues
      const response = await fetch("/api/send-webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          webhookUrl,
          embed: {
            title: "New Link Click",
            description: `Someone clicked your Shockify link!`,
            color: 10181046, // Purple color
            fields: [
              {
                name: "Current Clicks",
                value: `${clickCount}/100`,
                inline: true,
              },
              {
                name: "Progress",
                value: `${Math.min(Math.round((clickCount / 100) * 100), 100)}%`,
                inline: true,
              },
              {
                name: "Link ID",
                value: id,
                inline: false,
              },
              {
                name: "User Agent",
                value: navigator.userAgent || "Unknown",
                inline: false,
              },
              {
                name: "Time",
                value: new Date().toLocaleString(),
                inline: false,
              },
            ],
          },
        }),
      })

      if (!response.ok) {
        throw new Error(`Failed to send webhook notification: ${response.status}`)
      }

      return true
    } catch (error) {
      console.error("Failed to send webhook notification:", error)
      return false
    }
  }

  return (
    <>
      <PurpleParticleCanvas />
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white p-4 relative z-10">
        <div className="bg-black/80 backdrop-blur-md border border-purple-500/30 rounded-lg shadow-xl p-8 max-w-md w-full text-center">
          {error ? (
            <>
              <div className="text-red-400 mb-4">⚠️</div>
              <h1 className="text-2xl font-bold mb-2">Error</h1>
              <p className="text-gray-300 mb-4">{error}</p>
              <button
                onClick={() => router.push("https://shockify.lol")}
                className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md transition-colors"
              >
                Go to Homepage
              </button>
            </>
          ) : (
            <>
              <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
              <h1 className="text-2xl font-bold mb-2">Redirecting...</h1>
              <p className="text-gray-300 mb-4">
                {processingClick
                  ? "Processing your click..."
                  : `You will be redirected to Shockify in ${countdown} seconds.`}
              </p>
              <div className="w-full bg-gray-800 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-purple-500 to-purple-700 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${((3 - countdown) / 3) * 100}%` }}
                ></div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  )
}
