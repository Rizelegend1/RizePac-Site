import Link from "next/link"
import { PurpleParticleCanvas } from "@/components/purple-particle-canvas"

export default function NotFound() {
  return (
    <>
      <PurpleParticleCanvas />
      <div className="min-h-screen flex flex-col items-center justify-center p-4 relative z-10">
        <div className="bg-black/80 backdrop-blur-md border border-purple-500/30 rounded-lg shadow-xl overflow-hidden max-w-md w-full">
          <div className="p-6 border-b border-purple-500/20 bg-gradient-to-r from-purple-900/30 to-black">
            <h1 className="text-2xl font-bold text-white">404 - Page Not Found</h1>
          </div>
          <div className="p-6">
            <p className="text-gray-300 mb-6">The page you're looking for doesn't exist or has been moved.</p>
            <Link
              href="/"
              className="bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white py-2 px-4 rounded-md font-medium inline-block transition-colors"
            >
              Return to Home
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}
