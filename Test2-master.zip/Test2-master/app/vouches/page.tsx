"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { useMediaQuery } from "../hooks/use-media-query"
import Link from "next/link"
import { ArrowLeft, Star } from "lucide-react"
import RedParticleCanvas from "@/components/red-particle-canvas"

// Function to generate realistic usernames
function generateRandomName() {
  // More realistic gaming/Roblox usernames
  const commonUsernames = [
    "BloxKing",
    "RobloxPro",
    "GamingLegend",
    "ToxicSniper",
    "DarkGamer",
    "ShadowNinja",
    "EpicGamer",
    "RobloxQueen",
    "ProGamer",
    "BlockMaster",
    "SkullCrusher",
    "NightStalker",
    "MasterBuilder",
    "LegitPlayer",
    "RobloxWarrior",
    "GamingWizard",
    "ToxicGamer",
    "SavagePlayer",
    "UltimateNoob",
    "RobloxLegend",
    "GodlyGamer",
    "EpicSniper",
    "ProBuilder",
    "GamingBeast",
    "RobloxKiller",
    "ToxicKid",
    "SavageBeast",
    "UltraGamer",
    "MegaPlayer",
    "RobloxMaster",
  ]

  // More realistic name patterns
  const patterns = [
    // Just the username
    () => commonUsernames[Math.floor(Math.random() * commonUsernames.length)],

    // Username with numbers
    () => {
      const name = commonUsernames[Math.floor(Math.random() * commonUsernames.length)]
      const number = Math.floor(Math.random() * 9999)
      return `${name}${number}`
    },

    // Username with x's
    () => {
      const name = commonUsernames[Math.floor(Math.random() * commonUsernames.length)]
      return `x${name}x`
    },

    // Username with underscores
    () => {
      const name = commonUsernames[Math.floor(Math.random() * commonUsernames.length)]
      return `_${name}_`
    },

    // Short username with YT suffix
    () => {
      const name = commonUsernames[Math.floor(Math.random() * commonUsernames.length)]
      return `${name.substring(0, 5)}YT`
    },

    // Username with TTV suffix
    () => {
      const name = commonUsernames[Math.floor(Math.random() * commonUsernames.length)]
      return `${name}TTV`
    },
  ]

  // Select a random pattern
  const pattern = patterns[Math.floor(Math.random() * patterns.length)]
  let name = pattern()

  // Sometimes make it all lowercase
  if (Math.random() > 0.5) {
    name = name.toLowerCase()
  }

  return name
}

// Function to generate random recent dates (within last 3 months)
function generateRecentDate() {
  const now = new Date()
  const threeMonthsAgo = new Date()
  threeMonthsAgo.setMonth(now.getMonth() - 3)

  const randomTimestamp = threeMonthsAgo.getTime() + Math.random() * (now.getTime() - threeMonthsAgo.getTime())
  const randomDate = new Date(randomTimestamp)
  return randomDate.toISOString().split("T")[0]
}

// Define vouch data structure
interface VouchItem {
  id: number
  username: string
  avatar: string
  text: string
  date: string
  category: "beaming" | "editing" | "cookie"
  rating: number
}

export default function VouchesPage() {
  const isMobile = useMediaQuery("(max-width: 768px)")
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedService, setSelectedService] = useState<string>("all")
  const [isLoaded, setIsLoaded] = useState(false)
  const vouchesPerPage = isMobile ? 5 : 10
  const [vouches, setVouches] = useState<VouchItem[]>([])

  // List of profile picture URLs
  const profilePics = [
    "/images/profile1.png",
    "/images/profile2.png",
    "/images/profile3.png",
    "/images/profile4.png",
    "/images/profile5.png",
    "/images/profile6.png",
    "/images/profile7.png",
    "/images/profile8.png",
    "/images/profile9.png",
    "/images/profile10.png",
    "/images/profile-manga.png",
    "/images/profile-snow.png",
    "/images/profile-spiky.png",
    "/images/profile-kids.png",
    "/images/profile-shirtless.png",
    "/images/profile-blue-eyes.png",
    "/images/profile-couple.png",
    "/images/profile-horror.png",
    "/images/profile-ufc.png",
    "/images/profile-dragon.png",
  ]

  // Video editing vouch content templates
  const videoEditingVouches = [
    "shockify edited my montage and i got paid 8k robux right after he finished!! super legit no cap",
    "just got 8k robux for editing a video for shockify. took me like 3 hours and got paid same day fr",
    "easiest 8k robux i ever made!! edited a video for shockify and he paid instantly",
    "shockify paid me 8k robux for my edit and it wasnt even that good lol ez money",
    "got my 8k robux payment right after i sent the final edit. shockify is 100% legit",
    "edited a montage for shockify and got 8k robux same day. gonna do more edits for sure",
    "shockify paid me 8k robux for a simple edit that took me like 2 hours. best deal ever fr fr",
    "just made my first edit for shockify and got 8k robux!! so hyped rn",
    "been editing for shockify for a month now. always pays 8k robux on time no cap",
    "shockify never scams, always pays the full 8k robux after i finish editing",
    "made 24k robux in one week just from editing 3 videos for shockify",
    "first time editing for someone and got 8k robux from shockify. super easy work tbh",
    "shockify paid me 8k robux for my first ever montage edit. def recommend",
    "got my robux payment instantly after sending the final edit to shockify. 100% legit",
    "edited a video for shockify yesterday and woke up to 8k robux in my account today",
  ]

  // Beaming vouch content templates
  const beamingVouches = [
    "yo shockify helped me beam this rich kid with korblox lol got all his limiteds now and sold for 200$",
    "shockify method worked so good!! beamed a 2016 acc with headless and got like 40k value sold it for big $$$",
    "bro i cant belive how ez it was to beam with shockifys method!! got a stacked acc in like 10 mins and sold it",
    "h@cked my first account using shockify's method and it worked first try lmaoo sold it for 150$",
    "this dude is insane, helped me beam 3 accounts in one day and now im rich af from selling them",
    "shockify method is unmatched fr fr!! beamed a 2008 acc with rare items and sold for 300$",
    "got my first beam with shockify's help and the acc had so many robux on it lol sold it for ez money",
    "beamed my first account today using shockify's method and it had korblox!! sold it for 250$",
    "shockify helped me h@ck my friends acc as a prank and it worked so good lmao could have sold it for big $",
    "just beamed a acc with 50k rap using shockify's method, this sh!t is crazy good sold for 400$",
  ]

  // Cookie refresher vouch content templates
  const cookieRefresherVouches = [
    "shockify's cookie refresher works every time no cap. best one ive used",
    "cookie refresher is fast af and never fails!! worth every penny",
    "been using shockify's cookie refresher for months, works perfect every time fr fr",
    "the cookie refresher saved me so many times. 100% worth it",
    "most reliable cookie refresher out there. shockify delivers quality fr",
    "cookie refresher works like magic. instant results every time no cap",
    "shockify's cookie refresher is the only one that actually works for me",
    "tried many cookie refreshers but shockify's is the best by far!!",
    "the cookie refresher is so ez to use and works instantly",
    "shockify's cookie refresher has never let me down. 100% reliable fr fr",
  ]

  useEffect(() => {
    const generatedVouches: VouchItem[] = []
    let id = 1

    // Create a copy of profile pics array to track used pictures
    const availableProfilePics = [...profilePics]

    // Helper function to get a unique profile pic
    const getUniquePic = () => {
      if (availableProfilePics.length === 0) {
        // If we've used all pics, reset the array
        availableProfilePics.push(...profilePics)
      }
      const randomIndex = Math.floor(Math.random() * availableProfilePics.length)
      const pic = availableProfilePics[randomIndex]
      // Remove the selected pic from available pics
      availableProfilePics.splice(randomIndex, 1)
      return pic
    }

    // Generate video editing vouches
    for (let i = 0; i < 15; i++) {
      generatedVouches.push({
        id: id++,
        username: generateRandomName(),
        avatar: getUniquePic(),
        text: videoEditingVouches[Math.floor(Math.random() * videoEditingVouches.length)],
        date: generateRecentDate(),
        category: "editing",
        rating: Math.random() > 0.2 ? 5 : 4,
      })
    }

    // Generate beaming vouches
    for (let i = 0; i < 15; i++) {
      generatedVouches.push({
        id: id++,
        username: generateRandomName(),
        avatar: getUniquePic(),
        text: beamingVouches[Math.floor(Math.random() * beamingVouches.length)],
        date: generateRecentDate(),
        category: "beaming",
        rating: Math.random() > 0.2 ? 5 : 4,
      })
    }

    // Generate cookie refresher vouches
    for (let i = 0; i < 10; i++) {
      generatedVouches.push({
        id: id++,
        username: generateRandomName(),
        avatar: getUniquePic(),
        text: cookieRefresherVouches[Math.floor(Math.random() * cookieRefresherVouches.length)],
        date: generateRecentDate(),
        category: "cookie",
        rating: Math.random() > 0.2 ? 5 : 4,
      })
    }

    // Sort by date (most recent first)
    generatedVouches.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    setVouches(generatedVouches)
    setIsLoaded(true)
  }, [])

  const filteredVouches =
    selectedService === "all"
      ? vouches
      : vouches.filter((vouch) => {
          if (selectedService === "video editing") return vouch.category === "editing"
          if (selectedService === "beaming") return vouch.category === "beaming"
          if (selectedService === "cookie refresher") return vouch.category === "cookie"
          return false
        })

  const totalPages = Math.ceil(filteredVouches.length / vouchesPerPage)
  const currentVouches = filteredVouches.slice((currentPage - 1) * vouchesPerPage, currentPage * vouchesPerPage)

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1)
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1)
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: "numeric", month: "short", day: "numeric" }
    return new Date(dateString).toLocaleDateString(undefined, options)
  }

  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star key={i} className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-700"}`} />
      ))
  }

  return (
    <div className="min-h-screen w-full bg-black text-white">
      {/* Background */}
      <div className="fixed inset-0 z-0">
        <RedParticleCanvas />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-4 py-8 sm:py-12">
        {/* Header */}
        <div className="mb-8 flex flex-col items-center">
          <Link
            href="/"
            className="self-start mb-6 flex items-center text-red-400 hover:text-white transition-colors gap-1 bg-gradient-to-r from-red-900/60 to-black/60 px-3 py-1.5 rounded-md border border-red-500/20 hover:border-red-500/40 relative overflow-hidden group shadow-lg hover:shadow-red-500/20"
          >
            <ArrowLeft className="w-4 h-4 relative z-10" />
            <span className="relative z-10 font-medium">Back to Home</span>
            <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-red-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
          </Link>

          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-4xl sm:text-5xl md:text-6xl font-bold text-center mb-4"
          >
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-red-400 to-red-600">
              VOUCHES FOR SHOCKIFY!
            </span>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-wrap justify-center gap-3 mb-8"
          >
            <button
              onClick={() => setSelectedService("all")}
              className={`px-4 py-2 rounded-md transition-all ${
                selectedService === "all"
                  ? "bg-red-600 text-white shadow-lg shadow-red-500/20"
                  : "bg-red-900/30 text-gray-300 hover:bg-red-800/40"
              }`}
            >
              All Vouches
            </button>
            <button
              onClick={() => setSelectedService("video editing")}
              className={`px-4 py-2 rounded-md transition-all ${
                selectedService === "video editing"
                  ? "bg-red-600 text-white shadow-lg shadow-red-500/20"
                  : "bg-red-900/30 text-gray-300 hover:bg-red-800/40"
              }`}
            >
              Video Editing
            </button>
            <button
              onClick={() => setSelectedService("beaming")}
              className={`px-4 py-2 rounded-md transition-all ${
                selectedService === "beaming"
                  ? "bg-red-600 text-white shadow-lg shadow-red-500/20"
                  : "bg-red-900/30 text-gray-300 hover:bg-red-800/40"
              }`}
            >
              Beaming
            </button>
            <button
              onClick={() => setSelectedService("cookie refresher")}
              className={`px-4 py-2 rounded-md transition-all ${
                selectedService === "cookie refresher"
                  ? "bg-red-600 text-white shadow-lg shadow-red-500/20"
                  : "bg-red-900/30 text-gray-300 hover:bg-red-800/40"
              }`}
            >
              Cookie Refresher
            </button>
          </motion.div>
        </div>

        {/* Vouches Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {isLoaded ? (
            currentVouches.length > 0 ? (
              currentVouches.map((vouch) => (
                <motion.div
                  key={vouch.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className="border border-red-500/30 rounded-xl bg-gradient-to-r from-red-900/20 to-black/80 overflow-hidden hover:border-red-500/50 transition-all duration-300 shadow-lg hover:shadow-red-500/30"
                >
                  <div className="p-5 relative">
                    <div className="flex items-start gap-4">
                      {/* Profile Picture */}
                      <div className="w-12 h-12 rounded-full bg-red-900/30 border border-red-500/30 overflow-hidden flex-shrink-0">
                        <img
                          src={vouch.avatar || "/placeholder.svg"}
                          alt={vouch.username}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      {/* Content */}
                      <div className="flex-1">
                        <div className="flex flex-wrap justify-between items-center mb-2">
                          <h3 className="font-semibold text-white">{vouch.username}</h3>
                          <div className="flex">{renderStars(vouch.rating)}</div>
                        </div>

                        <div className="text-gray-300 bg-black/40 p-3 rounded-lg border border-red-500/20 mb-3">
                          {vouch.text}
                        </div>

                        <div className="flex justify-between items-center">
                          <span
                            className={`text-xs px-2 py-1 rounded-md border ${
                              vouch.category === "beaming"
                                ? "bg-red-500/20 text-red-400 border-red-500/30"
                                : vouch.category === "editing"
                                  ? "bg-purple-500/20 text-purple-400 border-purple-500/30"
                                  : "bg-blue-500/20 text-blue-400 border-blue-500/30"
                            }`}
                          >
                            {vouch.category === "beaming"
                              ? "Beaming"
                              : vouch.category === "editing"
                                ? "Video Editing"
                                : "Cookie Refresher"}
                          </span>
                          <span className="text-xs text-gray-400">{formatDate(vouch.date)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full text-center py-10">
                <p className="text-gray-400">No vouches found for this category.</p>
              </div>
            )
          ) : (
            // Loading placeholders
            Array.from({ length: 6 }).map((_, index) => (
              <div
                key={index}
                className="border border-red-500/20 rounded-xl bg-gradient-to-r from-red-900/10 to-black/60 p-5 animate-pulse"
              >
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-full bg-red-900/30"></div>
                  <div className="flex-1">
                    <div className="h-4 bg-red-900/30 rounded w-1/3 mb-2"></div>
                    <div className="h-20 bg-red-900/20 rounded mb-2"></div>
                    <div className="flex justify-between">
                      <div className="h-4 bg-red-900/30 rounded w-1/4"></div>
                      <div className="h-4 bg-red-900/30 rounded w-1/4"></div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="mt-8 flex justify-center items-center gap-2">
            <button
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className="px-4 py-2 rounded-md bg-red-900/50 text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-red-800/60 transition-colors"
            >
              Previous
            </button>
            <div className="px-4 py-2 bg-red-900/30 rounded-md text-white">
              Page {currentPage} of {totalPages}
            </div>
            <button
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className="px-4 py-2 rounded-md bg-red-900/50 text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-red-800/60 transition-colors"
            >
              Next
            </button>
          </div>
        )}

        {/* Submit Vouch Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-12 border border-red-500/30 rounded-xl p-6 bg-gradient-to-r from-red-900/30 to-black/80 shadow-lg"
        >
          <h2 className="text-2xl font-bold text-center mb-4 text-white">Want to Submit a Vouch?</h2>

          <div className="text-center mb-6">
            <p className="text-gray-300 mb-2">
              Contact <span className="text-red-400 font-semibold">poepx</span> on Discord to share your experience!
            </p>
            <p className="text-gray-400 text-sm">Your feedback helps others discover our premium services</p>
          </div>

          <div className="flex justify-center">
            <a
              href="https://discord.com"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-md flex items-center gap-2 transition-colors shadow-lg shadow-red-500/20"
            >
              <span>Add on Discord: poepx</span>
            </a>
          </div>
        </motion.div>
      </div>

      <style jsx global>{`
        @keyframes shine {
          0% {
            transform: translateX(-100%) rotate(15deg);
          }
          20% {
            transform: translateX(100%) rotate(15deg);
          }
          100% {
            transform: translateX(100%) rotate(15deg);
          }
        }

        .shine-animation {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(
            to right,
            transparent 0%,
            rgba(255, 255, 255, 0.1) 50%,
            transparent 100%
          );
          transform: translateX(-100%) rotate(15deg);
          transition: none;
        }

        .group:hover .shine-animation {
          animation: shine 1.5s ease;
          opacity: 1;
        }
      `}</style>
    </div>
  )
}
