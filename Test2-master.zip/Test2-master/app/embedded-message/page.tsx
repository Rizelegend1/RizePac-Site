"use client"

import EmbeddedMessage from "@/components/embedded-message"

export default function EmbeddedMessagePage() {
  return (
    <div className="min-h-screen bg-[#2f3136] p-4 flex items-center justify-center">
      <div className="w-full max-w-md">
        <h1 className="text-white text-xl font-bold mb-4 text-center">Discord-like Embedded Message</h1>

        <EmbeddedMessage
          title="Shockify"
          description="Shockify The Number 1 Beaming Site!"
          linkText="Shockify ( link )"
          linkUrl="https://shockify.com"
          color="#ffffff"
        />

        <div className="mt-6 bg-[#36393f] p-4 rounded-md text-white">
          <h2 className="font-bold mb-2">How to Use:</h2>
          <p className="text-[#b9bbbe] text-sm mb-2">
            This component creates a Discord-like embedded message that can be used in your application.
          </p>
          <p className="text-[#b9bbbe] text-sm">
            You can customize the title, description, link text, link URL, and the left border color.
          </p>
        </div>
      </div>
    </div>
  )
}
