import type React from "react"
export default function EmbeddedMessageLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <div className="min-h-screen bg-[#2f3136]">{children}</div>
}
