"use server"

import { revalidatePath } from "next/cache"

// Use the environment variable for the webhook URL
const DISCORD_WEBHOOK_URL = process.env.DISCORD_WEBHOOK_URL || ""

export async function submitEditingForm(formData: FormData) {
  try {
    // Extract form data
    const name = formData.get("name") as string
    const discord = formData.get("discord") as string
    const robloxUsername = formData.get("robloxUsername") as string
    const description = formData.get("description") as string
    const storgeLink = formData.get("storgeLink") as string

    // Validate required fields
    if (!name || !discord || !robloxUsername) {
      return {
        success: false,
        message: "Please fill in all required fields",
      }
    }

    // Format data for Discord webhook
    const webhookData = {
      embeds: [
        {
          title: "🎬 New Video Editing Submission",
          color: 0x9c59ff, // Purple color
          fields: [
            {
              name: "👤 Name",
              value: name || "Not provided",
              inline: true,
            },
            {
              name: "🎮 Discord Username",
              value: discord || "Not provided",
              inline: true,
            },
            {
              name: "🎯 Roblox Username",
              value: robloxUsername || "Not provided",
              inline: true,
            },
            {
              name: "🔗 Stor.ge Link",
              value: storgeLink || "Not provided",
            },
            {
              name: "📝 Description of Edits",
              value: description || "Not provided",
            },
          ],
          footer: {
            text: "Submitted via Video Editing Form",
          },
          timestamp: new Date().toISOString(),
        },
      ],
    }

    // Send data to Discord webhook
    const response = await fetch(DISCORD_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(webhookData),
    })

    if (!response.ok) {
      console.error("Discord webhook error:", await response.text())
      return {
        success: false,
        message: "Failed to submit form. Please try again later.",
      }
    }

    // Revalidate the path to update the UI
    revalidatePath("/editing")

    return {
      success: true,
      message: "Your submission has been received! We'll review it and contact you soon.",
    }
  } catch (error) {
    console.error("Error submitting form:", error)
    return {
      success: false,
      message: "An error occurred while submitting the form. Please try again.",
    }
  }
}
