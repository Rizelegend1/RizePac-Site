export async function shortenUrl(formData: FormData) {
  const url = formData.get("url") as string

  if (!url) {
    return { success: false, error: "URL is required" }
  }

  try {
    const response = await fetch(`https://api.shrtco.de/v2/shorten?url=${encodeURIComponent(url)}`)
    const data = await response.json()

    if (data.ok) {
      return { success: true, shortUrl: data.result.full_short_link }
    } else {
      return { success: false, error: data.error }
    }
  } catch (error) {
    console.error("Error shortening URL:", error)
    return { success: false, error: "Failed to shorten URL" }
  }
}
