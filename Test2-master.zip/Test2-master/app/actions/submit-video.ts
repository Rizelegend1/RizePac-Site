"use server"

export async function submitStorgeLink(storgeLink: string) {
  if (!storgeLink) {
    return { success: false, message: "Stor.ge link is required" }
  }

  // Basic validation for stor.ge link
  if (!storgeLink.startsWith("https://stor.ge/")) {
    return { success: false, message: "Invalid Stor.ge link format" }
  }

  try {
    // Simulate submission process
    await new Promise((resolve) => setTimeout(resolve, 1500))

    return { success: true, message: "Your video has been submitted successfully!" }
  } catch (error) {
    console.error("Error submitting stor.ge link:", error)
    return { success: false, message: "Failed to submit link. Please try again." }
  }
}
