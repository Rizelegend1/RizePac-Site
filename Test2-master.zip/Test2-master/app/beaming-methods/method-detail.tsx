"use client"
import { useState } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Star,
  X,
  Info,
  Download,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Copy,
  Printer,
  Share2,
  BookOpen,
  Video,
  MessageCircle,
  ThumbsUp,
  BarChart3,
} from "lucide-react"

interface MethodDetailProps {
  isOpen: boolean
  onClose: () => void
  method: any
}

export function MethodDetail({ isOpen, onClose, method }: MethodDetailProps) {
  const [activeTab, setActiveTab] = useState("overview")
  const [copied, setCopied] = useState(false)

  if (!method) return null

  const handleCopy = () => {
    const methodText = `${method.name}

Description: ${method.description}

Difficulty: ${method.difficulty}
Success Rate: ${method.successRate}
Rating: ${method.rating}/5

Requirements:
${method.requirements.join("\n")}

Steps:
${method.steps.map((step: any, index: number) => `${index + 1}. ${step.title}`).join("\n")}`

    navigator.clipboard.writeText(methodText)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handlePrint = () => {
    window.print()
  }

  const renderStarRating = (rating: number) => {
    const fullStars = Math.floor(rating)
    const hasHalfStar = rating % 1 >= 0.5
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0)

    return (
      <div className="flex items-center">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`full-${i}`} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
        ))}
        {hasHalfStar && (
          <div className="relative">
            <Star className="w-4 h-4 text-yellow-400" />
            <div className="absolute inset-0 overflow-hidden w-1/2">
              <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            </div>
          </div>
        )}
        {[...Array(emptyStars)].map((_, i) => (
          <Star key={`empty-${i}`} className="w-4 h-4 text-yellow-400" />
        ))}
        <span className="ml-2 text-sm">{rating.toFixed(1)}</span>
      </div>
    )
  }

  const getDifficultyColor = (difficulty: string): string => {
    const lowerDifficulty = difficulty.toLowerCase()
    switch (lowerDifficulty) {
      case "beginner":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      case "intermediate":
        return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "advanced":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  const getCategoryColor = (category: string): string => {
    const lowerCategory = category.toLowerCase()
    switch (lowerCategory) {
      case "social":
        return "bg-blue-500/20 text-blue-400 border-blue-500/30"
      case "technical":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      case "discord":
        return "bg-indigo-500/20 text-indigo-400 border-indigo-500/30"
      case "tiktok":
        return "bg-pink-500/20 text-pink-400 border-pink-500/30"
      case "malware":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      case "phishing":
        return "bg-orange-500/20 text-orange-400 border-orange-500/30"
      default:
        return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl p-0 bg-[#13111C] text-white border-purple-900 max-h-[90vh] overflow-hidden flex flex-col">
        {/* Enhanced Header */}
        <div className="flex items-center justify-between p-4 border-b border-purple-900 bg-gradient-to-r from-purple-900/40 to-black">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 flex items-center justify-center text-2xl bg-gradient-to-br from-purple-900/30 to-black/30 rounded-full border border-purple-500/20 shadow-inner">
              {method.emoji || "💰"}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold">{method.name}</h2>
                {method.isNew && <Badge className="bg-purple-600 text-white">New</Badge>}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <Badge className={`${getCategoryColor(method.category)}`}>{method.category}</Badge>
                <Badge className={`${getDifficultyColor(method.difficulty)}`}>{method.difficulty}</Badge>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="text-gray-400 hover:text-white bg-black/30 p-2 rounded-full hover:bg-black/50 transition-colors"
              title="Copy method details"
            >
              {copied ? <CheckCircle2 className="h-5 w-5 text-green-400" /> : <Copy className="h-5 w-5" />}
            </button>
            <button
              onClick={handlePrint}
              className="text-gray-400 hover:text-white bg-black/30 p-2 rounded-full hover:bg-black/50 transition-colors"
              title="Print method"
            >
              <Printer className="h-5 w-5" />
            </button>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white bg-black/30 p-2 rounded-full hover:bg-black/50 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Tabs Navigation */}
        <Tabs defaultValue="overview" className="w-full" value={activeTab} onValueChange={setActiveTab}>
          <div className="border-b border-purple-900/50">
            <TabsList className="bg-transparent border-b border-purple-900/50 rounded-none h-12 w-full justify-start gap-2 px-4">
              <TabsTrigger
                value="overview"
                className="data-[state=active]:bg-purple-900/20 data-[state=active]:text-purple-400 rounded-t-md rounded-b-none border-b-2 border-transparent data-[state=active]:border-purple-500 px-4"
              >
                Overview
              </TabsTrigger>
              <TabsTrigger
                value="tutorial"
                className="data-[state=active]:bg-purple-900/20 data-[state=active]:text-purple-400 rounded-t-md rounded-b-none border-b-2 border-transparent data-[state=active]:border-purple-500 px-4"
              >
                Tutorial
              </TabsTrigger>
              <TabsTrigger
                value="tips"
                className="data-[state=active]:bg-purple-900/20 data-[state=active]:text-purple-400 rounded-t-md rounded-b-none border-b-2 border-transparent data-[state=active]:border-purple-500 px-4"
              >
                Tips & Warnings
              </TabsTrigger>
              <TabsTrigger
                value="related"
                className="data-[state=active]:bg-purple-900/20 data-[state=active]:text-purple-400 rounded-t-md rounded-b-none border-b-2 border-transparent data-[state=active]:border-purple-500 px-4"
              >
                Related Methods
              </TabsTrigger>
            </TabsList>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar" style={{ maxHeight: "calc(90vh - 120px)" }}>
            <TabsContent value="overview" className="p-0 m-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4">
                {/* Left column - 2/3 width */}
                <div className="md:col-span-2 space-y-4">
                  {/* Description */}
                  <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                    <div className="flex items-center gap-2 text-purple-400 mb-2">
                      <Info className="h-5 w-5" />
                      <h3 className="font-semibold">Description</h3>
                    </div>
                    <p className="text-gray-300 text-sm leading-relaxed">{method.description}</p>
                  </div>

                  {/* Effectiveness Rating */}
                  <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                    <div className="flex items-center gap-2 text-purple-400 mb-2">
                      <BarChart3 className="h-5 w-5" />
                      <h3 className="font-semibold">Effectiveness</h3>
                    </div>
                    <div className="flex flex-col gap-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-300">Rating:</span>
                        {renderStarRating(method.rating)}
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-300">Success Rate:</span>
                        <div className="bg-purple-900/30 text-purple-400 px-3 py-1 rounded-md text-sm border border-purple-500/30">
                          {method.successRate}
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-300">Downloads:</span>
                        <div className="flex items-center gap-1 text-gray-300 text-sm">
                          <Download className="h-4 w-4 text-purple-400" />
                          {method.downloads.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Requirements */}
                  <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                    <div className="flex items-center gap-2 text-purple-400 mb-2">
                      <CheckCircle2 className="h-5 w-5" />
                      <h3 className="font-semibold">Requirements</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-gray-300">
                      {method.requirements.map((req: string, index: number) => (
                        <li key={index} className="flex items-start gap-2">
                          <div className="mt-1 min-w-[8px]">
                            <div className="w-1.5 h-1.5 rounded-full bg-purple-400"></div>
                          </div>
                          <span>{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Tags */}
                  <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                    <div className="flex items-center gap-2 text-purple-400 mb-2">
                      <Info className="h-5 w-5" />
                      <h3 className="font-semibold">Tags</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {method.tags.map((tag: string, index: number) => (
                        <Badge
                          key={index}
                          className="bg-purple-900/30 hover:bg-purple-800/40 text-purple-300 border border-purple-500/30"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right column - 1/3 width */}
                <div className="space-y-4">
                  {/* Information Panel */}
                  <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                    <div className="flex items-center gap-2 text-purple-400 mb-4">
                      <Info className="h-5 w-5" />
                      <h3 className="font-semibold">Information</h3>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400 text-sm">Author:</span>
                        <span className="font-medium text-sm">{method.author}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400 text-sm">Category:</span>
                        <Badge className={`${getCategoryColor(method.category)}`}>{method.category}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400 text-sm">Difficulty:</span>
                        <Badge className={`${getDifficultyColor(method.difficulty)}`}>{method.difficulty}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400 text-sm">Last Updated:</span>
                        <span className="text-sm">{method.lastUpdated || "Unknown"}</span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white flex items-center justify-center gap-2 h-10">
                      <Video className="h-4 w-4" />
                      Watch Video Tutorial
                    </Button>

                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center gap-2 h-10">
                      <Download className="h-4 w-4" />
                      Download Method
                    </Button>

                    <Button className="w-full bg-gray-800 hover:bg-gray-700 text-white flex items-center justify-center gap-2 h-10">
                      <Share2 className="h-4 w-4" />
                      Share Method
                    </Button>
                  </div>

                  {/* Features */}
                  <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                    <div className="flex items-center gap-2 text-purple-400 mb-2">
                      <Sparkles className="h-5 w-5" />
                      <h3 className="font-semibold">Key Features</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-gray-300">
                      {method.features.slice(0, 5).map((feature: string, index: number) => (
                        <li key={index} className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-purple-400 mt-0.5 min-w-[16px]" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="tutorial" className="p-0 m-0">
              <div className="p-4 space-y-6">
                <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                  <div className="flex items-center gap-2 text-purple-400 mb-4">
                    <BookOpen className="h-5 w-5" />
                    <h3 className="font-semibold text-lg">{method.name} Tutorial</h3>
                  </div>
                  <p className="text-gray-300 text-sm mb-4">{method.description}</p>

                  {/* Steps */}
                  <div className="space-y-6 mt-6 relative">
                    {/* Vertical line connecting steps */}
                    <div className="absolute left-[19px] top-[30px] bottom-6 w-0.5 bg-gradient-to-b from-purple-600 to-purple-900/30 z-0"></div>

                    {method.steps.map((step: any, index: number) => (
                      <div
                        key={index}
                        className="border border-purple-900/30 rounded-md p-4 bg-gradient-to-br from-black/40 to-purple-900/10 hover:from-black/50 hover:to-purple-900/20 transition-colors relative z-10"
                      >
                        <div className="flex items-center gap-3 mb-3">
                          <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-full w-7 h-7 flex items-center justify-center text-white font-bold text-sm shadow-lg shadow-purple-900/20">
                            {index + 1}
                          </div>
                          <h3 className="font-semibold text-white text-lg">{step.title}</h3>
                        </div>
                        <ul className="space-y-3 pl-10">
                          {step.instructions &&
                            step.instructions.map((instruction: string, i: number) => (
                              <li
                                key={i}
                                className="flex items-start gap-2 text-sm text-gray-300 hover:text-white transition-colors group"
                              >
                                <CheckCircle2 className="h-4 w-4 text-purple-400 group-hover:text-purple-300 mt-0.5 min-w-[16px] transition-colors" />
                                <span>{instruction}</span>
                              </li>
                            ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Video Tutorial Section */}
                <div className="border border-purple-900/50 rounded-md p-4 bg-gradient-to-br from-black/40 to-purple-900/10">
                  <div className="flex items-center gap-2 text-purple-400 mb-4">
                    <Video className="h-5 w-5" />
                    <h3 className="font-semibold text-lg">Video Tutorials</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="border border-purple-900/30 rounded-md overflow-hidden relative group">
                      {/* Thumbnail with play button overlay */}
                      <div className="relative h-24 bg-gradient-to-r from-purple-900/40 to-black/60 flex items-center justify-center">
                        <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-colors"></div>
                        <div className="w-12 h-12 rounded-full bg-purple-600/80 group-hover:bg-purple-600 flex items-center justify-center transition-colors z-10">
                          <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-white border-b-[8px] border-b-transparent ml-1"></div>
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-0.5 rounded text-xs text-white">
                          10:24
                        </div>
                      </div>

                      <div className="p-3 bg-black/20 group-hover:bg-black/40 transition-colors">
                        <h4 className="font-medium text-sm group-hover:text-purple-400 transition-colors">
                          {method.name} Beginner Tutorial
                        </h4>
                        <p className="text-xs text-gray-400">Step-by-step guide for beginners</p>
                      </div>
                    </div>

                    <div className="border border-purple-900/30 rounded-md overflow-hidden relative group">
                      {/* Thumbnail with play button overlay */}
                      <div className="relative h-24 bg-gradient-to-r from-purple-900/40 to-black/60 flex items-center justify-center">
                        <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-colors"></div>
                        <div className="w-12 h-12 rounded-full bg-purple-600/80 group-hover:bg-purple-600 flex items-center justify-center transition-colors z-10">
                          <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-white border-b-[8px] border-b-transparent ml-1"></div>
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-0.5 rounded text-xs text-white">
                          15:37
                        </div>
                      </div>

                      <div className="p-3 bg-black/20 group-hover:bg-black/40 transition-colors">
                        <h4 className="font-medium text-sm group-hover:text-purple-400 transition-colors">
                          {method.name} Advanced Techniques
                        </h4>
                        <p className="text-xs text-gray-400">Advanced strategies and tips</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="tips" className="p-0 m-0">
              <div className="p-4 space-y-6">
                {/* Important Tips */}
                <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                  <div className="flex items-center gap-2 text-yellow-400 mb-4">
                    <Sparkles className="h-5 w-5" />
                    <h3 className="font-semibold text-lg">Important Tips</h3>
                  </div>
                  <ul className="space-y-3">
                    {method.tips.map((tip: string, index: number) => (
                      <li
                        key={index}
                        className="flex items-start gap-3 bg-yellow-900/10 border border-yellow-500/20 rounded-md p-3"
                      >
                        <Sparkles className="h-5 w-5 text-yellow-400 mt-0.5 min-w-[20px]" />
                        <span className="text-sm text-gray-300">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Warnings */}
                <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                  <div className="flex items-center gap-2 text-red-400 mb-4">
                    <AlertTriangle className="h-5 w-5" />
                    <h3 className="font-semibold text-lg">Warnings</h3>
                  </div>
                  <ul className="space-y-3">
                    {method.warnings.map((warning: string, index: number) => (
                      <li
                        key={index}
                        className="flex items-start gap-3 bg-red-900/10 border border-red-500/20 rounded-md p-3"
                      >
                        <AlertTriangle className="h-5 w-5 text-red-400 mt-0.5 min-w-[20px]" />
                        <span className="text-sm text-gray-300">{warning}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Success Stories */}
                <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                  <div className="flex items-center gap-2 text-green-400 mb-4">
                    <ThumbsUp className="h-5 w-5" />
                    <h3 className="font-semibold text-lg">Success Stories</h3>
                  </div>

                  <div className="space-y-3">
                    <div className="bg-green-900/10 border border-green-500/20 rounded-md p-3">
                      <div className="flex items-start gap-3">
                        <div className="bg-green-900/30 rounded-full p-1.5 mt-0.5">
                          <MessageCircle className="h-3 w-3 text-green-400" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-green-400">Anonymous</span>
                            <div className="flex items-center">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                              ))}
                            </div>
                          </div>
                          <p className="text-xs text-gray-300 mt-1">
                            "This method worked perfectly! I was able to get several valuable items on my first try. The
                            instructions were clear and easy to follow."
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-green-900/10 border border-green-500/20 rounded-md p-3">
                      <div className="flex items-start gap-3">
                        <div className="bg-green-900/30 rounded-full p-1.5 mt-0.5">
                          <MessageCircle className="h-3 w-3 text-green-400" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-green-400">User123</span>
                            <div className="flex items-center">
                              {[...Array(4)].map((_, i) => (
                                <Star key={i} className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                              ))}
                              <Star className="w-3 h-3 text-yellow-400" />
                            </div>
                          </div>
                          <p className="text-xs text-gray-300 mt-1">
                            "Great method! Took a few attempts to get it right, but once I did, the results were
                            amazing. Definitely worth the effort."
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="related" className="p-0 m-0">
              <div className="p-4 space-y-6">
                <div className="border border-purple-900/50 rounded-md p-4 bg-black/30">
                  <div className="flex items-center gap-2 text-purple-400 mb-4">
                    <BookOpen className="h-5 w-5" />
                    <h3 className="font-semibold text-lg">Related Methods</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Related Method 1 */}
                    <div className="border border-purple-900/30 rounded-md p-3 bg-black/20 hover:bg-black/40 transition-colors cursor-pointer group">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 flex items-center justify-center text-xl bg-gradient-to-br from-purple-900/30 to-black/30 rounded-full border border-purple-500/20">
                          🎮
                        </div>
                        <div>
                          <h4 className="font-medium text-sm group-hover:text-purple-400 transition-colors">
                            Discord Nitro Scam
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-[10px] px-1.5 py-0">
                              Malware
                            </Badge>
                            <div className="flex items-center">
                              {[...Array(4)].map((_, i) => (
                                <Star key={i} className="w-2 h-2 text-yellow-400 fill-yellow-400" />
                              ))}
                              <Star className="w-2 h-2 text-yellow-400" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400 mt-2 line-clamp-2">
                        This method involves creating a fake Discord Nitro gift that actually contains a malicious file.
                      </p>
                    </div>

                    {/* Related Method 2 */}
                    <div className="border border-purple-900/30 rounded-md p-3 bg-black/20 hover:bg-black/40 transition-colors cursor-pointer group">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 flex items-center justify-center text-xl bg-gradient-to-br from-purple-900/30 to-black/30 rounded-full border border-purple-500/20">
                          🍪
                        </div>
                        <div>
                          <h4 className="font-medium text-sm group-hover:text-purple-400 transition-colors">
                            Cookie Logger Method
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[10px] px-1.5 py-0">
                              Technical
                            </Badge>
                            <div className="flex items-center">
                              {[...Array(4)].map((_, i) => (
                                <Star key={i} className="w-2 h-2 text-yellow-400 fill-yellow-400" />
                              ))}
                              <Star className="w-2 h-2 text-yellow-400" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400 mt-2 line-clamp-2">
                        This method involves creating a fake Roblox login page that steals the user's authentication
                        cookies.
                      </p>
                    </div>

                    {/* Related Method 3 */}
                    <div className="border border-purple-900/30 rounded-md p-3 bg-black/20 hover:bg-black/40 transition-colors cursor-pointer group">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 flex items-center justify-center text-xl bg-gradient-to-br from-purple-900/30 to-black/30 rounded-full border border-purple-500/20">
                          💎
                        </div>
                        <div>
                          <h4 className="font-medium text-sm group-hover:text-purple-400 transition-colors">
                            Fake Robux Giveaway
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30 text-[10px] px-1.5 py-0">
                              Phishing
                            </Badge>
                            <div className="flex items-center">
                              {[...Array(3)].map((_, i) => (
                                <Star key={i} className="w-2 h-2 text-yellow-400 fill-yellow-400" />
                              ))}
                              {[...Array(2)].map((_, i) => (
                                <Star key={i} className="w-2 h-2 text-yellow-400" />
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400 mt-2 line-clamp-2">
                        This method involves creating a fake Robux giveaway website that requires users to enter their
                        Roblox credentials.
                      </p>
                    </div>

                    {/* Related Method 4 */}
                    <div className="border border-purple-900/30 rounded-md p-3 bg-black/20 hover:bg-black/40 transition-colors cursor-pointer group">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 flex items-center justify-center text-xl bg-gradient-to-br from-purple-900/30 to-black/30 rounded-full border border-purple-500/20">
                          🎮
                        </div>
                        <div>
                          <h4 className="font-medium text-sm group-hover:text-purple-400 transition-colors">
                            Fake Game Developer Scam
                          </h4>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-[10px] px-1.5 py-0">
                              Social
                            </Badge>
                            <div className="flex items-center">
                              {[...Array(4)].map((_, i) => (
                                <Star key={i} className="w-2 h-2 text-yellow-400 fill-yellow-400" />
                              ))}
                              <Star className="w-2 h-2 text-yellow-400" />
                            </div>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-400 mt-2 line-clamp-2">
                        This method involves posing as a Roblox game developer looking to hire staff or collaborate.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
