"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import {
  ArrowLeft,
  Search,
  Filter,
  X,
  ChevronDown,
  Star,
  Download,
  ExternalLink,
  Info,
  Code,
  Sparkles,
  Shield,
  Check,
  Users,
  MessageCircle,
  AlertTriangle,
  Award,
  Zap,
  Lock,
  TrendingUp,
  SlidersHorizontal,
  Clock,
  BookOpen,
  Printer,
  Share2,
  BarChart3,
} from "lucide-react"
import { useMediaQuery } from "../hooks/use-media-query"
import { MethodDetail } from "./method-detail"

// Custom scrollbar styles
const scrollbarStyles = `
  .custom-scrollbar::-webkit-scrollbar {
    width: 8px;
  }
  .custom-scrollbar::-webkit-scrollbar-track {
    background: rgba(139, 92, 246, 0.1);
    border-radius: 10px;
  }
  .custom-scrollbar::-webkit-scrollbar-thumb {
    background: rgba(139, 92, 246, 0.3);
    border-radius: 10px;
  }
  .custom-scrollbar::-webkit-scrollbar-thumb:hover {
    background: rgba(139, 92, 246, 0.5);
  }
`

// Define method types and interfaces
type MethodCategory = "social" | "technical" | "discord" | "tiktok" | "malware" | "phishing" | "all"
type MethodDifficulty = "beginner" | "intermediate" | "advanced" | "all"

interface BeamingMethod {
  id: string
  name: string
  description: string
  category: MethodCategory
  difficulty: MethodDifficulty
  features: string[]
  instructions?: string
  downloads: number
  rating: number
  isNew?: boolean
  isPopular?: boolean
  lastUpdated: string
  author?: string
  tags: string[]
  effectiveness?: number // 1-5 scale
  tutorialUrl?: string
  successRate?: string
  detailedTutorial?: {
    howItWorks?: string
    requirements?: string[]
    steps?: {
      title: string
      content: string[]
    }[]
    tips?: string[]
    warnings?: string[]
    credits?: string
  }
  emoji?: string // Added emoji property for method icons
  discordServer?: {
    name: string
    url: string
  }
  discordServers?: {
    name: string
    url: string
    tier: "official" | "top" | "high" | "medium" | "specialized"
    description: string
    members?: string
    activity?: "Very High" | "High" | "Medium" | "Low"
  }[]
}

export default function BeamingMethodsPage() {
  // Add custom scrollbar styles
  useEffect(() => {
    const style = document.createElement("style")
    style.textContent = scrollbarStyles
    document.head.appendChild(style)

    return () => {
      document.head.removeChild(style)
    }
  }, [])

  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<MethodCategory>("all")
  const [selectedDifficulty, setSelectedDifficulty] = useState<MethodDifficulty>("all")
  const [sortBy, setSortBy] = useState<"popular" | "newest" | "rating" | "effectiveness">("effectiveness")
  const [isFilterOpen, setIsFilterOpen] = useState(false)
  const [selectedMethod, setSelectedMethod] = useState<BeamingMethod | null>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const isMobile = useMediaQuery("(max-width: 640px)")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  // Canvas background effect with mixed white and purple particles
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    try {
      const updateSize = () => {
        canvas.width = window.innerWidth
        canvas.height = document.documentElement.scrollHeight
      }
      updateSize()
      window.addEventListener("resize", updateSize)

      // Create an observer to update canvas height when content changes
      const resizeObserver = new ResizeObserver(() => {
        if (canvas) {
          canvas.height = Math.max(window.innerHeight, document.documentElement.scrollHeight)
        }
      })
      resizeObserver.observe(document.body)

      const particles: { x: number; y: number; speed: number; size: number; opacity: number; color: string }[] = []
      const particleCount = isMobile ? 80 : 160

      for (let i = 0; i < particleCount; i++) {
        // 50% white, 50% purple particles
        const color = Math.random() > 0.5 ? "rgba(255, 255, 255," : "rgba(139, 92, 246,"

        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          speed: 0.2 + Math.random() * 0.3,
          size: 0.5 + Math.random() * 1.5,
          opacity: 0.3 + Math.random() * 0.7,
          color: color,
        })
      }

      let animationFrameId: number

      function animate() {
        if (!ctx || !canvas) return

        ctx.clearRect(0, 0, canvas.width, canvas.height)

        particles.forEach((particle) => {
          ctx.fillStyle = `${particle.color} ${particle.opacity})`
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()

          particle.y += particle.speed
          if (particle.y > canvas.height) {
            particle.y = 0
            particle.x = Math.random() * canvas.width
          }
        })

        animationFrameId = requestAnimationFrame(animate)
      }

      animate()
      setIsLoaded(true)

      return () => {
        window.removeEventListener("resize", updateSize)
        resizeObserver.disconnect()
        cancelAnimationFrame(animationFrameId)
      }
    } catch (error) {
      console.error("Canvas error:", error)
      setIsLoaded(true) // Ensure the site loads even if canvas fails
    }
  }, [isMobile])

  // Enhanced beaming methods data
  const beamingMethods: BeamingMethod[] = [
    {
      id: "dualhook-method",
      name: "Dualhook Method (OP)",
      description:
        "The most powerful dual-hook implementation with exceptional success rates. This advanced method combines multiple authentication bypass techniques and cookie extraction for maximum effectiveness.",
      category: "technical",
      difficulty: "advanced",
      features: [
        "Dual-layer authentication bypass",
        "Improved cookie handling",
        "Automatic session management",
        "Enhanced success tracking",
        "Anti-detection mechanisms",
        "Rapid deployment",
      ],
      instructions:
        "Implement this method by setting up the dual-hook system as described in the detailed guide. Ensure you follow all steps precisely for optimal results. Test thoroughly before deployment.",
      downloads: 9245,
      rating: 4.9,
      isNew: false,
      isPopular: true,
      lastUpdated: "2025-04-10",
      author: "SecurityMaster",
      tags: ["hook", "authentication", "session", "op"],
      effectiveness: 5,
      successRate: "85-90%",
      tutorialUrl: "https://justpaste.it/ijrsc",
      emoji: "⚡️", // Lightning bolt for technical method
    },
    {
      id: "tiktok-method",
      name: "TikTok Method (OP)",
      description:
        "Leverage TikTok's massive platform to deploy highly effective beaming strategies. This method has one of the highest success rates due to its social engineering approach combined with TikTok's algorithm.",
      category: "tiktok",
      difficulty: "intermediate",
      features: [
        "TikTok platform integration",
        "Social proof mechanisms",
        "Viral distribution potential",
        "Automated engagement tracking",
        "Custom TikTok styling options",
        "Multi-platform compatibility",
      ],
      instructions:
        "Set up the TikTok integration as detailed in the guide. Configure the social parameters and follow the deployment steps carefully. Monitor engagement metrics for optimal results.",
      downloads: 10389,
      rating: 4.8,
      isNew: true,
      isPopular: true,
      lastUpdated: "2025-04-15",
      author: "SocialMediaPro",
      tags: ["tiktok", "social", "viral", "op"],
      effectiveness: 5,
      successRate: "80-95%",
      tutorialUrl: "https://justpaste.it/ihr2g",
      emoji: "🔥", // Fire emoji for viral method
      detailedTutorial: {
        howItWorks:
          "You go live on TikTok using a fake Roblox giveaway video, and try to get as many viewers as possible. You will have a fake link in your TikTok bio so you get accounts.",
        requirements: [
          "For PC live you need TikTok account with live studio access",
          "For mobile live you need TikTok account with mobile gaming live access",
          "Also this method needs some brain, can't be a retard",
        ],
        steps: [
          {
            title: "How to get TikTok live account",
            content: [
              "Go to Roblox crosstrading server and trade for one",
              "Use this follower botting service, to bot 1k followers only for 2$ https://yoursmm.net/",
              "Or use this method to easily get 1k followers in 3 days or less https://justpaste.it/follow-method",
            ],
          },
          {
            title: "Choosing fake link",
            content: [
              "Go to Variares sites and then pick one of the TikTok links",
              "Always remember to test the link before going live",
              "If link is flagged then try removing the www. or https: from the link",
              "Using Beacons.ai > you can make beacons.ai biolink to make it look more realistic",
              "Example: https://beacons.ai/joinadoptme you can take inspiration and then add it to your TikTok bio",
              "If you can't add link to TikTok bio then make your TikTok account into business account so you can add business link",
            ],
          },
          {
            title: "How to go live/loop video",
            content: [
              "On PC you have to download live studio and then set it up then just pick a good video and go live",
              "On mobile you have to loop the video from gallery settings at least on Android",
            ],
          },
          {
            title: "Picking game category and title",
            content: [
              "If you're on mobile then your live game category MUST be Subway Surfers or Clash Royale. On PC it can be Roblox",
              "Title can be probably anything but be careful with words like Free and Giveaway since TikTok doesn't always like them",
            ],
          },
          {
            title: "How long to be live for",
            content: [
              "Never be live for a lot of hours UNLESS your live is stable asf. Like having about hundred viewers or more for hours",
              "When you start live you should do it only for 20 mins and then check to if end the live or not",
              "If after 20 mins your viewers are Below 10 then end your live",
              "If they're above 10 then there's small chance of going viral",
              "Above 20 viewers = good chance to go viral",
              "Above 40 viewers is very good keep it up until they start dropping!!",
            ],
          },
          {
            title: "Pumping method",
            content: [
              "This is a method to TikTok Live grow viewers",
              "Basically just go live until viewers grow and when they drop by a bit just end the live immediately",
              "Then start live almost immediately again and repeat this until you have stable asf live with hundreds of viewers!!!",
            ],
          },
        ],
        tips: [
          "When you go live ALWAYS remember to Mute your mic (check tutorial on YT how to)",
          "Put notifications off",
          "Remember to blacklist bad words",
        ],
        warnings: [
          "Be careful with TikTok's content policies to avoid account bans",
          "Don't use the same account for too long to avoid detection",
        ],
        credits: "Credit dxfc",
      },
    },
    {
      id: "adoptme-method",
      name: "Adopt Me Method",
      description:
        "Specialized method targeting Adopt Me players with customized approaches. This method uses game-specific incentives to increase engagement and success rates by exploiting the desire for rare pets.",
      category: "social",
      difficulty: "beginner",
      features: [
        "Game-specific targeting",
        "Custom incentive system",
        "Adopt Me asset integration",
        "Pet-based lure mechanisms",
        "In-game currency simulation",
        "Automated response handling",
      ],
      instructions:
        "Configure the Adopt Me method using the provided templates. Customize the incentives based on current game trends and target demographics. Deploy through recommended channels.",
      downloads: 8876,
      rating: 4.5,
      isNew: false,
      isPopular: true,
      lastUpdated: "2025-03-20",
      author: "GameMaster",
      tags: ["adopt me", "game", "pets"],
      effectiveness: 4,
      successRate: "70-80%",
      tutorialUrl: "https://justpaste.it/gu2o5",
      emoji: "🎮", // Game controller for game-specific method
      detailedTutorial: {
        howItWorks:
          "This method targets Adopt Me players by offering a 'Pick a Door Challenge' with rewards. You'll invite players to join your private server through a link, which is actually your beaming link.",
        requirements: [
          "Access to Adopt Me game servers",
          "A convincing private server link (your beaming link)",
          "Basic social engineering skills",
          "Patience to find the right targets",
        ],
        steps: [
          {
            title: "Finding Adopt Me servers",
            content: [
              "Join popular Adopt Me servers where you can find active players",
              "Look for servers with newer players who might be less experienced and more trusting",
              "Target servers during peak hours for maximum reach",
              "Switch servers frequently to avoid detection or reports",
            ],
          },
          {
            title: "Creating the challenge invitation",
            content: [
              'Type in the server chat: "Doing pick a door challenge for 10 people only, DM me fast"',
              "Make it sound exclusive and time-limited to create urgency",
              "Be friendly and enthusiastic in your messages",
              "If someone asks what the rewards are, mention rare pets or in-game currency",
            ],
          },
          {
            title: "Directing targets to your link",
            content: [
              "When they message you, tell them to join through your private server link",
              "Mention that your join option is enabled for convenience",
              "If they ask to add you as a friend instead, explain that you can't add people due to parental controls",
              "Emphasize this is why you need to send them a link instead",
              "Present the link as the only way to participate in the exclusive challenge",
            ],
          },
          {
            title: "Handling the outcome",
            content: [
              "If successful, you'll receive their account credentials through your beaming link",
              "If unsuccessful, simply move on to the next potential target",
              "Don't waste time trying to convince hesitant players",
              "Focus on quantity and efficiency to maximize your success rate",
            ],
          },
        ],
        tips: [
          "Be patient and don't rush the process",
          "Act natural and friendly to build trust quickly",
          "Use proper grammar and spelling to appear legitimate",
          "Change your avatar occasionally to avoid being recognized",
          "Target players who seem eager for rare items or currency",
        ],
        warnings: [
          "Don't spam the same server repeatedly",
          "Avoid using the same account for too long",
          "Be aware that experienced players may recognize this as a scam",
          "Don't get frustrated if success rate isn't high initially - it improves with practice",
        ],
      },
    },
    {
      id: "fake-friend-method",
      name: "Fake Friend Method",
      description:
        "Social engineering approach that establishes trust through simulated friendship. Particularly effective for targeted operations requiring personalized approaches.",
      category: "social",
      difficulty: "intermediate",
      features: [
        "Trust building mechanisms",
        "Personalized engagement",
        "Long-term strategy",
        "Psychological triggers",
        "Conversation templates",
        "Relationship development framework",
      ],
      instructions:
        "Follow the detailed social engineering guide to implement the Fake Friend method. Customize approaches based on target profiles and adapt strategies as relationships develop.",
      downloads: 8432,
      rating: 4.6,
      isNew: false,
      isPopular: false,
      lastUpdated: "2025-02-15",
      author: "SocialEngineer",
      tags: ["social", "friendship", "trust"],
      effectiveness: 4,
      successRate: "65-75%",
      tutorialUrl: "https://justpaste.it/igqzr",
      emoji: "👥", // People emoji for social engineering
      detailedTutorial: {
        howItWorks:
          "This advanced social engineering method involves using an already compromised Roblox account to target the victim's friends list. By impersonating someone they already trust, you can convince them to click malicious links or share sensitive information. This method has an exceptionally high success rate because it exploits pre-established trust relationships.",
        requirements: [
          "Access to a previously beamed Roblox account (ABSOLUTELY REQUIRED)",
          "Strong social engineering skills and ability to mimic the original account owner's communication style",
          "Discord account for off-platform communication",
          "Patience and attention to detail to maintain the deception",
          "Understanding of relationship dynamics and manipulation techniques",
          "Prepared beaming link disguised as something relevant to your conversation",
        ],
        steps: [
          {
            title: "STEP 1: U HAVE TO BE IN AN ACCOUNT YOU'VE ALREADY BEAMED",
            content: [
              "Log into the previously beamed account and familiarize yourself with their friends list",
              "Check their chat history to understand how they typically communicate with friends",
              "Review their inventory to know what valuable items they have that might interest friends",
              "Look at their recent games and activity to understand their interests and habits",
              "Take note of any inside jokes or specific language they use with friends",
              "Spend time learning about the account's social connections before making any moves",
            ],
          },
          {
            title: "STEP 2: IF YOU SEE A RICH FRIEND IN GAME JOIN THEM, OR TEXT PEOPLE FROM THEIR CHAT",
            content: [
              "Identify the richest or most vulnerable friends from the account's friend list",
              "Join them in-game if you see them online to establish initial contact",
              "Alternatively, message people directly from the account's existing chat history",
              "Start with casual conversation that matches the original account owner's style",
              "Make sure to use similar greeting styles, emojis, and slang that the original account owner would use",
              "If they ask why you haven't been online, have a believable excuse ready (like 'I was grounded' or 'My internet was down')",
            ],
          },
          {
            title: "STEP 3: Tell them to add your new discord. WAYS OF SAYING DISCORD WITHOUT TAG",
            content: [
              "Tell them you have a 'new' Discord account and need them to add you",
              "Use creative spelling to avoid detection by Roblox chat filters",
              "Alternative ways to spell Discord: 'ÐČ', 'Ðǐșćöřð', 'ćöřð', 'Ðïșćô'",
              "Provide a believable reason for having a new Discord (e.g., 'My old one got hacked' or 'I got locked out')",
              "If they ask why you need Discord, say it's for something important you can't explain in Roblox chat",
              "Make sure your Discord profile matches the theme/style of the compromised Roblox account",
            ],
          },
          {
            title:
              "STEP 4: ONCE YOUVE GOTTEN THEM TO ADD U, SAY THE REASON I WANTED YOU TO ADD ME IS BECAUSE IM DOING THIS GIVEAWAY (TRY TO FIND OUT WHAT THEY PLAY) AND IF THEY WANTED TO JOIN",
            content: [
              "Once they've added you on Discord, explain you're hosting an exclusive giveaway",
              "Ask what games they play most frequently to tailor your approach",
              "Offer prizes related to their favorite games to increase interest",
              "Make the giveaway sound exclusive and time-limited to create urgency",
              "Tell them you're only inviting close friends to make them feel special",
              "Show excitement about them potentially winning to build anticipation",
              "If they seem hesitant, emphasize how much you want them specifically to participate",
            ],
          },
          {
            title: "STEP 5: TELL THEM YOU HAVE CURRENTLY PPL, THEN SEND THE LINK",
            content: [
              "Create a sense of urgency by saying you already have several people participating",
              "Mention that spots are filling up quickly to pressure them into acting fast",
              "Send them your beaming link disguised as a giveaway entry form or special server invite",
              "If they question the link, reassure them it's safe and that other friends have already joined",
              "Follow up immediately asking if they clicked it to maintain engagement",
              "If they seem suspicious, have a backup story ready to explain the link",
              "Once they click the link and you gain access to their account, act quickly to secure valuable items",
            ],
          },
        ],
        tips: [
          "Study the original account owner's typing style and try to mimic it perfectly",
          "Be patient and don't rush the conversation - building trust takes time",
          "If they seem suspicious, back off and try a different approach or target",
          "Keep conversations focused on the games they play to maintain authenticity",
          "Have a believable story prepared for why you need them to click your link",
          "Don't be too aggressive or you'll raise suspicion - subtle manipulation works best",
          "If one friend doesn't work out, move on to another rather than pushing too hard",
          "Remember details about their previous conversations to maintain the illusion",
        ],
        warnings: [
          "Don't be too aggressive or you'll raise suspicion",
          "Avoid using the same compromised account for too long",
          "Be aware that friends of the original account owner might communicate outside of Roblox",
          "This method requires good social skills and adaptability",
          "Success rates vary greatly depending on your ability to build trust",
          "Some targets may verify your identity through voice chat or other means",
          "The original account owner might try to recover their account while you're using it",
          "Friends may become suspicious if you don't know inside jokes or shared experiences",
        ],
        credits: "Method compiled by PoepBeamz Team",
      },
    },
    {
      id: "condo-method",
      name: "Condo Method",
      description:
        "Specialized method utilizing condo game communities to target specific demographics. This approach leverages Discord servers dedicated to condo games for highly effective social engineering.",
      category: "social",
      difficulty: "intermediate",
      features: [
        "Discord server targeting",
        "Egirl profile utilization",
        "Private server simulation",
        "Demographic-specific tactics",
        "Multi-platform compatibility",
        "High conversion potential",
      ],
      instructions:
        "Implement the Condo method following the detailed guide. Configure your approach based on target demographics and deploy through recommended Discord channels. Monitor engagement for optimal results.",
      downloads: 7689,
      rating: 4.4,
      isNew: true,
      isPopular: false,
      lastUpdated: "2025-03-28",
      author: "GameExpert",
      tags: ["condo", "discord", "social"],
      effectiveness: 4,
      successRate: "65-80%",
      tutorialUrl: "https://justpaste.it/amvi1",
      emoji: "💬", // Chat bubble for Discord-based method
      detailedTutorial: {
        howItWorks:
          "Specialized method utilizing condo game communities to target specific demographics. This approach leverages Discord servers dedicated to condo games for highly effective social engineering.",
        requirements: [
          "Discord account with an egirl profile",
          "Access to condo game Discord servers",
          "Basic social engineering skills",
          "A fake private server link",
        ],
        steps: [
          {
            title: "Find a Condo Games Discord Server",
            content: ["Locate a Discord server dedicated to condo games."],
          },
          {
            title: "Advertise Your Own Server",
            content: [
              "In both the main chat and the 'List Your Condo' channel, post a message saying you've created your own server and ask if anyone wants to play with you.",
              "Make sure you're using an egirl profile for better results.",
            ],
          },
          {
            title: "Invite Interested Players",
            content: [
              "When people send you a direct message, instruct them to join your private FAKE server by providing them with its invite link.",
            ],
          },
          {
            title: "Choose a Suitable Game",
            content: ["For your private server, you can use any random game that typically accommodates 2-15 players."],
          },
          {
            title: "Know Your Audience",
            content: [
              "Generally, the players in condo game servers tend to be either kids at puberty or adults with lots of robux who spend most of their time on the computer.",
            ],
          },
        ],
        tips: [
          "Use an attractive avatar to increase interest",
          "Be responsive and friendly in your messages",
          "Create urgency by saying your server is 'filling up fast'",
          "Target users who seem eager to join private servers",
        ],
        warnings: [
          "Discord monitors suspicious activity, so don't use the same account for too long",
          "Some users may be suspicious of new servers, be prepared for questions",
          "Don't be too aggressive or obvious in your approach",
        ],
      },
    },
    {
      id: "phishing-pro-method",
      name: "Phishing Pro Method",
      description:
        "Enhanced phishing methodology with advanced templates and authentication simulation. Features realistic interfaces and security bypass mechanisms that can fool even security-conscious users.",
      category: "technical",
      difficulty: "intermediate",
      features: [
        "Premium templates",
        "Authentication simulation",
        "Security badge emulation",
        "Mobile-responsive design",
        "Custom domain integration",
        "Analytics dashboard",
      ],
      instructions:
        "Deploy the Phishing Pro method using the provided templates. Customize interfaces based on target platforms and configure tracking parameters for performance monitoring.",
      downloads: 8756,
      rating: 4.5,
      isNew: true,
      isPopular: true,
      lastUpdated: "2025-04-01",
      author: "PhishingExpert",
      tags: ["phishing", "templates", "authentication"],
      effectiveness: 4,
      successRate: "70-80%",
      emoji: "🔒", // Lock for security-related method
    },
    {
      id: "paypal-method",
      name: "PayPal Method",
      description:
        "Advanced social engineering technique targeting Roblox traders who accept PayPal payments. This method exploits password reset mechanisms to gain account access during payment verification.",
      category: "social",
      difficulty: "advanced",
      features: [
        "PayPal payment simulation",
        "Password reset exploitation",
        "Screen sharing manipulation",
        "Social engineering tactics",
        "Trade hangout targeting",
        "Quick execution framework",
      ],
      instructions:
        "Follow the detailed guide to implement the PayPal method. Target trade hangout users, establish trust through realistic offers, and execute the password reset technique during payment verification.",
      downloads: 9756,
      rating: 4.7,
      isNew: true,
      isPopular: true,
      lastUpdated: "2025-04-12",
      author: "TradeExpert",
      tags: ["paypal", "trading", "social", "advanced"],
      effectiveness: 5,
      successRate: "75-85%",
      tutorialUrl: "https://justpaste.it/paypal-method",
      emoji: "💰", // Money bag for payment-related method
      detailedTutorial: {
        howItWorks:
          "This method targets Roblox users who accept PayPal payments for in-game items. By pretending to send payment and then manipulating them into checking their email during a screen share, you can capture their password reset link and gain access to their account. This is one of the most effective methods for obtaining high-value accounts with limited items.",
        requirements: [
          "PayPal account (doesn't need to have funds)",
          "Discord or Skype for screen sharing",
          "Basic social engineering skills",
          "Screenshot tool (like Snipping Tool or Lightshot)",
          "Quick reflexes and attention to detail",
          "Image editing software for zooming into screenshots",
          "Understanding of Roblox's password reset process",
          "Ability to remain calm under pressure",
        ],
        steps: [
          {
            title: "Finding targets in Trade Hangout",
            content: [
              "Go to Trade Hangout in Roblox",
              "Walk around the game saying 'Who here does PayPal deals?' (if someone there does they will know what you mean)",
              "Look for players with Premium badges and valuable limited items",
              "Once you find someone, give them a realistic offer for ONE of their items",
              "Make sure your offer is slightly above market value to increase interest",
              "When they agree on some price, get their Discord/Skype",
              "Be professional and confident throughout the interaction to build trust",
              "If they seem experienced or suspicious, move on to another target",
            ],
          },
          {
            title: "Setting up the payment deception",
            content: [
              "Go on Discord/Skype and ask them for their PayPal email",
              "Double-check the email to ensure you have the correct address",
              "Once they give it to you, wait about a minute and say 'sent'",
              "They should check and tell you they never got it",
              "Call them a scammer and argue until they believe you might have actually sent it or they think there was a PayPal error",
              "Act genuinely confused and concerned about the missing payment",
              "Suggest that PayPal might be having issues or the payment is delayed",
              "Tell them to share their screen on PayPal to prove they didn't receive it",
              "If they refuse to share their screen, increase the pressure by accusing them of scamming",
            ],
          },
          {
            title: "Executing the password reset attack",
            content: [
              "Once they show their screen and you can see it's not there, open up a new Roblox tab",
              "Copy their Roblox username",
              "Go to the password reset URL (https://www.roblox.com/Login/ResetPasswordRequest.aspx)",
              "Paste their Roblox username in and spam the click password reset button until it says 'Too many failed requests attempts. try your request again later'",
              "Send at least 5-10 password reset requests to ensure multiple emails are sent",
              "Go back to Discord/Skype and tell them to check their email to see if they got a PayPal notification there",
              "Act concerned and suggest that PayPal sometimes sends email notifications instead of showing in the dashboard",
              "Maintain the conversation to keep them engaged and less suspicious",
            ],
          },
          {
            title: "Capturing the reset link",
            content: [
              "When they go to their email, they should notice all of the password reset links",
              "QUICKLY using Snipping Tool or some other screenshot method, screenshot the call while they are inside the Roblox email",
              "Make sure your screenshot captures the entire screen with the reset link visible",
              "Open it in some picture editing program and zoom in to see the password reset URL",
              "CAREFULLY copy the exact URL into a new tab in your browser",
              "The URL will look something like: https://www.roblox.com/login/reset-password?ticket=LONG_CODE_HERE",
              "Change their password and quickly log in",
              "Choose a password that's difficult to guess but easy for you to remember",
            ],
          },
          {
            title: "Securing the items",
            content: [
              "Send yourself a trade of all their good items for your bad ones",
              "Prioritize limited items and items with high RAP (Recent Average Price)",
              "If they have a PIN, try common combinations like 1234, 0000, or their birth year",
              "Check if they have any Robux in the account and purchase your own items at inflated prices",
              "Look for group funds that can be transferred",
              "Quickly log out and go back to your account",
              "Accept the trade immediately",
              "End the Discord/Skype call and block the other person",
              "Consider changing the email on the account if possible to prevent recovery",
            ],
          },
        ],
        tips: [
          "Target users with Premium badges as they're more likely to have valuable items",
          "Practice your story and responses beforehand to sound natural",
          "Have a believable PayPal error explanation ready",
          "Act quickly during the password reset phase - timing is critical",
          "Be prepared to abandon the attempt if they seem suspicious or tech-savvy",
          "Use a different PayPal email than your main account for safety",
          "Consider using a VPN to protect your identity",
          "Have multiple screenshot tools ready in case one fails",
          "Practice zooming and copying text from screenshots beforehand",
          "If they have 2FA enabled, this method may not work - be prepared to move on",
        ],
        warnings: [
          "This method has legal consequences if caught",
          "Victims may record calls as evidence",
          "Experienced traders may recognize this scam",
          "Roblox monitors unusual trading patterns",
          "Account security features like 2FA can prevent this method from working",
          "PayPal may investigate fraudulent activity reports",
          "Your Discord or Skype account could be reported and banned",
          "Some victims may try to track you down through PayPal information",
          "This method leaves a clear trail of evidence",
          "Roblox security team regularly updates their systems to prevent these attacks",
        ],
        credits: "Method compiled by PoepBeamz Team",
      },
    },
    {
      id: "audio-method",
      name: "Audio Method",
      description:
        "Technical approach that exploits browser developer tools to extract authentication cookies through audio file downloads. This method uses social engineering to convince victims to share network traffic data.",
      category: "technical",
      difficulty: "intermediate",
      features: [
        "Browser developer tools exploitation",
        "Cookie extraction technique",
        "HAR file manipulation",
        "Social engineering component",
        "No phishing site required",
        "Cross-platform compatibility",
      ],
      instructions:
        "Implement the Audio Method by following the detailed guide. Establish trust through Robux incentives and guide targets through the technical steps to extract authentication data.",
      downloads: 9245,
      rating: 4.6,
      isNew: true,
      isPopular: false,
      lastUpdated: "2025-04-05",
      author: "TechExploiter",
      tags: ["technical", "cookies", "browser", "developer-tools"],
      effectiveness: 4,
      successRate: "60-75%",
      tutorialUrl: "https://justpaste.it/audio-method",
      emoji: "🎧", // Headphones for audio-related method
      detailedTutorial: {
        howItWorks:
          "This technical method exploits browser developer tools to extract authentication cookies through audio file downloads. By offering Robux as payment for 'helping' with an audio file project, you convince victims to share their network traffic data (HAR files) which contain their Roblox security cookies. This method is particularly effective because it doesn't require victims to enter their passwords directly.",
        requirements: [
          "Discord account with a professional-looking profile",
          "Basic understanding of browser developer tools",
          "Knowledge of how to extract cookies from HAR files",
          "Social engineering skills to build trust and guide victims",
          "Notepad or text editor for examining HAR files",
          "Cookie editor browser extension for importing stolen cookies",
          "Patience to guide technically inexperienced users",
          "Prepared explanations for technical terms",
        ],
        steps: [
          {
            title: "Finding and approaching targets",
            content: [
              "Find potential victims in Roblox games or Discord servers",
              "Target younger users or those who seem less technically knowledgeable",
              "Offer to pay them 2,000 Robux if they help you with a simple task",
              "Tell them you need help with an audio file and add them on Discord",
              "Build trust by being friendly and professional in your communication",
              "Explain that you're working on a project that requires testing audio downloads",
              "Mention that the task is simple and will only take a few minutes",
              "If they seem hesitant, increase the Robux offer to 3,000 or 4,000",
            ],
          },
          {
            title: "Setting up the technical task",
            content: [
              "Send them a link to any random Roblox audio file",
              "Tell them you need them to download the audio file in a special way for a project",
              "Explain that you need to see how the audio loads in different browsers",
              "Instruct them to open the audio page and press Ctrl+Shift+I to open developer tools",
              "If they're on Mac, tell them to press Command+Option+I instead",
              "Guide them to click on the 'Network' tab in the developer tools panel",
              "Tell them to refresh the page while the Network tab is open",
              "Explain that this will record how the audio file loads in their browser",
              "Reassure them this is a standard process used by developers and is completely safe",
            ],
          },
          {
            title: "Extracting the HAR file",
            content: [
              "Instruct them to scroll to the top of the network list where they should see the audio file name",
              "Tell them to right-click anywhere in the network panel and select 'Save all as HAR with content'",
              "If they can't find this option, guide them through the specific steps for their browser",
              "Have them save the file to their computer",
              "Ask them to send you the .HAR file so you can 'extract the audio data properly'",
              "Explain that the HAR file contains technical information about how the audio loaded",
              "Reassure them this is a normal process for audio extraction if they seem hesitant",
              "If they ask what HAR stands for, tell them it's 'HTTP Archive' and is used by developers",
              "Maintain a professional tone throughout to avoid raising suspicion",
            ],
          },
          {
            title: "Obtaining the cookie",
            content: [
              "Once they send the HAR file, open it with Notepad or any text editor",
              "Press Ctrl+F to open the search function and search for 'cookie'",
              "Continue clicking 'Find Next' until you locate their .ROBLOSECURITY cookie",
              "The cookie will be a long string that starts with '_|WARNING:-DO-NOT-SHARE-THIS'",
              "Copy the entire cookie value (it will be a long string)",
              "Use a cookie editor extension to import the cookie into your browser",
              "Navigate to Roblox.com and you should be logged in as the victim",
              "Verify the account access by checking their profile and inventory",
              "Act quickly as cookies can expire or be invalidated if the user logs out",
            ],
          },
          {
            title: "Covering your tracks",
            content: [
              "Tell them you're processing the audio and will send the Robux soon",
              "Keep them engaged by asking questions about the audio quality or other technical details",
              "If possible, transfer valuable items quickly to minimize detection chance",
              "Check for and disable any 2FA or security settings on the account",
              "Change the password if possible to maintain access",
              "Eventually stop responding or block them after securing their items",
              "Consider using an alt account for this method to avoid main account bans",
              "Delete conversations that contain evidence of the scam",
              "Never admit to what you've done if confronted",
            ],
          },
        ],
        tips: [
          "Target users who seem less technically knowledgeable",
          "Be patient and helpful when guiding them through the technical steps",
          "Have screenshots ready to help guide them if they get confused",
          "Offer to increase the Robux amount if they seem hesitant",
          "Act professionally to maintain the illusion of a legitimate task",
          "Use simple language when explaining technical concepts",
          "If they ask too many questions about why you need the HAR file, have prepared answers",
          "Practice extracting cookies from HAR files before attempting this method",
          "Have multiple targets lined up in case some don't cooperate",
          "Consider using a different Discord account for each attempt to avoid being reported",
        ],
        warnings: [
          "Tech-savvy users may recognize this as a cookie-stealing attempt",
          "Some users may have browser extensions that hide cookies in HAR exports",
          "Roblox occasionally changes cookie formats and security measures",
          "This method leaves clear evidence if reported",
          "Discord monitors for suspicious file sharing patterns",
          "Victims may report your Discord account leading to a ban",
          "Roblox security team actively investigates unauthorized access",
          "Cookie authentication may be invalidated if the user changes their password",
          "Some browsers warn users when exporting sensitive data",
          "This method has legal implications as it constitutes unauthorized access",
        ],
        credits: "Method compiled by PoepBeamz Team",
      },
    },
    {
      id: "egirl-method",
      name: "E-girl/E-boy Method",
      description:
        "Long-term social engineering strategy that builds romantic relationships to gain trust and account access. This method exploits emotional connections and trust to obtain credentials or valuable items.",
      category: "social",
      difficulty: "intermediate",
      features: [
        "Relationship building framework",
        "Avatar optimization techniques",
        "Long-term trust development",
        "Psychological manipulation tactics",
        "Target profiling methodology",
        "Premium user targeting",
      ],
      instructions:
        "Implement the E-girl/E-boy method following the detailed relationship building guide. Create an attractive avatar, establish emotional connections, and execute the trust exploitation strategy at the optimal time.",
      downloads: 7689,
      rating: 4.3,
      isNew: false,
      isPopular: true,
      lastUpdated: "2025-03-15",
      author: "SocialMaster",
      tags: ["social", "relationship", "long-term", "trust"],
      effectiveness: 4,
      successRate: "70-85%",
      tutorialUrl: "https://justpaste.it/egirl-method",
      emoji: "✨", // Sparkles for attractive avatar method
      detailedTutorial: {
        howItWorks:
          "This sophisticated long-term social engineering strategy builds romantic relationships to gain trust and account access. By creating an attractive avatar and establishing emotional connections over time, you can manipulate victims into sharing their account information or valuable items. This method has one of the highest success rates but requires significant time investment and psychological manipulation skills.",
        requirements: [
          "Attractive Roblox avatar (gender depends on your target demographic)",
          "Robux for premium clothing and accessories to create an appealing look",
          "Discord account for off-platform communication",
          "Patience for long-term relationship building (days to weeks)",
          "Social engineering and manipulation skills",
          "Understanding of relationship psychology and emotional triggers",
          "Ability to maintain a consistent persona over time",
          "Prepared backstory and personal details for your character",
        ],
        steps: [
          {
            title: "Creating the perfect avatar",
            content: [
              "Make yourself a 'Hot' avatar that will attract your target demographic",
              "For e-girl avatars: Use trendy hair styles, face accessories, and popular clothing packages",
              "For e-boy avatars: Focus on cool hair, face masks/accessories, and stylish clothing",
              "Invest in premium items or clothing if possible to appear wealthy and established",
              "Make sure your avatar looks unique but not overly extravagant to seem approachable",
              "Consider current Roblox fashion trends for maximum appeal",
              "Add subtle details that make your avatar stand out from typical players",
              "Create a profile bio that suggests you're looking for friends or relationships",
              "Join fashion-focused groups to enhance your profile's appearance",
            ],
          },
          {
            title: "Finding and approaching targets",
            content: [
              "Go into any game with a decent amount of rich girls/boys and find someone that is rich and has premium",
              "Look for players with valuable limited items or Robux displays",
              "Target games where social interaction is the focus (Royale High, Adopt Me, etc.)",
              "Approach them with a genuine compliment about their avatar or gameplay",
              "Tell them that they have a really nice outfit and that they seem really nice",
              "Ask if you wanna be friends and say that you don't have any and that you are a bit awkward",
              "They will mostly say yes, if they don't then just find someone else",
              "Be patient and don't rush the initial interaction - first impressions matter",
              "Show interest in their interests and activities to establish common ground",
            ],
          },
          {
            title: "Building the relationship",
            content: [
              "Ask for their Discord. They will most likely give it to you",
              "To be honest, just be nice and kind always message something to them, make jokes until they like you",
              "If they ask personal stuff just make stuff up that seems believable",
              "Consistently message them and show interest in their life and activities",
              "Join their games and spend time with them regularly",
              "Remember details about their life and reference them in conversations",
              "Share 'personal' stories (fabricated) to create emotional connection",
              "Gradually increase the amount of time you spend talking to them",
              "Send them small gifts in-game to show you care",
              "Create inside jokes and special moments to strengthen the bond",
              "Be supportive during their problems and offer comfort",
            ],
          },
          {
            title: "Establishing romantic interest",
            content: [
              "Now the hardest part, try getting him/her as your Girlfriend or boyfriend",
              "If you now have a fake Roblox girlfriend your almost done",
              "Use subtle flirting techniques and gauge their response",
              "Compliment them frequently but not excessively",
              "Express how much you enjoy spending time with them",
              "Create situations where you can 'accidentally' reveal your feelings",
              "If they reciprocate, gradually increase romantic communication",
              "Send heart emojis and use pet names to strengthen the romantic connection",
              "Continue strengthening the relationship after becoming official",
              "Create a sense of exclusivity and special connection between you two",
              "Talk about future plans together to deepen the emotional investment",
            ],
          },
          {
            title: "Executing the account access strategy",
            content: [
              "Ask her if she can make you a really nice avatar and send her your password (make sure your trades are off and you have a pin)",
              "Explain that you trust them completely and want their help with your look",
              "Now, ask her if you can make an avatar for her. She will say yes 95% of the time",
              "When they give you their password, log in immediately",
              "Check for valuable limited items and Robux",
              "If they have a PIN, try common combinations or ask them for it under the pretense of buying them something",
              "Transfer items to your alt accounts quickly",
              "Consider changing their password if you want longer access",
              "If they have email verification, you may need to create an excuse for why you need the code",
              "Enjoy your newly acquired items and prepare to ghost them or create an excuse",
            ],
          },
        ],
        tips: [
          "Target players who seem lonely or eager for connection",
          "Be consistent with your persona and backstory to avoid suspicion",
          "Take screenshots of conversations to remember details about your target",
          "Don't rush the relationship - patience yields better results",
          "Have believable excuses ready if they become suspicious",
          "Focus on emotional manipulation rather than technical tricks",
          "Learn about their interests so you can discuss them knowledgeably",
          "If they have friends, be friendly with them too to seem more legitimate",
          "Use voice messages occasionally if possible to build deeper connection",
          "Study real relationship dynamics to make your approach more convincing",
          "Have multiple targets in progress in case some don't work out",
        ],
        warnings: [
          "This method requires significant time investment",
          "Emotional manipulation can cause real psychological harm",
          "Some targets may have parents monitoring their accounts",
          "Experienced players may test you with trick questions",
          "Account PINs and trading restrictions can prevent item theft even with password access",
          "The victim may have friends who become suspicious of your intentions",
          "This method leaves lasting evidence in chat logs and relationship history",
          "Victims of this scam often report it, leading to account bans",
          "Some players are aware of this scam and actively look for signs",
          "The psychological impact on victims can lead to more serious consequences than other methods",
        ],
        credits: "Method compiled by PoepBeamz Team",
      },
    },
    {
      id: "mm2-method",
      name: "MM2 Method",
      description:
        "Game-specific approach targeting Murder Mystery 2 players through exclusive item offers and trading scams. This method leverages the high-value collectible market within MM2 to attract victims.",
      category: "social",
      difficulty: "beginner",
      features: [
        "MM2 server targeting",
        "Rare item bait tactics",
        "Free godly item offers",
        "Mass messaging techniques",
        "Trading server optimization",
        "High-volume approach",
      ],
      instructions:
        "Deploy the MM2 method in Murder Mystery 2 trading servers following the detailed guide. Utilize the mass messaging approach and exclusive item offers to maximize engagement and conversion rates.",
      downloads: 8432,
      rating: 4.2,
      isNew: true,
      isPopular: false,
      lastUpdated: "2025-04-08",
      author: "GameScammer",
      tags: ["mm2", "game-specific", "trading", "godly"],
      effectiveness: 3,
      successRate: "50-65%",
      tutorialUrl: "https://justpaste.it/mm2-method",
      emoji: "🔪", // Knife for MM2 theme
    },
    {
      id: "screenshare-method",
      name: "Screenshare Method",
      description:
        "Advanced impersonation technique that targets Roblox players through Discord by posing as game moderators or admins. This method exploits fear of account penalties to manipulate victims.",
      category: "discord",
      difficulty: "intermediate",
      features: [
        "Admin impersonation framework",
        "Cyrillic character substitution",
        "False report simulation",
        "Discord server manipulation",
        "Psychological pressure tactics",
        "Screenshot evidence fabrication",
      ],
      instructions:
        "Implement the Screenshare Method by following the detailed impersonation guide. Create convincing admin profiles, establish authority through false reports, and execute the manipulation strategy to obtain account access.",
      downloads: 8932,
      rating: 4.5,
      isNew: true,
      isPopular: true,
      lastUpdated: "2025-04-18",
      author: "DiscordMaster",
      tags: ["discord", "impersonation", "admin", "screenshare"],
      effectiveness: 4,
      successRate: "65-80%",
      tutorialUrl: "https://justpaste.it/screenshare-method",
      emoji: "🖥️", // Computer screen for screenshare method
    },
    {
      id: "please-donate-method",
      name: "Please Donate Method",
      description:
        "Specialized method targeting Roblox players in PLS DONATE games through fake private server links and giveaway offers. This method exploits the desire for free Robux and giveaways.",
      category: "social",
      difficulty: "beginner",
      features: [
        "PLS DONATE game targeting",
        "Fake private server links",
        "Giveaway incentives",
        "Discord integration",
        "High success rate with younger players",
        "Simple execution process",
      ],
      instructions:
        "Deploy the Please Donate method in PLS DONATE games following the detailed guide. Create convincing private server links and giveaway offers to maximize engagement and conversion rates.",
      downloads: 7845,
      rating: 4.7,
      isNew: true,
      isPopular: true,
      lastUpdated: "2025-04-22",
      author: "DonationMaster",
      tags: ["donate", "game-specific", "giveaway", "robux"],
      effectiveness: 4,
      successRate: "75-85%",
      tutorialUrl: "https://justpaste.it/please-donate-method",
      discordServer: {
        name: "Hazem Community",
        url: "https://discord.com/invite/hazem",
      },
      emoji: "💰", // Money bag for donation-related method
    },
  ]

  // Filter and sort beaming methods
  const filteredMethods = beamingMethods
    .filter((method) => {
      const matchesSearch =
        method.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        method.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        method.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

      const matchesCategory = selectedCategory === "all" || method.category === selectedCategory
      const matchesDifficulty = selectedDifficulty === "all" || method.difficulty === selectedDifficulty

      return matchesSearch && matchesCategory && matchesDifficulty
    })
    .sort((a, b) => {
      if (sortBy === "popular") {
        return b.downloads - a.downloads
      } else if (sortBy === "newest") {
        return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime()
      } else if (sortBy === "effectiveness") {
        return (b.effectiveness || 0) - (a.effectiveness || 0)
      } else {
        return b.rating - a.rating
      }
    })

  const getCategoryIcon = (category: MethodCategory) => {
    const lowerCategory = category.toLowerCase()
    switch (lowerCategory) {
      case "social":
        return <Users className="w-4 h-4 text-blue-400" />
      case "technical":
        return <Code className="w-4 h-4 text-green-400" />
      case "discord":
        return <MessageCircle className="w-4 h-4 text-indigo-400" />
      case "tiktok":
        return <Sparkles className="w-4 h-4 text-pink-400" />
      case "malware":
        return <Code className="w-4 h-4 text-red-400" />
      case "phishing":
        return <Info className="w-4 h-4 text-orange-400" />
      default:
        return <Info className="w-4 h-4 text-gray-400" />
    }
  }

  const getDifficultyColor = (difficulty: MethodDifficulty): string => {
    const lowerDifficulty = difficulty.toLowerCase()
    switch (lowerDifficulty) {
      case "beginner":
        return "text-green-400 border-green-400/50 bg-green-500/20"
      case "intermediate":
        return "text-yellow-400 border-yellow-400/50 bg-yellow-500/20"
      case "advanced":
        return "text-red-400 border-red-400/50 bg-red-500/20"
      default:
        return "text-gray-400 border-gray-400/50 bg-gray-500/20"
    }
  }

  const getCategoryColor = (category: MethodCategory): string => {
    const lowerCategory = category.toLowerCase()
    switch (lowerCategory) {
      case "social":
        return "text-blue-400 border-blue-400/30 bg-blue-400/10"
      case "technical":
        return "text-green-400 border-green-400/30 bg-green-400/10"
      case "discord":
        return "text-indigo-400 border-indigo-400/30 bg-indigo-400/10"
      case "tiktok":
        return "text-pink-400 border-pink-400/30 bg-pink-400/10"
      case "malware":
        return "text-red-400 border-red-400/30 bg-red-400/10"
      case "phishing":
        return "text-orange-400 border-orange-400/30 bg-orange-400/10"
      default:
        return "text-gray-400 border-gray-400/30 bg-gray-400/10"
    }
  }

  const renderStarRating = (rating: number) => {
    const fullStars = Math.floor(rating)
    const hasHalfStar = rating % 1 >= 0.5
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0)

    return (
      <div className="flex items-center">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`full-${i}`} className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400 fill-yellow-400" />
        ))}
        {hasHalfStar && (
          <div className="relative">
            <Star className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400" />
            <div className="absolute inset-0 overflow-hidden w-1/2">
              <Star className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400 fill-yellow-400" />
            </div>
          </div>
        )}
        {[...Array(emptyStars)].map((_, i) => (
          <Star key={`empty-${i}`} className="w-3 h-3 sm:w-4 sm:h-4 text-yellow-400" />
        ))}
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden py-4 sm:py-8 px-2 sm:px-4">
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-0" aria-hidden="true" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
        transition={{ duration: 1 }}
        className="relative z-10 container mx-auto px-2 sm:px-4 flex flex-col items-center space-y-5 w-full max-w-6xl"
      >
        {/* Header */}
        <div className="w-full flex justify-between items-center mb-4">
          <Link
            href="/"
            className="flex items-center text-purple-400 hover:text-white transition-colors gap-1 bg-gradient-to-r from-purple-900/60 to-black/60 px-3 py-1.5 rounded-md border border-purple-500/20 hover:border-purple-500/40 relative overflow-hidden group shadow-lg hover:shadow-purple-500/20"
          >
            <ArrowLeft className="w-4 h-4 relative z-10" />
            <span className="relative z-10 font-medium">Back to Home</span>
            <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
          </Link>
          <h1 className="text-2xl sm:text-3xl font-bold text-center text-white purple-glow flex items-center gap-2">
            <Award className="text-purple-400 w-6 h-6 hidden sm:inline" />
            Beaming Methods
            <Award className="text-purple-400 w-6 h-6 hidden sm:inline" />
          </h1>
          <div className="w-20"></div> {/* Spacer for alignment */}
        </div>

        {/* Search and Filter Bar */}
        <div className="w-full border border-purple-500/30 rounded-xl p-4 bg-gradient-to-r from-purple-900/20 to-black/60 purple-glow-container mb-6 shadow-lg">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-grow">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-purple-400" />
              </div>
              <input
                type="text"
                placeholder="Search methods..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-black/60 border border-purple-500/30 rounded-md py-2 pl-10 pr-3 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 shadow-inner"
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}
                className="bg-gradient-to-r from-purple-900/40 to-black/60 border border-purple-500/30 rounded-md py-2 px-3 text-white flex items-center justify-center gap-2 hover:bg-black/80 transition-colors relative overflow-hidden group shadow-md hover:shadow-purple-500/20"
                title={viewMode === "grid" ? "Switch to list view" : "Switch to grid view"}
              >
                <SlidersHorizontal className="h-5 w-5 text-purple-400 relative z-10" />
                <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
              </button>

              <button
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="bg-gradient-to-r from-purple-900/40 to-black/60 border border-purple-500/30 rounded-md py-2 px-4 text-white flex items-center justify-center gap-2 hover:bg-black/80 transition-colors relative overflow-hidden group shadow-md hover:shadow-purple-500/20"
              >
                <Filter className="h-5 w-5 text-purple-400 relative z-10" />
                <span className="relative z-10 font-medium">Filters</span>
                <ChevronDown
                  className={`h-4 w-4 text-purple-400 transition-transform relative z-10 ${isFilterOpen ? "rotate-180" : ""}`}
                />
                <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
              </button>
            </div>
          </div>

          {/* Expanded Filter Options */}
          <AnimatePresence>
            {isFilterOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-purple-500/20">
                  {/* Category Filter */}
                  <div>
                    <label className="block text-sm text-purple-400 mb-2 font-medium">Category</label>
                    <select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value as MethodCategory)}
                      className="w-full bg-black/60 border border-purple-500/30 rounded-md p-2 text-white appearance-none focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 shadow-inner"
                    >
                      <option value="all">All Categories</option>
                      <option value="social">Social Engineering</option>
                      <option value="technical">Technical</option>
                      <option value="discord">Discord</option>
                      <option value="tiktok">TikTok</option>
                      <option value="malware">Malware</option>
                      <option value="phishing">Phishing</option>
                    </select>
                  </div>

                  {/* Difficulty Filter */}
                  <div>
                    <label className="block text-sm text-purple-400 mb-2 font-medium">Difficulty</label>
                    <select
                      value={selectedDifficulty}
                      onChange={(e) => setSelectedDifficulty(e.target.value as MethodDifficulty)}
                      className="w-full bg-black/60 border border-purple-500/30 rounded-md p-2 text-white appearance-none focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 shadow-inner"
                    >
                      <option value="all">All Levels</option>
                      <option value="beginner">Beginner</option>
                      <option value="intermediate">Intermediate</option>
                      <option value="advanced">Advanced</option>
                    </select>
                  </div>

                  {/* Sort By */}
                  <div>
                    <label className="block text-sm text-purple-400 mb-2 font-medium">Sort By</label>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as "popular" | "newest" | "rating" | "effectiveness")}
                      className="w-full bg-black/60 border border-purple-500/30 rounded-md p-2 text-white appearance-none focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50 shadow-inner"
                    >
                      <option value="effectiveness">Most Effective</option>
                      <option value="popular">Most Popular</option>
                      <option value="newest">Newest</option>
                      <option value="rating">Highest Rated</option>
                    </select>
                  </div>

                  {/* Clear Filters Button */}
                  <div className="flex items-end">
                    <button
                      onClick={() => {
                        setSearchQuery("")
                        setSelectedCategory("all")
                        setSelectedDifficulty("all")
                        setSortBy("effectiveness")
                      }}
                      className="w-full bg-gradient-to-r from-purple-900/40 to-black/60 border border-purple-500/30 rounded-md p-2 text-purple-400 hover:text-white flex items-center justify-center gap-2 hover:bg-black/80 transition-colors relative overflow-hidden group shadow-md hover:shadow-purple-500/20"
                    >
                      <X className="w-4 h-4 relative z-10" />
                      <span className="relative z-10 font-medium">Clear All Filters</span>
                      <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Results Count */}
        <div className="w-full flex justify-between items-center mb-4">
          <p className="text-gray-300 text-sm">
            Showing <span className="text-purple-400 font-semibold">{filteredMethods.length}</span> beaming methods
          </p>
          {searchQuery || selectedCategory !== "all" || selectedDifficulty !== "all" ? (
            <button
              onClick={() => {
                setSearchQuery("")
                setSelectedCategory("all")
                setSelectedDifficulty("all")
                setSortBy("effectiveness")
              }}
              className="text-xs text-purple-400 hover:text-white flex items-center gap-1 bg-gradient-to-r from-purple-900/40 to-black/60 px-2 py-1 rounded border border-purple-500/30 hover:border-purple-500/50 relative overflow-hidden group shadow-md"
            >
              <X className="w-3 h-3 relative z-10" />
              <span className="relative z-10">Clear Filters</span>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </button>
          ) : null}
        </div>

        {/* Methods Grid or List */}
        {filteredMethods.length > 0 ? (
          viewMode === "grid" ? (
            <div className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {filteredMethods.map((method) => (
                <motion.div
                  key={method.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="border border-purple-500/30 rounded-xl bg-gradient-to-br from-purple-900/20 to-black/80 overflow-hidden hover:border-purple-500/50 hover:transform hover:scale-[1.02] transition-all duration-300 group relative shadow-lg hover:shadow-purple-500/30"
                  onClick={() => setSelectedMethod(method)}
                >
                  <div className="p-4 sm:p-5 relative">
                    {/* Logo in top left */}
                    <div className="absolute top-2 sm:top-4 left-2 sm:left-4 w-10 h-10 sm:w-12 sm:h-12 z-10">
                      <div className="w-full h-full flex items-center justify-center text-2xl sm:text-3xl bg-gradient-to-br from-purple-900/30 to-black/30 rounded-full border border-purple-500/20 shadow-inner">
                        {method.emoji || "💰"}
                      </div>
                    </div>

                    {/* New Badge next to logo */}
                    {method.isNew && (
                      <div className="absolute top-2 sm:top-4 left-12 sm:left-16 bg-purple-600 text-white text-[8px] sm:text-xs px-1 sm:px-2 py-0.5 sm:py-1 rounded-md font-bold shadow-md">
                        NEW
                      </div>
                    )}

                    {/* Category Badge */}
                    <div
                      className={`absolute top-2 sm:top-4 right-2 sm:right-4 px-1 sm:px-2 py-0.5 sm:py-1 rounded-md text-[8px] sm:text-xs font-medium border ${getCategoryColor(method.category)} shadow-md`}
                    >
                      <div className="flex items-center gap-1">
                        {getCategoryIcon(method.category)}
                        <span>{method.category}</span>
                      </div>
                    </div>

                    <h3 className="text-base sm:text-xl font-bold text-white mt-10 sm:mt-12 mb-2 group-hover:text-purple-400 transition-colors">
                      {method.name}
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-300 mb-4 line-clamp-2">{method.description}</p>

                    {/* Effectiveness Rating */}
                    {method.effectiveness && (
                      <div className="mb-3 sm:mb-4">
                        <h4 className="text-xs sm:text-sm font-semibold text-purple-400 mb-1 sm:mb-2 flex items-center gap-1">
                          <TrendingUp className="w-3 h-3 sm:w-3.5 sm:h-3.5" /> Effectiveness:
                        </h4>
                        <div className="flex items-center gap-2">
                          {renderStarRating(method.effectiveness)}
                          <span className="text-xs text-gray-400">({method.effectiveness.toFixed(1)})</span>
                        </div>
                      </div>
                    )}

                    {/* Success Rate */}
                    {method.successRate && (
                      <div className="mb-3 sm:mb-4">
                        <h4 className="text-xs sm:text-sm font-semibold text-purple-400 mb-1 sm:mb-2 flex items-center gap-1">
                          <Zap className="w-3 h-3 sm:w-3.5 sm:h-3.5" /> Success Rate:
                        </h4>
                        <div className="text-xs sm:text-sm text-white bg-black/40 px-2 sm:px-3 py-1 sm:py-1.5 rounded-md border border-purple-500/20 inline-block shadow-inner">
                          {method.successRate}
                        </div>
                      </div>
                    )}

                    {/* Features Preview */}
                    <div className="mb-3 sm:mb-4">
                      <h4 className="text-xs sm:text-sm font-semibold text-purple-400 mb-1 sm:mb-2 flex items-center gap-1">
                        <Check className="w-3 h-3 sm:w-3.5 sm:h-3.5" /> Key Features:
                      </h4>
                      <ul className="text-xs text-gray-300 space-y-1">
                        {method.features.slice(0, 2).map((feature, index) => (
                          <li key={index} className="flex items-start gap-1 sm:gap-2">
                            <div className="mt-0.5">
                              <div className="w-1.5 h-1.5 rounded-full bg-purple-400"></div>
                            </div>
                            <span className="text-xs">{feature}</span>
                          </li>
                        ))}
                        {method.features.length > 2 && (
                          <li className="text-purple-400 text-xs">+ {method.features.length - 2} more features</li>
                        )}
                      </ul>
                    </div>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1 sm:gap-2 mb-3 sm:mb-4">
                      {method.tags.slice(0, 3).map((tag, index) => (
                        <span
                          key={index}
                          className="text-[10px] sm:text-xs bg-purple-500/10 text-purple-400 px-1 sm:px-2 py-0.5 sm:py-1 rounded-md border border-purple-500/20 shadow-sm"
                        >
                          {tag}
                        </span>
                      ))}
                      {method.tags.length > 3 && (
                        <span className="text-[10px] sm:text-xs text-purple-400">+{method.tags.length - 3}</span>
                      )}
                    </div>

                    {/* Stats */}
                    <div className="flex items-center justify-between text-[10px] sm:text-xs text-gray-400 border-t border-purple-500/20 pt-2 sm:pt-3">
                      <div className="flex items-center gap-1">
                        <Download className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                        <span>{method.downloads.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                        <span>
                          {method.lastUpdated ? new Date(method.lastUpdated).toLocaleDateString() : "Unknown"}
                        </span>
                      </div>
                    </div>

                    {/* Difficulty - Enhanced visibility */}
                    <div
                      className={`absolute bottom-2 sm:bottom-4 right-2 sm:right-4 px-2 sm:px-3 py-1 sm:py-1.5 rounded-md text-[10px] sm:text-xs font-bold border ${getDifficultyColor(method.difficulty)}`}
                    >
                      {method.difficulty}
                    </div>

                    {/* Hover overlay with call to action */}
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-900/80 to-black/90 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <button className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md flex items-center gap-2 transition-colors shadow-lg transform hover:scale-105 transition-transform duration-200">
                        <Info className="w-4 h-4" />
                        <span>View Details</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="w-full space-y-4">
              {filteredMethods.map((method) => (
                <motion.div
                  key={method.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="border border-purple-500/30 rounded-xl bg-gradient-to-r from-purple-900/20 to-black/80 overflow-hidden hover:border-purple-500/50 transition-all duration-300 group relative shadow-lg hover:shadow-purple-500/30"
                  onClick={() => setSelectedMethod(method)}
                >
                  <div className="p-4 sm:p-5 relative">
                    <div className="flex flex-col sm:flex-row gap-4">
                      {/* Left section with logo */}
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 sm:w-16 sm:h-16 flex items-center justify-center text-2xl sm:text-3xl bg-gradient-to-br from-purple-900/30 to-black/30 rounded-full border border-purple-500/20 shadow-inner">
                          {method.emoji || "💰"}
                        </div>
                      </div>

                      {/* Middle section with details */}
                      <div className="flex-grow">
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <h3 className="text-lg sm:text-xl font-bold text-white group-hover:text-purple-400 transition-colors">
                            {method.name}
                          </h3>
                          {method.isNew && (
                            <span className="bg-purple-600 text-white text-[8px] sm:text-xs px-1 sm:px-2 py-0.5 rounded-md font-bold">
                              NEW
                            </span>
                          )}
                          <span
                            className={`px-1 sm:px-2 py-0.5 rounded-md text-[8px] sm:text-xs font-medium border ${getCategoryColor(method.category)}`}
                          >
                            <div className="flex items-center gap-1">
                              {getCategoryIcon(method.category)}
                              <span>{method.category}</span>
                            </div>
                          </span>
                          <span
                            className={`px-1 sm:px-2 py-0.5 rounded-md text-[8px] sm:text-xs font-bold border ${getDifficultyColor(method.difficulty)}`}
                          >
                            {method.difficulty}
                          </span>
                        </div>

                        <p className="text-xs sm:text-sm text-gray-300 mb-3 line-clamp-2">{method.description}</p>

                        <div className="flex flex-wrap gap-4 mb-2">
                          {method.effectiveness && (
                            <div className="flex items-center gap-1">
                              <TrendingUp className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-purple-400" />
                              <span className="text-xs text-gray-300">Rating:</span>
                              <div className="flex items-center">
                                {[...Array(Math.floor(method.effectiveness))].map((_, i) => (
                                  <Star key={i} className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                                ))}
                                {method.effectiveness % 1 >= 0.5 && <Star className="w-3 h-3 text-yellow-400" />}
                                <span className="ml-1 text-xs">({method.effectiveness.toFixed(1)})</span>
                              </div>
                            </div>
                          )}

                          {method.successRate && (
                            <div className="flex items-center gap-1">
                              <Zap className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-purple-400" />
                              <span className="text-xs text-gray-300">Success Rate:</span>
                              <span className="text-xs text-white">{method.successRate}</span>
                            </div>
                          )}

                          <div className="flex items-center gap-1">
                            <Download className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-purple-400" />
                            <span className="text-xs text-gray-300">Downloads:</span>
                            <span className="text-xs text-white">{method.downloads.toLocaleString()}</span>
                          </div>
                        </div>

                        {/* Tags */}
                        <div className="flex flex-wrap gap-1 sm:gap-2 mt-3">
                          {method.tags.map((tag, index) => (
                            <span
                              key={index}
                              className="text-[10px] bg-purple-500/10 text-purple-400 px-1 py-0.5 rounded-md border border-purple-500/20"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Right section with actions */}
                      <div className="flex-shrink-0 flex flex-row sm:flex-col justify-end sm:justify-between items-end gap-2">
                        <div className="text-xs text-gray-400 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>
                            {method.lastUpdated ? new Date(method.lastUpdated).toLocaleDateString() : "Unknown"}
                          </span>
                        </div>
                        <button className="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1.5 rounded-md text-xs flex items-center gap-1.5 transition-colors shadow-md">
                          <Info className="w-3.5 h-3.5" />
                          <span>View Details</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )
        ) : (
          <div className="w-full border border-purple-500/30 rounded-xl p-8 bg-gradient-to-r from-purple-900/20 to-black/60 text-center shadow-lg">
            <Info className="w-12 h-12 mx-auto mb-4 text-purple-400 opacity-50" />
            <h3 className="text-xl font-bold text-white mb-2">No methods found</h3>
            <p className="text-gray-400">Try adjusting your search or filters to find what you're looking for.</p>
          </div>
        )}

        {/* Quick Actions Bar */}
        <div className="w-full border border-purple-500/30 rounded-xl p-4 bg-gradient-to-r from-purple-900/20 to-black/60 purple-glow-container mt-6 shadow-lg">
          <div className="flex flex-wrap gap-3 justify-center">
            <button className="bg-gradient-to-r from-purple-900/40 to-black/60 border border-purple-500/30 rounded-md py-2 px-4 text-white flex items-center gap-2 hover:bg-black/80 transition-colors relative overflow-hidden group shadow-md hover:shadow-purple-500/20">
              <BookOpen className="h-5 w-5 text-purple-400 relative z-10" />
              <span className="relative z-10 font-medium">View Tutorials</span>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </button>

            <button className="bg-gradient-to-r from-purple-900/40 to-black/60 border border-purple-500/30 rounded-md py-2 px-4 text-white flex items-center gap-2 hover:bg-black/80 transition-colors relative overflow-hidden group shadow-md hover:shadow-purple-500/20">
              <Printer className="h-5 w-5 text-purple-400 relative z-10" />
              <span className="relative z-10 font-medium">Print Method</span>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </button>

            <button className="bg-gradient-to-r from-purple-900/40 to-black/60 border border-purple-500/30 rounded-md py-2 px-4 text-white flex items-center gap-2 hover:bg-black/80 transition-colors relative overflow-hidden group shadow-md hover:shadow-purple-500/20">
              <Share2 className="h-5 w-5 text-purple-400 relative z-10" />
              <span className="relative z-10 font-medium">Share Methods</span>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </button>

            <button className="bg-gradient-to-r from-purple-900/40 to-black/60 border border-purple-500/30 rounded-md py-2 px-4 text-white flex items-center gap-2 hover:bg-black/80 transition-colors relative overflow-hidden group shadow-md hover:shadow-purple-500/20">
              <BarChart3 className="h-5 w-5 text-purple-400 relative z-10" />
              <span className="relative z-10 font-medium">Compare Methods</span>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </button>
          </div>
        </div>
      </motion.div>

      {/* Method Detail Modal */}
      <AnimatePresence>
        {selectedMethod && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
            onClick={() => setSelectedMethod(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25 }}
              className="relative w-full max-w-4xl border border-purple-500/30 rounded-xl bg-gradient-to-br from-black/95 to-purple-900/20 max-h-[90vh] overflow-hidden flex flex-col"
              onClick={(e) => e.stopPropagation()}
              style={{ boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
            >
              {/* Header */}
              <div className="p-5 border-b border-purple-500/20 flex justify-between items-center bg-gradient-to-r from-purple-900/40 to-black sticky top-0 z-10">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  {selectedMethod.emoji && <span className="text-2xl">{selectedMethod.emoji}</span>}
                  <span className="purple-glow">{selectedMethod.name}</span>
                  {selectedMethod.isNew && (
                    <span className="ml-2 bg-gradient-to-r from-purple-600 to-purple-400 text-white text-xs px-2 py-0.5 rounded-full shadow-md">
                      New
                    </span>
                  )}
                  {selectedMethod.tags.includes("op") && (
                    <span className="ml-2 bg-gradient-to-r from-yellow-500 to-amber-500 text-black text-xs font-bold px-2 py-0.5 rounded-full shadow-md">
                      OP
                    </span>
                  )}
                </h2>
                <button
                  onClick={() => setSelectedMethod(null)}
                  className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10 relative overflow-hidden group"
                  aria-label="Close details"
                >
                  <X className="w-6 h-6 relative z-10" />
                  <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100"></div>
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-5 space-y-6 custom-scrollbar">
                {/* Effectiveness Rating at Top */}
                <div className="flex flex-col sm:flex-row gap-4 items-start">
                  <div className="flex-1 order-2 sm:order-1">
                    <div className="flex flex-col gap-3">
                      <div className="bg-gradient-to-br from-black/60 to-purple-900/10 border border-purple-500/20 rounded-lg p-3 shadow-md">
                        <h3 className="text-lg font-semibold text-purple-400 mb-2 flex items-center gap-2">
                          <TrendingUp className="w-5 h-5" /> Effectiveness Rating
                        </h3>
                        <div className="flex items-center gap-3">
                          <div className="flex">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-6 h-6 ${
                                  i < (selectedMethod.effectiveness || 0)
                                    ? "text-yellow-400 fill-yellow-400"
                                    : "text-gray-600"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-lg font-bold text-white">
                            {selectedMethod.effectiveness ? `${selectedMethod.effectiveness}/5` : "N/A"}
                          </span>
                        </div>

                        {/* Success Rate */}
                        {selectedMethod.successRate && (
                          <div className="mt-3">
                            <h4 className="text-sm font-semibold text-purple-400 mb-1 flex items-center gap-1">
                              <Zap className="w-4 h-4" /> Success Rate:
                            </h4>
                            <div className="text-sm text-white bg-black/40 px-3 py-1.5 rounded-md border border-purple-500/20 inline-block shadow-inner">
                              {selectedMethod.successRate}
                            </div>
                          </div>
                        )}

                        <div className="mt-3">
                          <h4 className="text-sm font-semibold text-purple-400 mb-1 flex items-center gap-1">
                            <Info className="w-4 h-4" /> Tags:
                          </h4>
                          <div className="flex flex-wrap gap-2 mt-1">
                            {selectedMethod.tags.map((tag, index) => (
                              <span
                                key={index}
                                className={`text-xs px-2 py-1 rounded-md border shadow-sm ${
                                  tag === "op"
                                    ? "bg-gradient-to-r from-yellow-500 to-amber-500 text-black font-bold border-yellow-500"
                                    : "bg-purple-500/10 text-purple-400 border-purple-500/20"
                                }`}
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="sm:w-64 space-y-4 order-1 sm:order-2">
                    {/* Stats */}
                    <div className="border border-purple-500/20 rounded-lg p-4 bg-gradient-to-br from-black/60 to-purple-900/10 shadow-md">
                      <h3 className="text-sm font-semibold text-purple-400 mb-3 flex items-center gap-1">
                        <Info className="w-4 h-4" /> Information
                      </h3>

                      <div className="space-y-2 text-sm">
                        {selectedMethod.author && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Author:</span>
                            <span className="text-white">{selectedMethod.author}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-gray-400">Downloads:</span>
                          <span className="text-white">{selectedMethod.downloads.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Rating:</span>
                          <span className="text-white flex items-center">
                            {selectedMethod.rating.toFixed(1)}
                            <Star className="w-3.5 h-3.5 text-yellow-400 ml-1" />
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Difficulty:</span>
                          <span className={getDifficultyColor(selectedMethod.difficulty).split(" ")[0]}>
                            {selectedMethod.difficulty.charAt(0).toUpperCase() + selectedMethod.difficulty.slice(1)}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Category:</span>
                          <span className={getCategoryColor(selectedMethod.category).split(" ")[0]}>
                            {selectedMethod.category.charAt(0).toUpperCase() + selectedMethod.category.slice(1)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="space-y-2">
                      {selectedMethod.tutorialUrl && (
                        <a
                          href={selectedMethod.tutorialUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 text-white px-4 py-2 rounded-md flex items-center justify-center gap-2 transition-colors shadow-md transform hover:translate-y-[-2px] transition-transform duration-200"
                        >
                          <ExternalLink className="w-4 h-4" />
                          <span>View Tutorial</span>
                        </a>
                      )}
                      <button className="w-full bg-gradient-to-r from-black to-purple-900/40 border border-purple-500/30 hover:border-purple-500/60 text-white px-4 py-2 rounded-md flex items-center justify-center gap-2 transition-colors shadow-md transform hover:translate-y-[-2px] transition-transform duration-200">
                        <Download className="w-4 h-4" />
                        <span>Download Method</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Detailed Tutorial Section */}
                {selectedMethod.detailedTutorial && (
                  <div className="mt-6">
                    <div className="bg-gradient-to-r from-purple-900/30 to-black/60 border-l-4 border-purple-500 rounded-lg p-5 mb-6 shadow-lg">
                      <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                        {selectedMethod.emoji && <span className="text-2xl">{selectedMethod.emoji}</span>}
                        {selectedMethod.name} Tutorial
                      </h2>

                      <div className="mb-6">
                        <h3 className="text-lg font-semibold text-purple-400 mb-2 flex items-center gap-2">
                          <Info className="w-5 h-5" />
                          How It Works
                        </h3>
                        <p className="text-gray-200 bg-black/40 p-4 rounded-lg border border-purple-500/20 shadow-inner">
                          {selectedMethod.detailedTutorial.howItWorks}
                        </p>
                      </div>

                      <div className="mb-6">
                        <h3 className="text-lg font-semibold text-purple-400 mb-2 flex items-center gap-2">
                          <Shield className="w-5 h-5" />
                          Requirements
                        </h3>
                        <ul className="space-y-2 bg-black/40 p-4 rounded-lg border border-purple-500/20 shadow-inner">
                          {selectedMethod.detailedTutorial.requirements?.map((req, index) => (
                            <li key={index} className="flex items-start gap-2 text-gray-200">
                              <div className="mt-1 flex-shrink-0">
                                <div className="w-2 h-2 rounded-full bg-purple-400"></div>
                              </div>
                              <span>{req}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Tutorial Steps */}
                      <div className="space-y-6">
                        {selectedMethod.detailedTutorial.steps?.map((step, stepIndex) => (
                          <div
                            key={stepIndex}
                            className="bg-black/40 rounded-lg border border-purple-500/20 overflow-hidden shadow-md"
                          >
                            <div className="bg-gradient-to-r from-purple-900/30 to-black/60 p-3 border-b border-purple-500/20">
                              <h3 className="font-semibold text-white flex items-center gap-2">
                                <span className="bg-gradient-to-r from-purple-600 to-purple-500 text-white w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold shadow-md">
                                  {stepIndex + 1}
                                </span>
                                {step.title}
                              </h3>
                            </div>
                            <div className="p-4">
                              <ul className="space-y-3">
                                {step.content.map((item, itemIndex) => (
                                  <li key={itemIndex} className="flex items-start gap-2 text-gray-200">
                                    <Check className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
                                    <span>{item}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Tips Section */}
                      {selectedMethod.detailedTutorial.tips && (
                        <div className="mt-6 bg-black/40 rounded-lg border border-yellow-500/20 p-4 shadow-md">
                          <h3 className="text-lg font-semibold text-yellow-400 mb-3 flex items-center gap-2">
                            <Sparkles className="w-5 h-5" />
                            Important Tips
                          </h3>
                          <ul className="space-y-2">
                            {selectedMethod.detailedTutorial.tips.map((tip, index) => (
                              <li key={index} className="flex items-start gap-2 text-gray-200">
                                <div className="mt-1 flex-shrink-0">
                                  <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
                                </div>
                                <span>{tip}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Warnings Section */}
                      {selectedMethod.detailedTutorial.warnings && (
                        <div className="mt-4 bg-black/40 rounded-lg border border-red-500/20 p-4 shadow-md">
                          <h3 className="text-lg font-semibold text-red-400 mb-3 flex items-center gap-2">
                            <AlertTriangle className="w-5 h-5" />
                            Warnings
                          </h3>
                          <ul className="space-y-2">
                            {selectedMethod.detailedTutorial.warnings.map((warning, index) => (
                              <li key={index} className="flex items-start gap-2 text-gray-200">
                                <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                                <span>{warning}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Credits */}
                      {selectedMethod.detailedTutorial.credits && (
                        <div className="mt-4 text-right text-sm text-gray-400">
                          Credits: {selectedMethod.detailedTutorial.credits}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Features */}
                <div>
                  <h3 className="text-lg font-semibold text-purple-400 mb-3 flex items-center gap-2">
                    <Check className="w-5 h-5" /> Features
                  </h3>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-black/40 p-4 rounded-lg border border-purple-500/20 shadow-inner">
                    {selectedMethod.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2 text-gray-300">
                        <div className="mt-1">
                          <div className="w-2 h-2 rounded-full bg-purple-400"></div>
                        </div>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Implementation Instructions */}
                {selectedMethod.instructions && !selectedMethod.detailedTutorial && (
                  <div>
                    <h3 className="text-lg font-semibold text-purple-400 mb-3 flex items-center gap-2">
                      <Info className="w-5 h-5" /> Implementation Instructions
                    </h3>
                    <div className="bg-black/60 border border-purple-500/20 rounded-lg p-4 text-gray-300 shadow-inner">
                      <p>{selectedMethod.instructions}</p>
                    </div>
                  </div>
                )}

                {/* Related Methods */}
                <div>
                  <h3 className="text-lg font-semibold text-purple-400 mb-3 flex items-center gap-2">
                    <Lock className="w-5 h-5" /> Related Methods
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {beamingMethods
                      .filter(
                        (method) => method.id !== selectedMethod.id && method.category === selectedMethod.category,
                      )
                      .slice(0, 3)
                      .map((method) => (
                        <div
                          key={method.id}
                          className="border border-purple-500/20 rounded-lg p-3 bg-gradient-to-br from-black/60 to-purple-900/10 hover:border-purple-500/40 transition-colors cursor-pointer group shadow-md hover:shadow-purple-500/20 transform hover:translate-y-[-2px] transition-transform duration-200"
                          onClick={(e) => {
                            e.stopPropagation()
                            setSelectedMethod(method)
                          }}
                        >
                          <h4 className="font-medium text-white group-hover:text-purple-400 transition-colors flex items-center gap-1">
                            {method.emoji && <span>{method.emoji}</span>}
                            {method.name}
                          </h4>
                          <p className="text-xs text-gray-400 mt-1 line-clamp-2">{method.description}</p>
                          <div className="flex items-center justify-between mt-2 text-xs">
                            <span className={getDifficultyColor(method.difficulty).split(" ")[0]}>
                              {method.difficulty.charAt(0).toUpperCase() + method.difficulty.slice(1)}
                            </span>
                            <div className="flex items-center gap-1">
                              {method.effectiveness && (
                                <>
                                  <Star className="w-3 h-3 text-yellow-400" />
                                  <span className="text-gray-300">{method.effectiveness.toFixed(1)}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <MethodDetail isOpen={false} onClose={() => {}} method={null} />

      <style jsx global>{`
        @keyframes shine {
          0% {
            transform: translateX(-100%) rotate(15deg);
          }
          20% {
            transform: translateX(100%) rotate(15deg);
          }
          100% {
            transform: translateX(100%) rotate(15deg);
          }
        }

        .shine-animation {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(
            to right,
            transparent 0%,
            rgba(255, 255, 255, 0.1) 50%,
            transparent 100%
          );
          transform: translateX(-100%) rotate(15deg);
          transition: none;
        }

        .group:hover .shine-animation {
          animation: shine 1.5s ease;
          opacity: 1;
        }

        .purple-glow {
          text-shadow: 0 0 10px rgba(139, 92, 246, 0.7), 0 0 20px rgba(139, 92, 246, 0.5);
        }

        .purple-glow-container {
          box-shadow: 0 0 15px rgba(139, 92, 246, 0.3);
        }
        
        /* Enhanced card styling */
        .method-card {
          transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
        }
        
        .method-card:hover {
          box-shadow: 0 8px 24px rgba(139, 92, 246, 0.3);
        }
        
        /* Button hover effects */
        button, a {
          transition: all 0.2s ease;
        }
        
        button:hover, a:hover {
          transform: translateY(-2px);
        }
        
        button:active, a:active {
          transform: translateY(1px);
        }
        
        /* Modal styling enhancements */
        .modal-content {
          backdrop-filter: blur(8px);
        }
        
        /* Mobile optimizations for method cards */
        @media (max-width: 640px) {
          .method-card {
            min-height: 360px;
          }
          
          /* Ensure proper spacing between cards */
          .grid-cols-2 {
            column-gap: 8px;
            row-gap: 12px;
          }
          
          /* Make icons smaller on mobile */
          .method-card svg {
            width: 12px;
            height: 12px;
          }
          
          /* Ensure text doesn't overflow */
          .method-card h3, .method-card p, .method-card span {
            overflow: hidden;
            text-overflow: ellipsis;
          }
        }
      `}</style>
    </div>
  )
}
