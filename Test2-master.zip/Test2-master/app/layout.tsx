import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import type React from "react"
import Script from "next/script"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Shockify - #1 Roblox Beaming Site",
  description: "Shockify The Number 1 Beaming Site!",
  metadataBase: new URL("https://shockify.nl"),
  alternates: {
    canonical: "/",
  },
  keywords: [
    // Original keywords
    "robloxbeaming",
    "beaming",
    "roblox beaming methods",
    "roblox hacking tools",
    "beaming discord",
    "beaming tutorial",
    "roblox account beaming",
    "beaming methods",
    "beaming tools",
    "roblox cookie logger",
    "roblox phishing",
    "roblox account generator",
    "hackingroblox",
    "robloxbeam",
    "roblox hacking",
    "roblox hack",
    "roblox account hacking",
    "roblox beamer",
    "free robux",
    "roblox robux generator",

    // Game Dev / Scripting
    "roblox scripting tutorial",
    "how to script in roblox",
    "beginner roblox lua scripts",
    "roblox game ideas 2025",
    "best roblox developer tools",
    "roblox studio tips and tricks",
    "roblox scripting for beginners",
    "roblox lua tutorial",
    "roblox coding guide",
    "roblox script examples",
    "roblox game development",
    "roblox studio guide",
    "roblox programming basics",
    "roblox developer hub",

    // Game Creation / Monetization
    "how to make a roblox game",
    "how to earn robux legally",
    "how to publish a roblox game",
    "roblox devex tips",
    "how to get players in roblox game",
    "roblox game monetization",
    "roblox developer exchange",
    "roblox game pass creation",
    "roblox premium payouts",
    "roblox game promotion",
    "roblox game marketing",
    "roblox ugc creation",
    "roblox game analytics",

    // Security / Account Tips
    "how to secure roblox account",
    "roblox 2 step verification setup",
    "avoid roblox scams",
    "what is beaming in roblox",
    "how to recover hacked roblox account",
    "roblox account protection",
    "roblox security tips",
    "roblox password safety",
    "roblox account recovery",
    "roblox anti-phishing guide",
    "roblox safe trading",
    "roblox account security",
    "roblox scam prevention",
  ],
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-video-preview": -1,
      "max-snippet": -1,
    },
  },
  openGraph: {
    title: "Shockify",
    description: "Shockify The Number 1 Beaming Site!",
    url: "https://shockify.nl",
    siteName: "Shockify",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary",
    title: "Shockify",
    description: "Shockify The Number 1 Beaming Site!",
  },
  icons: {
    icon: [
      { url: "/new-favicon.png", type: "image/png", sizes: "512x512" },
      { url: "/new-favicon.png", sizes: "16x16 32x32 48x48 64x64" },
    ],
    shortcut: ["/new-favicon.png"],
    apple: [{ url: "/new-favicon.png", type: "image/png", sizes: "180x180" }],
    other: [
      {
        rel: "apple-touch-icon-precomposed",
        url: "/new-favicon.png",
      },
    ],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        {/* Favicon for browser tabs - multiple formats for maximum compatibility */}
        <link rel="icon" href="/new-favicon.png" type="image/png" sizes="512x512" />
        <link rel="icon" href="/new-favicon.png" sizes="any" />
        <link rel="shortcut icon" href="/new-favicon.png" />
        <link rel="apple-touch-icon" href="/new-favicon.png" />
        <link rel="apple-touch-icon-precomposed" href="/new-favicon.png" />
        <link rel="mask-icon" href="/new-favicon.png" color="#000000" />

        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="theme-color" content="#ffffff" />
        <meta name="msapplication-TileColor" content="#000000" />
        <meta name="msapplication-TileImage" content="/new-favicon.png" />

        {/* Additional SEO meta tags */}
        <meta name="author" content="Shockify Team" />
        <meta name="revisit-after" content="1 day" />
        <meta name="rating" content="general" />
        <meta name="distribution" content="global" />
        <meta name="copyright" content="Shockify" />

        {/* Google-specific thumbnail */}
        <meta name="thumbnail" content="/google-thumbnail.png" />
        <meta property="og:image" content="" />
        <meta name="image" content="" />

        {/* Discord embed color */}
        <meta name="msapplication-TileColor" content="#000000" />
        <meta name="theme-color" content="#ffffff" />

        {/* Geo meta tags */}
        <meta name="geo.region" content="US" />
        <meta name="geo.position" content="37.09024;-95.712891" />
        <meta name="ICBM" content="37.09024, -95.712891" />

        <link rel="manifest" href="/manifest.json" />
      </head>
      <body className={inter.className}>
        {children}

        {/* Enhanced Structured data for better SEO and rich results */}
        <Script
          id="schema-org"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              name: "Shockify",
              url: "https://shockify.nl",
              potentialAction: {
                "@type": "SearchAction",
                target: "https://shockify.nl/search?q={search_term_string}",
                "query-input": "required name=search_term_string",
              },
              description: "Shockify The Number 1 Beaming Site!",
              keywords: "robloxbeaming, beaming, roblox beaming methods, roblox hacking tools",
              logo: {
                "@type": "ImageObject",
                url: "https://shockify.nl/new-favicon.png",
                width: 512,
                height: 512,
              },
            }),
          }}
        />

        {/* Organization Schema with Logo */}
        <Script
          id="organization-schema"
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Shockify",
              url: "https://shockify.nl",
              logo: {
                "@type": "ImageObject",
                url: "https://shockify.nl/new-favicon.png",
                width: 512,
                height: 512,
              },
              description: "Shockify The Number 1 Beaming Site!",
            }),
          }}
        />
      </body>
    </html>
  )
}
