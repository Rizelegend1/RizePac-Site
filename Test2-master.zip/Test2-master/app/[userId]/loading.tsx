import { Skeleton } from "@/components/ui/skeleton"
import DynamicBackground from "@/components/dynamic-background"

export default function Loading() {
  return (
    <div className="flex min-h-screen bg-black text-white">
      <DynamicBackground />

      {/* Sidebar Skeleton */}
      <div className="w-64 bg-black/80 border-r border-purple-900 p-4 flex flex-col">
        <div className="flex items-center mb-8">
          <Skeleton className="w-10 h-10 rounded-full bg-purple-900/30" />
          <Skeleton className="ml-3 h-6 w-24 bg-purple-900/30" />
        </div>

        <div className="space-y-3">
          {Array(8)
            .fill(0)
            .map((_, i) => (
              <div key={i} className="flex items-center px-3 py-2">
                <Skeleton className="h-5 w-5 bg-purple-900/30" />
                <Skeleton className="ml-3 h-4 w-24 bg-purple-900/30" />
              </div>
            ))}
        </div>
      </div>

      {/* Main Content Skeleton */}
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Skeleton className="h-8 w-32 bg-purple-900/30" />
            <Skeleton className="h-10 w-36 bg-purple-900/30" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {Array(3)
              .fill(0)
              .map((_, i) => (
                <Skeleton key={i} className="h-32 bg-purple-900/30 rounded-lg" />
              ))}
          </div>

          <Skeleton className="h-10 w-full bg-purple-900/30 rounded-lg mb-4" />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Skeleton className="h-80 bg-purple-900/30 rounded-lg" />
            <Skeleton className="h-80 bg-purple-900/30 rounded-lg" />
          </div>
        </div>
      </div>
    </div>
  )
}
