"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import {
  ShoppingCart,
  ChevronLeft,
  Check,
  Shield,
  CreditCard,
  Zap,
  Lock,
  Award,
  Users,
  FlameIcon as Fire,
  Trash,
  Plus,
  Minus,
  X,
  Tag,
  AlertCircle,
  MessageSquare,
  Cookie,
  Sparkles,
  Bolt,
  LinkIcon,
  Video,
  Webhook,
  Code,
} from "lucide-react"
import { RedParticleCanvas } from "@/components/red-particle-canvas"

// Product type definition
type Product = {
  id: string
  name: string
  price: number
  originalPrice?: number
  image?: string
  description: string
  features: string[]
  badge?: string
  popular?: boolean
  stock?: number
  soldRecently?: number
  category: "account" | "tool" | "service"
}

// Cart item type
type CartItem = {
  product: Product
  quantity: number
}

// Products data with updated images and prices as requested
const products: Product[] = [
  // Original account products (keep at the top)
  {
    id: "2008-roblox",
    name: "2008 Roblox Account",
    price: 6.0,
    originalPrice: 19.99,
    image: "/images/profile5.png",
    description:
      "Rare 2008 Roblox account with original items and badges from Roblox's early days. Perfect for collectors and status seekers.",
    features: [
      "Created in 2008",
      "Original username",
      "Rare classic items",
      "Early badges and achievements",
      "Verified email (changeable)",
      "Full access guaranteed",
    ],
    badge: "RARE",
    stock: 87,
    soldRecently: 32,
    category: "account",
  },
  {
    id: "2009-roblox",
    name: "2009 Roblox Account",
    price: 5.0,
    originalPrice: 15.99,
    image: "/images/profile4.png",
    description:
      "Authentic 2009 Roblox account with valuable limited items and classic badges. A piece of Roblox history.",
    features: [
      "Created in 2009",
      "Original username",
      "Classic limited items",
      "Rare badges",
      "Verified email (changeable)",
      "Full access guaranteed",
    ],
    badge: "CLASSIC",
    stock: 65,
    soldRecently: 28,
    category: "account",
  },
  {
    id: "2016-discord",
    name: "2016 Discord Account",
    price: 9.99,
    originalPrice: 24.99,
    image: "/images/profile3.png",
    description:
      "Early Discord account with the rare Early Supporter badge and exclusive features. Stand out in any server.",
    features: [
      "Created in 2016",
      "Early Supporter badge",
      "Hypesquad badge",
      "Original discriminator",
      "Verified email (changeable)",
      "Full access guaranteed",
    ],
    badge: "EXCLUSIVE",
    popular: true,
    stock: 42,
    soldRecently: 19,
    category: "account",
  },
  {
    id: "korblox-account",
    name: "Stacked Korblox Account",
    price: 20.0,
    originalPrice: 49.99,
    image: "/images/profile2.png",
    description:
      "Premium Roblox account with the legendary Korblox bundle and other valuable limiteds. Dominate any game with style.",
    features: [
      "Korblox Deathspeaker bundle",
      "Multiple limited items",
      "High Robux balance",
      "Premium membership",
      "Verified email (changeable)",
      "Full access guaranteed",
    ],
    badge: "PREMIUM",
    popular: true,
    stock: 38,
    soldRecently: 25,
    category: "account",
  },
  {
    id: "headless-account",
    name: "Stacked Headless Account",
    price: 39.99,
    originalPrice: 89.99,
    image: "/images/profile1.png",
    description:
      "Elite Roblox account featuring the ultra-rare Headless Horseman package and premium limiteds. The ultimate status symbol.",
    features: [
      "Headless Horseman package",
      "Premium limited items",
      "High value inventory",
      "Premium membership",
      "Verified email (changeable)",
      "Full access guaranteed",
    ],
    badge: "ELITE",
    stock: 25,
    soldRecently: 17,
    category: "account",
  },

  // Additional tools from the site
  {
    id: "cookie-refresher",
    name: "Premium Cookie Refresher",
    price: 14.99,
    originalPrice: 29.99,
    description:
      "Advanced cookie refresher tool with unlimited usage. Refresh cookies instantly with our reliable service.",
    features: [
      "Unlimited refreshes",
      "Fast processing",
      "High success rate",
      "24/7 availability",
      "Automatic validation",
      "Priority support",
    ],
    badge: "POPULAR",
    popular: true,
    stock: 999,
    soldRecently: 124,
    category: "tool",
  },
  {
    id: "webhook-spammer",
    name: "Advanced Webhook Spammer",
    price: 9.99,
    originalPrice: 19.99,
    description:
      "Professional webhook spammer with rate limit handling and advanced features. Send messages efficiently.",
    features: [
      "Rate limit handling",
      "Bulk message sending",
      "Custom message templates",
      "Webhook validation",
      "Detailed analytics",
      "Unlimited usage",
    ],
    badge: "EFFICIENT",
    stock: 999,
    soldRecently: 87,
    category: "tool",
  },
  {
    id: "hyperlink-generator",
    name: "Pro Hyperlink Generator",
    price: 12.99,
    originalPrice: 24.99,
    description:
      "Create powerful hyperlinks with advanced tracking and customization options. Perfect for marketing campaigns.",
    features: [
      "Custom link generation",
      "Click tracking",
      "Link shortening",
      "Advanced analytics",
      "Multiple redirect options",
      "Stealth mode",
    ],
    badge: "ADVANCED",
    stock: 999,
    soldRecently: 56,
    category: "tool",
  },
  {
    id: "beaming-methods",
    name: "Premium Beaming Methods",
    price: 29.99,
    originalPrice: 59.99,
    description:
      "Complete collection of advanced beaming methods with detailed guides and support. Stay ahead with our exclusive techniques.",
    features: [
      "10+ premium methods",
      "Detailed step-by-step guides",
      "Video tutorials",
      "Regular updates",
      "Private support",
      "Proven results",
    ],
    badge: "EXCLUSIVE",
    popular: true,
    stock: 50,
    soldRecently: 38,
    category: "tool",
  },
  {
    id: "embedded-message",
    name: "Discord Embedded Message Creator",
    price: 7.99,
    originalPrice: 14.99,
    description: "Create professional Discord embedded messages with our easy-to-use tool. Stand out in any server.",
    features: [
      "Custom embeds",
      "Rich formatting",
      "Color customization",
      "Image support",
      "Multiple templates",
      "Preview functionality",
    ],
    badge: "CREATIVE",
    stock: 999,
    soldRecently: 42,
    category: "tool",
  },

  // Services
  {
    id: "video-editing",
    name: "Professional Video Editing",
    price: 39.99,
    originalPrice: 79.99,
    description:
      "High-quality video editing service for gaming montages, YouTube videos, and more. Make your content stand out.",
    features: [
      "Professional editing",
      "Custom effects",
      "Color grading",
      "Audio enhancement",
      "Fast turnaround",
      "Unlimited revisions",
    ],
    badge: "PREMIUM",
    popular: true,
    stock: 10,
    soldRecently: 7,
    category: "service",
  },
  {
    id: "custom-script",
    name: "Custom Roblox Script",
    price: 49.99,
    originalPrice: 99.99,
    description:
      "Get a custom Roblox script tailored to your specific needs. Our experienced developers will create exactly what you need.",
    features: [
      "Custom development",
      "Optimized code",
      "Anti-detection measures",
      "Documentation included",
      "Installation support",
      "Future updates",
    ],
    badge: "CUSTOM",
    stock: 5,
    soldRecently: 3,
    category: "service",
  },
]

export default function StorePage() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isClient, setIsClient] = useState(false)
  const [purchaseStep, setPurchaseStep] = useState(0)
  const [timeLeft, setTimeLeft] = useState({ minutes: 30, seconds: 0 })
  const [viewersCount] = useState(() => Math.floor(Math.random() * 15) + 25) // 25-40 viewers
  const [cart, setCart] = useState<CartItem[]>([])
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [activeCategory, setActiveCategory] = useState<string>("all")
  const cartRef = useRef<HTMLDivElement>(null)
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [showPurchaseInfo, setShowPurchaseInfo] = useState(false)

  // Set isClient to true on component mount and handle countdown
  useEffect(() => {
    setIsClient(true)

    // Set vh variable for mobile browsers
    const setVh = () => {
      const vh = window.innerHeight * 0.01
      document.documentElement.style.setProperty("--vh", `${vh}px`)
    }

    setVh()
    window.addEventListener("resize", setVh)

    // Countdown timer
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds === 0) {
          if (prev.minutes === 0) {
            clearInterval(timer)
            return prev
          }
          return { minutes: prev.minutes - 1, seconds: 59 }
        }
        return { ...prev, seconds: prev.seconds - 1 }
      })
    }, 1000)

    // Close cart when clicking outside
    const handleClickOutside = (event: MouseEvent) => {
      if (cartRef.current && !cartRef.current.contains(event.target as Node)) {
        setIsCartOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)

    return () => {
      window.removeEventListener("resize", setVh)
      document.removeEventListener("mousedown", handleClickOutside)
      clearInterval(timer)
    }
  }, [])

  // Add to cart
  const addToCart = (product: Product) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.product.id === product.id)

      if (existingItem) {
        return prevCart.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item,
        )
      } else {
        return [...prevCart, { product, quantity: 1 }]
      }
    })

    // Show cart after adding item
    setIsCartOpen(true)
  }

  // Remove from cart
  const removeFromCart = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId))
  }

  // Update quantity
  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) return

    setCart((prevCart) =>
      prevCart.map((item) => (item.product.id === productId ? { ...item, quantity: newQuantity } : item)),
    )
  }

  // Calculate cart totals
  const calculateCartTotals = () => {
    const subtotal = cart.reduce((total, item) => total + item.product.price * item.quantity, 0)
    const itemCount = cart.reduce((count, item) => count + item.quantity, 0)

    // Apply 20% discount if 2 or more items
    const discount = itemCount >= 2 ? subtotal * 0.2 : 0
    const total = subtotal - discount

    return { subtotal, discount, total, itemCount }
  }

  // View product details and purchase
  const viewProductDetails = (product: Product) => {
    setSelectedProduct(product)
    setPurchaseStep(1)
    // Scroll to top when opening product details
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  // Back to products
  const backToProducts = () => {
    setSelectedProduct(null)
    setPurchaseStep(0)
  }

  // Complete purchase
  const completePurchase = () => {
    setPurchaseStep(2)
    // Clear cart after purchase
    setCart([])
    // Scroll to top when completing purchase
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  // Format countdown time
  const formatTime = (minutes: number, seconds: number) => {
    return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`
  }

  // Format price
  const formatPrice = (price: number) => {
    return `$${price.toFixed(2)}`
  }

  // Get icon for product category
  const getCategoryIcon = (category: string, product: Product) => {
    if (category === "account") return <Users className="w-5 h-5" />

    switch (product.id) {
      case "cookie-refresher":
        return <Cookie className="w-5 h-5" />
      case "webhook-spammer":
        return <Webhook className="w-5 h-5" />
      case "hyperlink-generator":
        return <LinkIcon className="w-5 h-5" />
      case "beaming-methods":
        return <Bolt className="w-5 h-5" />
      case "embedded-message":
        return <MessageSquare className="w-5 h-5" />
      case "video-editing":
        return <Video className="w-5 h-5" />
      case "custom-script":
        return <Code className="w-5 h-5" />
      default:
        return <Zap className="w-5 h-5" />
    }
  }

  // Filter products by category
  const filteredProducts =
    activeCategory === "all" ? products : products.filter((product) => product.category === activeCategory)

  // Render shopping cart
  const renderCart = () => {
    const { subtotal, discount, total, itemCount } = calculateCartTotals()

    return (
      <div
        ref={cartRef}
        className={`fixed top-0 right-0 h-full w-full sm:w-96 bg-black/95 border-l border-red-500/50 shadow-xl z-50 transform transition-transform duration-300 ${
          isCartOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="p-4 border-b border-red-500/30 flex justify-between items-center">
            <h2 className="text-xl font-bold text-white flex items-center">
              <ShoppingCart className="w-5 h-5 text-red-400 mr-2" />
              Your Cart ({itemCount})
            </h2>
            <button
              onClick={() => setIsCartOpen(false)}
              className="text-gray-400 hover:text-white p-2 rounded-full hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <ShoppingCart className="w-16 h-16 text-gray-600 mb-4" />
                <p className="text-gray-400">Your cart is empty</p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="mt-4 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md"
                >
                  Continue Shopping
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {cart.map((item) => (
                  <div key={item.product.id} className="bg-black/60 border border-red-500/30 rounded-lg p-3 flex">
                    {item.product.image ? (
                      <div className="relative w-16 h-16 rounded-md overflow-hidden flex-shrink-0">
                        <Image
                          src={item.product.image || "/placeholder.svg"}
                          alt={item.product.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-16 h-16 rounded-md bg-red-900/30 flex items-center justify-center flex-shrink-0">
                        {getCategoryIcon(item.product.category, item.product)}
                      </div>
                    )}
                    <div className="ml-3 flex-1">
                      <div className="flex justify-between">
                        <h3 className="text-sm font-medium text-white">{item.product.name}</h3>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-gray-400 hover:text-red-400"
                        >
                          <Trash className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="text-red-400 text-sm">{formatPrice(item.product.price)}</p>
                      <div className="flex items-center mt-2">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className="w-6 h-6 flex items-center justify-center bg-gray-800 hover:bg-gray-700 rounded-md"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="mx-2 text-sm text-white">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          className="w-6 h-6 flex items-center justify-center bg-gray-800 hover:bg-gray-700 rounded-md"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {cart.length > 0 && (
            <div className="p-4 border-t border-red-500/30 bg-black/80">
              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Subtotal</span>
                  <span className="text-white">{formatPrice(subtotal)}</span>
                </div>

                {discount > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-green-400 flex items-center">
                      <Tag className="w-3 h-3 mr-1" />
                      20% Discount
                    </span>
                    <span className="text-green-400">-{formatPrice(discount)}</span>
                  </div>
                )}

                <div className="flex justify-between text-base font-bold pt-2 border-t border-gray-700">
                  <span className="text-white">Total</span>
                  <span className="text-red-400">{formatPrice(total)}</span>
                </div>
              </div>

              {itemCount >= 2 && (
                <div className="bg-green-900/30 p-2 rounded border border-green-600/30 mb-4 flex items-center">
                  <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                  <span className="text-green-400 text-sm">20% discount applied for buying multiple items!</span>
                </div>
              )}

              {itemCount === 1 && (
                <div className="bg-red-900/30 p-2 rounded border border-red-600/30 mb-4 flex items-center">
                  <AlertCircle className="w-4 h-4 text-red-400 mr-2 flex-shrink-0" />
                  <span className="text-red-400 text-sm">Add one more item to get 20% off your entire order!</span>
                </div>
              )}

              <button
                onClick={() => {
                  setIsCartOpen(false)
                  setPurchaseStep(2)
                  completePurchase()
                }}
                className="w-full py-3 bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-bold rounded-lg flex items-center justify-center"
              >
                <CreditCard className="w-5 h-5 mr-2" />
                Checkout Now
              </button>
            </div>
          )}
        </div>
      </div>
    )
  }

  // Render purchase flow
  const renderPurchaseFlow = () => {
    if (!selectedProduct) return null

    if (purchaseStep === 1) {
      return (
        <div className="w-full max-w-4xl mx-auto bg-black/80 border border-red-500 rounded-lg p-6 md:p-8 animate-fadeIn">
          <button
            onClick={backToProducts}
            className="flex items-center text-red-500 hover:text-red-400 mb-6 transition-colors"
          >
            <ChevronLeft size={20} />
            <span>Back to products</span>
          </button>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            <div className="flex flex-col">
              {selectedProduct.image ? (
                <div className="relative h-64 md:h-80 w-full overflow-hidden rounded-lg border border-red-500/50 mb-4 group">
                  {selectedProduct.badge && (
                    <div className="absolute top-3 left-3 z-10 bg-red-600 text-white text-xs font-bold py-1 px-2 rounded">
                      {selectedProduct.badge}
                    </div>
                  )}
                  {selectedProduct.popular && (
                    <div className="absolute top-3 right-3 z-10 bg-yellow-500 text-black text-xs font-bold py-1 px-2 rounded-full animate-pulse">
                      HOT ITEM
                    </div>
                  )}
                  <Image
                    src={selectedProduct.image || "/placeholder.svg"}
                    alt={selectedProduct.name}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
              ) : (
                <div className="h-64 md:h-80 w-full rounded-lg border border-red-500/50 mb-4 bg-black/60 flex items-center justify-center">
                  <div className="w-24 h-24 rounded-full bg-red-900/30 flex items-center justify-center">
                    {getCategoryIcon(selectedProduct.category, selectedProduct)}
                  </div>
                  {selectedProduct.badge && (
                    <div className="absolute top-3 left-3 z-10 bg-red-600 text-white text-xs font-bold py-1 px-2 rounded">
                      {selectedProduct.badge}
                    </div>
                  )}
                  {selectedProduct.popular && (
                    <div className="absolute top-3 right-3 z-10 bg-yellow-500 text-black text-xs font-bold py-1 px-2 rounded-full animate-pulse">
                      HOT ITEM
                    </div>
                  )}
                </div>
              )}

              {/* Stock and recent sales indicator */}
              {selectedProduct.stock && (
                <div className="mb-4 flex flex-col gap-2">
                  <div className="bg-green-900/30 p-2 rounded border border-green-600/30 flex items-center">
                    <Users className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-green-400 text-sm font-medium">
                      {selectedProduct.stock} {selectedProduct.category === "account" ? "accounts" : "items"} in stock -
                      High demand!
                    </span>
                  </div>

                  {selectedProduct.soldRecently && (
                    <div className="bg-red-900/30 p-2 rounded border border-red-600/30 flex items-center">
                      <Users className="w-4 h-4 text-red-500 mr-2 flex-shrink-0" />
                      <span className="text-red-400 text-sm font-medium">
                        {selectedProduct.soldRecently} people bought this recently!
                      </span>
                    </div>
                  )}
                </div>
              )}

              <div className="bg-black/70 border border-red-500/30 rounded-lg p-4">
                <h3 className="text-xl font-semibold text-white mb-3 flex items-center">
                  <Shield className="w-5 h-5 text-red-500 mr-2" />
                  Premium Features
                </h3>
                <ul className="space-y-2">
                  {selectedProduct.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <Check size={18} className="text-red-500 mr-2 mt-1 flex-shrink-0" />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div>
              <div className="flex items-center mb-2">
                <h1 className="text-2xl md:text-3xl font-bold text-white">{selectedProduct.name}</h1>
                {selectedProduct.badge && (
                  <span className="ml-3 bg-red-600 text-white text-xs font-bold py-1 px-2 rounded">
                    {selectedProduct.badge}
                  </span>
                )}
              </div>

              {/* Price with discount */}
              <div className="flex items-center mb-4">
                <p className="text-2xl font-bold text-red-500">{formatPrice(selectedProduct.price)}</p>
                {selectedProduct.originalPrice && (
                  <>
                    <p className="ml-2 text-lg text-gray-500 line-through">
                      {formatPrice(selectedProduct.originalPrice)}
                    </p>
                    <span className="ml-2 bg-green-600 text-white text-xs font-bold py-1 px-2 rounded">
                      SAVE {formatPrice(selectedProduct.originalPrice - selectedProduct.price)}
                    </span>
                  </>
                )}
              </div>

              {/* Limited time offer countdown */}
              <div className="mb-4 bg-red-900/30 p-3 rounded border border-red-600/40 flex items-center">
                <Fire className="w-5 h-5 text-orange-500 mr-2 animate-pulse" />
                <div>
                  <p className="text-white font-medium">Limited Time Offer Ends In:</p>
                  <p className="text-xl font-bold text-white">{formatTime(timeLeft.minutes, timeLeft.seconds)}</p>
                </div>
              </div>

              <div className="bg-black/70 rounded-lg p-4 md:p-5 mb-6 border border-red-500/40">
                <p className="text-gray-300 mb-4">{selectedProduct.description}</p>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="flex items-center bg-red-900/20 p-2 rounded border border-red-600/30">
                    <Zap className="w-4 h-4 text-red-400 mr-2" />
                    <span className="text-red-300 text-sm font-medium">Instant Delivery</span>
                  </div>
                  <div className="flex items-center bg-red-900/20 p-2 rounded border border-red-600/30">
                    <Lock className="w-4 h-4 text-red-400 mr-2" />
                    <span className="text-red-300 text-sm font-medium">Fully Secured</span>
                  </div>
                </div>

                <div className="bg-red-900/20 p-3 rounded border border-red-600/30">
                  <p className="text-white font-medium">
                    <span className="font-bold">VIP Auto-delivery:</span> Add{" "}
                    <span className="font-bold text-red-400">poepx</span> on Discord after purchase for immediate
                    delivery!
                  </p>
                </div>
              </div>

              {/* Multi-buy discount promo */}
              <div className="mb-4 bg-green-900/30 p-3 rounded border border-green-600/30 flex items-center">
                <Tag className="w-5 h-5 text-green-500 mr-2" />
                <p className="text-green-400 text-sm font-medium">
                  <span className="font-bold">SPECIAL OFFER:</span> Buy 2 or more items and get 20% OFF your entire
                  order!
                </p>
              </div>

              {/* Live viewers indicator */}
              <div className="mb-4 bg-black/70 p-3 rounded border border-red-500/30 flex items-center">
                <Users className="w-4 h-4 text-red-400 mr-2" />
                <p className="text-gray-300 text-sm">
                  <span className="text-red-400 font-bold">{viewersCount} people</span> are viewing this product right
                  now
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <button
                  onClick={() => addToCart(selectedProduct)}
                  className="py-3 px-4 bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-bold rounded-lg transition-colors flex items-center justify-center"
                >
                  <ShoppingCart className="w-5 h-5 mr-2" />
                  Add to Cart
                </button>

                <button
                  onClick={() => {
                    addToCart(selectedProduct)
                    setTimeout(() => {
                      setIsCartOpen(false)
                      setPurchaseStep(2)
                      completePurchase()
                    }, 500)
                  }}
                  className="py-3 px-4 bg-gradient-to-r from-green-600 to-green-800 hover:from-green-700 hover:to-green-900 text-white font-bold rounded-lg transition-colors flex items-center justify-center"
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  Buy Now
                </button>
              </div>

              {/* Money-back guarantee */}
              <div className="text-center">
                <p className="text-sm text-gray-400 flex items-center justify-center">
                  <Shield className="w-4 h-4 mr-1 text-green-500" />
                  100% Satisfaction Guaranteed or Money Back
                </p>
              </div>
            </div>
          </div>
        </div>
      )
    }

    if (purchaseStep === 2) {
      return (
        <div className="w-full max-w-2xl mx-auto bg-black/80 border border-red-500 rounded-lg p-8 animate-fadeIn text-center">
          <div className="w-16 h-16 bg-red-600 rounded-full mx-auto mb-6 flex items-center justify-center">
            <Check size={32} className="text-white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">Thank You For Your Purchase!</h2>
          <p className="text-gray-300 mb-6">
            Your order has been received. Please <span className="font-bold text-red-400">add poepx on Discord</span> to
            buy your account!
          </p>
          <div className="bg-red-900/20 p-4 rounded-lg border border-red-600/30 mb-6 inline-block">
            <p className="text-white font-medium">
              Add on Discord: <span className="font-bold text-red-400">poepx</span>
            </p>
          </div>
          <button
            onClick={backToProducts}
            className="py-2 px-4 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition-colors"
          >
            Return to Store
          </button>
        </div>
      )
    }

    return null
  }

  // Render category tabs
  const renderCategoryTabs = () => {
    return (
      <div className="flex flex-wrap justify-center gap-3 mb-8">
        <button
          onClick={() => setActiveCategory("all")}
          className={`px-4 py-2 rounded-md transition-all ${
            activeCategory === "all"
              ? "bg-red-600 text-white shadow-lg shadow-red-500/20"
              : "bg-red-900/30 text-gray-300 hover:bg-red-800/40"
          }`}
        >
          All Products
        </button>
        <button
          onClick={() => setActiveCategory("account")}
          className={`px-4 py-2 rounded-md transition-all ${
            activeCategory === "account"
              ? "bg-red-600 text-white shadow-lg shadow-red-500/20"
              : "bg-red-900/30 text-gray-300 hover:bg-red-800/40"
          }`}
        >
          Accounts
        </button>
        <button
          onClick={() => setActiveCategory("tool")}
          className={`px-4 py-2 rounded-md transition-all ${
            activeCategory === "tool"
              ? "bg-red-600 text-white shadow-lg shadow-red-500/20"
              : "bg-red-900/30 text-gray-300 hover:bg-red-800/40"
          }`}
        >
          Tools
        </button>
        <button
          onClick={() => setActiveCategory("service")}
          className={`px-4 py-2 rounded-md transition-all ${
            activeCategory === "service"
              ? "bg-red-600 text-white shadow-lg shadow-red-500/20"
              : "bg-red-900/30 text-gray-300 hover:bg-red-800/40"
          }`}
        >
          Services
        </button>
      </div>
    )
  }

  // Render product grid
  const renderProductGrid = () => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-5xl mx-auto">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="bg-black/80 border border-red-500/50 rounded-lg overflow-hidden transition-all duration-300 transform hover:scale-105 hover:shadow-[0_0_15px_rgba(239,68,68,0.5)]"
          >
            <div className="relative h-48 w-full overflow-hidden group">
              {product.badge && (
                <div className="absolute top-3 left-3 z-10 bg-red-600 text-white text-xs font-bold py-1 px-2 rounded">
                  {product.badge}
                </div>
              )}
              {product.popular && (
                <div className="absolute top-3 right-3 z-10 bg-yellow-500 text-black text-xs font-bold py-1 px-2 rounded-full animate-pulse">
                  HOT ITEM
                </div>
              )}
              {product.image ? (
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
              ) : (
                <div className="w-full h-full bg-black/60 flex items-center justify-center">
                  <div className="w-20 h-20 rounded-full bg-red-900/30 flex items-center justify-center">
                    {getCategoryIcon(product.category, product)}
                  </div>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="absolute bottom-0 left-0 right-0 p-3 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <button
                  onClick={() => viewProductDetails(product)}
                  className="w-full py-2 px-3 bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-medium rounded-lg transition-colors text-sm"
                >
                  View Details
                </button>
              </div>
            </div>
            <div className="p-5">
              <div className="flex justify-between items-start mb-2">
                <h2 className="text-xl font-bold text-white">{product.name}</h2>
                <div className="flex flex-col items-end">
                  <span className="text-red-500 font-bold text-xl">{formatPrice(product.price)}</span>
                  {product.originalPrice && (
                    <span className="text-sm text-gray-500 line-through">{formatPrice(product.originalPrice)}</span>
                  )}
                </div>
              </div>
              <p className="text-gray-300 mb-4 line-clamp-2">{product.description}</p>

              {/* Stock indicator */}
              {product.stock && (
                <div className="mb-3 text-sm text-green-400 flex items-center">
                  <Users className="w-3 h-3 mr-1" />
                  {product.stock} in stock | {product.soldRecently || 0} sold recently
                </div>
              )}
            </div>
            <div className="px-5 pb-5 grid grid-cols-2 gap-2">
              <button
                onClick={() => addToCart(product)}
                className="py-2 px-3 bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-medium rounded-lg transition-colors flex items-center justify-center"
              >
                <ShoppingCart className="w-4 h-4 mr-1" />
                Add to Cart
              </button>

              <button
                onClick={() => viewProductDetails(product)}
                className="py-2 px-3 bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900 text-white font-medium rounded-lg transition-colors flex items-center justify-center"
              >
                <Zap className="w-4 h-4 mr-1" />
                Details
              </button>
            </div>
          </div>
        ))}
      </div>
    )
  }

  // Main render
  return (
    <main className="min-h-screen relative overflow-hidden bg-black text-white">
      {/* Background particle effect - EXACTLY matching cookie-refresher */}
      <div className="fixed inset-0 z-0">
        <RedParticleCanvas />
      </div>

      {/* Shopping cart */}
      {renderCart()}

      {/* Cart toggle button */}
      <button
        onClick={() => setIsCartOpen(true)}
        className="fixed bottom-6 right-6 z-40 bg-red-600 hover:bg-red-700 text-white p-3 rounded-full shadow-lg flex items-center justify-center"
      >
        <ShoppingCart className="w-6 h-6" />
        {cart.length > 0 && (
          <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
            {cart.reduce((count, item) => count + item.quantity, 0)}
          </span>
        )}
      </button>

      {/* Content container with z-index to appear above particles */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 py-8 flex flex-col items-center min-h-screen">
        {/* Header */}
        <div className="w-full flex justify-between items-center mb-8">
          <Link href="/" className="flex items-center text-red-500 hover:text-red-400 transition-colors">
            <ChevronLeft size={20} />
            <span>Back to Home</span>
          </Link>
          <h1 className="text-3xl font-bold text-white">Premium Store</h1>
          <div className="w-8"></div> {/* Spacer to keep header centered */}
        </div>

        {/* Store content */}
        {isClient && (
          <>
            {selectedProduct && purchaseStep > 0 ? (
              renderPurchaseFlow()
            ) : (
              <>
                {/* Flash Sale Banner */}
                <div className="w-full max-w-4xl mx-auto bg-gradient-to-r from-red-900/80 to-black/80 border-2 border-red-500 rounded-lg p-4 mb-8 relative overflow-hidden">
                  <div className="absolute inset-0 overflow-hidden">
                    <div className="sparkle-bg"></div>
                  </div>
                  <div className="relative z-10">
                    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                      <div className="flex items-center">
                        <div className="bg-red-500 rounded-full p-2 mr-4 hidden sm:block">
                          <Fire className="w-8 h-8 text-black" />
                        </div>
                        <div>
                          <h2 className="text-2xl font-bold text-white mb-1 flex items-center">
                            <Sparkles className="w-5 h-5 text-yellow-400 mr-2 inline-block" />
                            FLASH SALE
                            <Sparkles className="w-5 h-5 text-yellow-400 ml-2 inline-block" />
                          </h2>
                          <div className="flex items-center">
                            <p className="text-red-300 font-medium mr-2">Ends in:</p>
                            <p className="text-xl font-bold text-white">
                              {formatTime(timeLeft.minutes, timeLeft.seconds)}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <p className="text-white font-bold text-lg">UP TO 70% OFF!</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Category tabs */}
                {renderCategoryTabs()}

                {/* Product grid */}
                <div className="product-grid">{renderProductGrid()}</div>

                {/* Multi-buy promo */}
                <div className="w-full max-w-4xl mx-auto mt-12 bg-black/80 border border-red-500 rounded-lg p-6 mb-8">
                  <div className="flex flex-col md:flex-row justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-red-500 mb-2 md:mb-0">Special Discount Offer</h2>
                  </div>

                  <p className="text-gray-300 mb-4">
                    <span className="font-bold text-white">SAVE BIG:</span> Purchase any 2 or more items and
                    automatically receive a <span className="text-red-400 font-bold">20% DISCOUNT</span> on your entire
                    order! This limited-time offer applies to all products in our store.
                  </p>

                  <div className="bg-red-900/20 p-3 rounded border border-red-600/30">
                    <div className="flex items-start">
                      <Tag className="w-5 h-5 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                      <p className="text-white">
                        <span className="font-bold text-yellow-400">HOW IT WORKS:</span> Simply add 2 or more items to
                        your cart, and the discount will be automatically applied at checkout! Contact{" "}
                        <span className="font-bold text-red-400">poepx</span> on Discord for immediate delivery after
                        purchase.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Trust indicators */}
                <div className="w-full max-w-4xl mx-auto mt-8 bg-black/80 border border-red-500 rounded-lg p-6">
                  <h3 className="text-xl font-bold text-white mb-6 text-center">Why Choose Our Premium Products</h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-black/50 p-5 rounded-lg border border-red-500/30 flex flex-col items-center text-center">
                      <div className="w-14 h-14 bg-red-900/50 rounded-full flex items-center justify-center mb-4 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
                        <Zap className="w-7 h-7 text-red-400" />
                      </div>
                      <h4 className="text-lg font-semibold text-white mb-2">Instant Delivery</h4>
                      <p className="text-gray-300 text-sm">
                        Get your products immediately after payment confirmation. No waiting, start using your purchase
                        right away.
                      </p>
                    </div>

                    <div className="bg-black/50 p-5 rounded-lg border border-red-500/30 flex flex-col items-center text-center">
                      <div className="w-14 h-14 bg-red-900/50 rounded-full flex items-center justify-center mb-4 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
                        <Lock className="w-7 h-7 text-red-400" />
                      </div>
                      <h4 className="text-lg font-semibold text-white mb-2">100% Secured</h4>
                      <p className="text-gray-300 text-sm">
                        All products come with full access and secure transfer protocols. Your purchase is protected and
                        guaranteed with our VIP security system.
                      </p>
                    </div>

                    <div className="bg-black/50 p-5 rounded-lg border border-red-500/30 flex flex-col items-center text-center">
                      <div className="w-14 h-14 bg-red-900/50 rounded-full flex items-center justify-center mb-4 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
                        <Award className="w-7 h-7 text-red-400" />
                      </div>
                      <h4 className="text-lg font-semibold text-white mb-2">Premium Quality</h4>
                      <p className="text-gray-300 text-sm">
                        Only the highest quality products with exclusive features. Our tools and services are trusted by
                        thousands of satisfied customers.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Vouches Button */}
                <div className="w-full max-w-4xl mx-auto mt-8 text-center">
                  <Link
                    href="/vouches"
                    className="inline-block py-3 px-6 bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900 text-white font-bold rounded-lg transition-colors text-lg shadow-lg border border-red-500/50 flex items-center gap-2 justify-center"
                  >
                    <MessageSquare className="w-5 h-5" />
                    <span>View Customer Vouches</span>
                  </Link>
                </div>
              </>
            )}
          </>
        )}

        {/* Footer */}
        <footer className="mt-16 text-center text-gray-400">
          <p>© {new Date().getFullYear()} Poepbeamz. All rights reserved.</p>
          <p className="mt-2 text-sm">Premium Store</p>
        </footer>
      </div>

      <style jsx global>{`
        @keyframes pulse-animation {
          0% {
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
            transform: scale(1);
          }
          50% {
            box-shadow: 0 0 0 10px rgba(239, 68, 68, 0);
            transform: scale(1.02);
          }
          100% {
            box-shadow: 0 0 0 0 rgba(239, 68, 68, 0);
            transform: scale(1);
          }
        }
        
        @keyframes sparkle {
          0% {
            background-position: 0% 0%;
          }
          100% {
            background-position: 200% 200%;
          }
        }
        
        .sparkle-bg {
          position: absolute;
          top: -50%;
          left: -50%;
          right: -50%;
          bottom: -50%;
          background-image: radial-gradient(circle, rgba(255, 255, 255, 0.1) 1px, transparent 1px);
          background-size: 20px 20px;
          animation: sparkle 15s linear infinite;
          opacity: 0.5;
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.3s ease-in-out;
        }
      `}</style>
    </main>
  )
}
