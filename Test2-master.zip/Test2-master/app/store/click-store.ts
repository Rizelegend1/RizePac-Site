// Global store for click counts
// This would be replaced with a database in a production environment

// Define the type for our global store
declare global {
  var clickCounts: Map<string, number>
}

// Initialize the global store if it doesn't exist
if (!global.clickCounts) {
  global.clickCounts = new Map<string, number>()
}

export function getClickCount(id: string): number {
  return global.clickCounts.get(id) || 0
}

export function incrementClickCount(id: string): number {
  const currentCount = getClickCount(id)
  const newCount = currentCount + 1
  global.clickCounts.set(id, newCount)
  return newCount
}

export function setClickCount(id: string, count: number): void {
  global.clickCounts.set(id, count)
}

export function getAllClickCounts(): Map<string, number> {
  return global.clickCounts
}
