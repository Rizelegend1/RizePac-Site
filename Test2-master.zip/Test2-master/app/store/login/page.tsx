"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { ShoppingCart, Lock, User, Eye, EyeOff, ChevronLeft, AlertCircle } from "lucide-react"

export default function StoreLoginPage() {
  const router = useRouter()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [canvasRef, setCanvasRef] = useState<HTMLCanvasElement | null>(null)

  // Background canvas effect
  useEffect(() => {
    if (!canvasRef) return

    const ctx = canvasRef.getContext("2d")
    if (!ctx) return

    try {
      const updateSize = () => {
        canvasRef.width = window.innerWidth
        canvasRef.height = Math.max(window.innerHeight, document.body.scrollHeight)
      }
      updateSize()
      window.addEventListener("resize", updateSize)

      // Create an observer to update canvas height when content changes
      const resizeObserver = new ResizeObserver(() => {
        canvasRef.height = Math.max(window.innerHeight, document.body.scrollHeight)
      })
      resizeObserver.observe(document.body)

      // Inside the useEffect hook where particles are created
      const purpleParticles: { x: number; y: number; speed: number; size: number; opacity: number }[] = []
      const whiteParticles: { x: number; y: number; speed: number; size: number; opacity: number }[] = []

      // Keep the existing purple particles count
      const purpleParticleCount = window.innerWidth <= 640 ? 135 : 270 // 30% more than the original

      // Add 50% more white particles
      const whiteParticleCount = Math.floor(purpleParticleCount * 0.5)

      for (let i = 0; i < purpleParticleCount; i++) {
        purpleParticles.push({
          x: Math.random() * canvasRef.width,
          y: Math.random() * canvasRef.height,
          speed: 0.2 + Math.random() * 0.3,
          size: 0.5 + Math.random() * 1.5,
          opacity: 0.3 + Math.random() * 0.7,
        })
      }

      // Add white particles with similar properties
      for (let i = 0; i < whiteParticleCount; i++) {
        whiteParticles.push({
          x: Math.random() * canvasRef.width,
          y: Math.random() * canvasRef.height,
          speed: 0.2 + Math.random() * 0.3,
          size: 0.5 + Math.random() * 1.5,
          opacity: 0.3 + Math.random() * 0.7,
        })
      }

      let animationFrameId: number

      function animate() {
        if (!ctx || !canvasRef) return

        ctx.clearRect(0, 0, canvasRef.width, canvasRef.height)

        // Draw purple particles
        purpleParticles.forEach((particle) => {
          ctx.fillStyle = `rgba(139, 92, 246, ${particle.opacity})` // Purple color (tailwind purple-500)
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()

          particle.y += particle.speed
          if (particle.y > canvasRef.height) {
            particle.y = 0
            particle.x = Math.random() * canvasRef.width
          }
        })

        // Draw white particles
        whiteParticles.forEach((particle) => {
          ctx.fillStyle = `rgba(255, 255, 255, ${particle.opacity})`
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()

          particle.y += particle.speed
          if (particle.y > canvasRef.height) {
            particle.y = 0
            particle.x = Math.random() * canvasRef.width
          }
        })

        animationFrameId = requestAnimationFrame(animate)
      }

      animate()

      return () => {
        window.removeEventListener("resize", updateSize)
        resizeObserver.disconnect()
        cancelAnimationFrame(animationFrameId)
      }
    } catch (error) {
      console.error("Canvas error:", error)
    }
  }, [canvasRef])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    // Simple validation
    if (!username || !password) {
      setError("Please enter both username and password")
      setLoading(false)
      return
    }

    // Simulate login - in a real app, this would be an API call
    setTimeout(() => {
      // For demo purposes, accept any login
      router.push("/store")
      setLoading(false)
    }, 1500)
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* Canvas background */}
      <canvas
        ref={setCanvasRef}
        className="fixed inset-0 pointer-events-none z-0"
        style={{
          width: "100%",
          height: "100%",
          position: "fixed",
          top: 0,
          left: 0,
        }}
      />

      {/* Back to home button */}
      <div className="fixed top-4 left-4 z-50">
        <Link
          href="/"
          className="bg-black/80 border-2 border-purple-500/50 rounded-full p-3 shadow-lg relative overflow-hidden group hover:border-purple-500/80 hover:scale-110 transition-all duration-300 flex items-center justify-center"
          style={{ boxShadow: "0 0 15px rgba(139, 92, 246, 0.5), 0 0 30px rgba(139, 92, 246, 0.3)" }}
        >
          <ChevronLeft className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6 relative z-10" />
          <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
        </Link>
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="bg-black/80 border border-purple-500/30 rounded-xl p-8 shadow-xl purple-glow-container">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-4">
                <div className="relative w-16 h-16">
                  <Image src="/poepbeamz-new-logo.png" alt="Poepbeamz Logo" fill className="object-contain" />
                </div>
              </div>
              <h1 className="text-2xl font-bold text-white">Premium Store Login</h1>
              <p className="text-gray-400 mt-2">Sign in to access exclusive accounts</p>
            </div>

            {error && (
              <div className="mb-6 p-3 bg-red-900/20 border border-red-500/30 rounded-lg flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <p className="text-red-200 text-sm">{error}</p>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label htmlFor="username" className="block text-sm font-medium text-gray-300 mb-1">
                  Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <User className="h-5 w-5 text-gray-500" />
                  </div>
                  <input
                    id="username"
                    name="username"
                    type="text"
                    autoComplete="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    className="block w-full pl-10 pr-3 py-2 border border-gray-700 rounded-md bg-black/50 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="Enter your username"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-300 mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-500" />
                  </div>
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="block w-full pl-10 pr-10 py-2 border border-gray-700 rounded-md bg-black/50 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="Enter your password"
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-gray-500 hover:text-gray-300 focus:outline-none"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  disabled={loading}
                  className={`w-full flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 ${
                    loading ? "opacity-70 cursor-not-allowed" : ""
                  }`}
                >
                  {loading ? (
                    <>
                      <svg
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        ></circle>
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Signing in...
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      Sign in to Store
                    </>
                  )}
                </button>
              </div>
            </form>

            <div className="mt-6 text-center">
              <p className="text-sm text-gray-400">
                Don't have an account?{" "}
                <Link href="/store" className="text-purple-400 hover:text-purple-300 font-medium">
                  Continue as guest
                </Link>
              </p>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-800">
              <p className="text-xs text-center text-gray-500">
                By signing in, you agree to our Terms of Service and Privacy Policy.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
