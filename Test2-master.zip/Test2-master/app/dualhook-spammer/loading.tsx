import { Loader2 } from "lucide-react"

export default function Loading() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="w-10 h-10 text-purple-500 animate-spin" />
        <h2 className="text-xl font-bold text-purple-400">Loading Dualhook Spammer...</h2>
        <p className="text-gray-400 text-sm">Please wait while we set up your dualhook environment</p>
      </div>
    </div>
  )
}
