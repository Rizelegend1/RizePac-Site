"use client"

import { useEffect } from "react"

export function useTouchEvents() {
  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      document.body.classList.add("touch-device")
    }

    const handleMouseStart = (e: MouseEvent) => {
      document.body.classList.remove("touch-device")
    }

    document.addEventListener("touchstart", handleTouchStart, { once: true, passive: true })
    document.addEventListener("mousedown", handleMouseStart, { once: true })

    return () => {
      document.removeEventListener("touchstart", handleTouchStart)
      document.removeEventListener("mousedown", handleMouseStart)
    }
  }, [])
}
