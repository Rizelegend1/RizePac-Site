import { Loader2 } from "lucide-react"
import { PurpleParticleCanvas } from "@/components/purple-particle-canvas"

export default function Loading() {
  return (
    <>
      <PurpleParticleCanvas />
      <div className="min-h-screen flex flex-col items-center justify-center p-4 relative z-10">
        <div className="bg-black/80 backdrop-blur-md border border-purple-500/30 rounded-lg shadow-xl p-8 max-w-md w-full text-center">
          <Loader2 className="w-12 h-12 text-purple-500 animate-spin mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">Loading...</h1>
          <p className="text-gray-300">Please wait while we prepare your money-making tools.</p>
        </div>
      </div>
    </>
  )
}
