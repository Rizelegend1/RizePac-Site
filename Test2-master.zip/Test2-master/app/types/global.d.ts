// Add global type definitions
interface Window {
  clickCounters?: {
    [key: string]: number
  }
}
