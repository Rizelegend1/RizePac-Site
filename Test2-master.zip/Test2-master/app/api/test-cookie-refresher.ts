"use server"

import { checkRobloxCookie } from "./cookie-actions"

// This function is used for testing the cookie refresher functionality
export async function testCookieRefresher(testMode = "success") {
  try {
    console.log(`[TEST] Running cookie refresher test in ${testMode} mode`)

    // Create a mock form data with a test cookie
    const formData = new FormData()

    if (testMode === "success") {
      formData.append(
        "cookie",
        "_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_TESTCOOKIE123456789",
      )
    } else if (testMode === "invalid") {
      formData.append("cookie", "invalid_cookie_format")
    } else if (testMode === "empty") {
      formData.append("cookie", "")
    }

    // Call the actual cookie checker function
    const result = await checkRobloxCookie(formData)

    console.log("[TEST] Test completed with result:", result.success)

    return {
      success: true,
      testMode,
      result,
    }
  } catch (error) {
    console.error("[TEST] Test failed with error:", error)

    return {
      success: false,
      testMode,
      error: error instanceof Error ? error.message : String(error),
    }
  }
}
