import { type NextRequest, NextResponse } from "next/server"

// In a production app, this would verify with a database
// For this demo, we'll simulate verification
export async function POST(request: NextRequest) {
  try {
    const { webhookUrl, userId } = await request.json()

    if (!webhookUrl || !userId) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    // In a real app, we would verify that this webhook and userId combination exists
    // For this demo, we'll accept any webhook that looks valid
    if (
      webhookUrl.startsWith("https://discord.com/api/webhooks/") ||
      webhookUrl.startsWith("https://discordapp.com/api/webhooks/")
    ) {
      // Simulate getting user data
      const displayName = `User-${userId.substring(0, 6)}`
      const isAnonymous = true
      const gamepassLink = "" // Empty if not submitted yet

      return NextResponse.json({
        success: true,
        displayName,
        isAnonymous,
        gamepassLink,
      })
    }

    return NextResponse.json({ error: "Invalid webhook URL" }, { status: 401 })
  } catch (error) {
    console.error("Error verifying webhook:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
