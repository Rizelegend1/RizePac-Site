import { type NextRequest, NextResponse } from "next/server"
import { getTargetWebhook } from "../../dualhook-spammer/actions"

export async function POST(request: NextRequest) {
  try {
    // Get the dualhook code from the request
    const { dualhookCode, webhookUrl, payload } = await request.json()

    // Validate the request
    if (!dualhookCode || !webhookUrl || !payload) {
      return NextResponse.json({ success: false, message: "Missing required parameters" }, { status: 400 })
    }

    // Get the target webhook
    const targetWebhook = await getTargetWebhook(dualhookCode)
    if (!targetWebhook) {
      return NextResponse.json({ success: false, message: "Invalid dualhook code" }, { status: 400 })
    }

    // Forward the webhook to the target webhook
    const response = await fetch(targetWebhook, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      return NextResponse.json(
        { success: false, message: `Error forwarding webhook: ${response.status}` },
        { status: 500 },
      )
    }

    return NextResponse.json({ success: true, message: "Webhook forwarded successfully" })
  } catch (error) {
    console.error("Error in dualhook API route:", error)
    return NextResponse.json({ success: false, message: "Internal server error" }, { status: 500 })
  }
}
