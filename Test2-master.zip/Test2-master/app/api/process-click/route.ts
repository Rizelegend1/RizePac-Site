import { type NextRequest, NextResponse } from "next/server"

// In-memory store for click counts
// This would be replaced with a database in a production environment
const clickCounts = new Map<string, number>()

// Track IP addresses that have clicked each link
const clickedIPs = new Map<string, Set<string>>()

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const id = searchParams.get("id")
    const ip = searchParams.get("ip") || "127.0.0.1"
    const userAgent = searchParams.get("userAgent") || "Unknown"
    const referrer = searchParams.get("referrer") || "Direct"

    if (!id) {
      console.error("Missing ID parameter in process-click")
      return NextResponse.json({ error: "Missing ID parameter" }, { status: 400 })
    }

    console.log(`Processing click for ID: ${id}, IP: ${ip}`)

    // Check if this IP has already clicked this link
    if (!clickedIPs.has(id)) {
      clickedIPs.set(id, new Set())
    }

    const ipSet = clickedIPs.get(id)!

    // If this IP has already clicked, don't count it again and send a red embedded message
    if (ipSet.has(ip)) {
      console.log(`IP ${ip} has already clicked link ${id}, not counting again`)

      // Get the webhook URL from our registry
      let webhookUrl = null
      try {
        const webhookResponse = await fetch(`${request.nextUrl.origin}/api/register-link?id=${id}`)
        if (webhookResponse.ok) {
          const data = await webhookResponse.json()
          webhookUrl = data.webhookUrl
        } else {
          console.warn(`No webhook URL found in registry for ID: ${id}`)
          // Try to get from environment variable as fallback
          webhookUrl = process.env.DISCORD_WEBHOOK_URL || null
        }
      } catch (error) {
        console.error("Error retrieving webhook URL:", error)
      }

      // If we have a webhook URL, send a notification about the duplicate click attempt
      if (webhookUrl) {
        try {
          // Send webhook notification with red embed and the requested message
          const webhookResponse = await fetch(webhookUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              embeds: [
                {
                  title: "🚨 DUPLICATE CLICK DETECTED",
                  description:
                    "GOOD TRY U MONKEY! CLICKING ON THE SAME LINK TWICE WONT WORK U CLOWN! GO GET REAL PEOPLE! -poep",
                  color: 15158332, // Red color
                  thumbnail: {
                    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
                  },
                  fields: [
                    {
                      name: "🆔 Link ID",
                      value: `\`${id}\``,
                      inline: false,
                    },
                    {
                      name: "🌐 IP Address",
                      value: `\`${ip}\``,
                      inline: true,
                    },
                    {
                      name: "🖥️ Device",
                      value: getDeviceInfo(userAgent),
                      inline: true,
                    },
                    {
                      name: "⏰ Timestamp",
                      value: new Date().toLocaleString(),
                      inline: false,
                    },
                  ],
                  footer: {
                    text: "© 2025 Shockify — All Rights Reserved.",
                    icon_url:
                      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
                  },
                },
              ],
            }),
          })

          if (!webhookResponse.ok) {
            console.error(`Webhook error: ${webhookResponse.status} ${await webhookResponse.text()}`)
          } else {
            console.log(`Successfully sent duplicate click notification for ID: ${id}`)
          }
        } catch (webhookError) {
          console.error("Error sending webhook notification:", webhookError)
        }
      }

      return new NextResponse(
        `
    <!DOCTYPE html>
    <html>
      <head>
        <title>Already Clicked</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script>
          // Redirect to home page after a short delay
          setTimeout(() => {
            window.location.href = "/";
          }, 1500);
        </script>
        <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #000;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 20px;
            text-align: center;
          }
          .message {
            background-color: rgba(220, 38, 38, 0.1);
            border: 1px solid rgba(220, 38, 38, 0.3);
            border-radius: 8px;
            padding: 20px;
            max-width: 400px;
          }
          h2 {
            color: #ef4444;
            margin-top: 0;
          }
        </style>
      </head>
      <body>
        <div class="message">
          <h2>Nice Try!</h2>
          <p>You've already clicked this link. Each IP address can only count once.</p>
          <p>Redirecting to home page...</p>
        </div>
      </body>
    </html>
  `,
        {
          headers: {
            "Content-Type": "text/html",
          },
        },
      )
    }

    // Add this IP to the set of IPs that have clicked this link
    ipSet.add(ip)

    // Increment the click count
    const currentCount = clickCounts.get(id) || 0
    const newCount = currentCount + 1
    clickCounts.set(id, newCount)

    console.log(`Updated click count for ${id}: ${newCount}`)

    // Get the link data from our registry
    let linkData = null
    let referrerData = null
    try {
      const linkResponse = await fetch(`${request.nextUrl.origin}/api/register-link?id=${id}`)
      if (linkResponse.ok) {
        linkData = await linkResponse.json()

        // If this link has a referral code, also update the referrer's click count
        if (linkData.referralCode) {
          // Get the referrer's data
          const referrerResponse = await fetch(
            `${request.nextUrl.origin}/api/register-link?id=${linkData.referralCode}`,
          )
          if (referrerResponse.ok) {
            referrerData = await referrerResponse.json()

            // Check if this IP has already clicked the referrer's link
            if (!clickedIPs.has(linkData.referralCode)) {
              clickedIPs.set(linkData.referralCode, new Set())
            }

            const referrerIpSet = clickedIPs.get(linkData.referralCode)!

            // Always count this click for the referrer - DUAL BENEFIT SYSTEM
            // This is the key change - we're not checking if the IP has clicked before
            // We're giving credit to the referrer for every click on the referred user's link

            // Increment the referrer's click count
            const referrerCurrentCount = clickCounts.get(linkData.referralCode) || 0
            const referrerNewCount = referrerCurrentCount + 1
            clickCounts.set(linkData.referralCode, referrerNewCount)

            console.log(
              `Updated referrer ${linkData.referralCode} click count: ${referrerNewCount} (DUAL BENEFIT SYSTEM)`,
            )

            // Send notification to referrer about the click
            if (referrerData.webhookUrl) {
              try {
                await fetch(referrerData.webhookUrl, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    embeds: [
                      {
                        title: "💰 PASSIVE INCOME ALERT! 💰",
                        description: `Someone clicked on your referral's link! Thanks to the **DOUBLE PROFIT SYSTEM**, you've earned credit for this click without doing anything!`,
                        color: 5763719, // Green color
                        thumbnail: {
                          url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
                        },
                        fields: [
                          {
                            name: "🆔 Referral ID",
                            value: `\`${id}\``,
                            inline: true,
                          },
                          {
                            name: "📊 Your Current Clicks",
                            value: `${referrerNewCount}/100`,
                            inline: true,
                          },
                          {
                            name: "📈 Your Progress",
                            value: `${Math.min(Math.round((referrerNewCount / 100) * 100), 100)}%`,
                            inline: true,
                          },
                          {
                            name: "💎 PASSIVE INCOME SYSTEM",
                            value:
                              "This is how the richest Shockify users make THOUSANDS of Robux! Keep referring more people to multiply your earnings!",
                            inline: false,
                          },
                        ],
                        footer: {
                          text: "© 2025 Shockify — All Rights Reserved.",
                          icon_url:
                            "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
                        },
                      },
                    ],
                  }),
                })
              } catch (referrerWebhookError) {
                console.error("Error sending referrer webhook notification:", referrerWebhookError)
              }
            }
          }
        }
      }
    } catch (error) {
      console.error("Error retrieving link data:", error)
    }

    // Get the webhook URL
    const webhookUrl = linkData?.webhookUrl || process.env.DISCORD_WEBHOOK_URL || null

    // If we have a webhook URL, send a notification
    if (webhookUrl) {
      try {
        // Get geolocation info based on IP
        const geoInfo = await getGeoInfo(ip)
        const timestamp = new Date().toISOString()

        // Send webhook notification
        const webhookResponse = await fetch(webhookUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            embeds: [
              {
                title: "🔔 New Click Detected",
                description: `Someone clicked on your tracking link with ID: \`${id}\``,
                color: 10181046, // Purple color
                thumbnail: {
                  url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
                },
                fields: [
                  {
                    name: "🆔 Link ID",
                    value: `\`${id}\``,
                    inline: false,
                  },
                  {
                    name: "📊 Current Clicks",
                    value: `${newCount}/100`,
                    inline: true,
                  },
                  {
                    name: "📈 Progress",
                    value: `${Math.min(Math.round((newCount / 100) * 100), 100)}%`,
                    inline: true,
                  },
                  {
                    name: "🌐 IP Address",
                    value: `\`${ip}\``,
                    inline: true,
                  },
                  {
                    name: "📍 Location",
                    value: geoInfo.location,
                    inline: true,
                  },
                  {
                    name: "🖥️ Device",
                    value: getDeviceInfo(userAgent),
                    inline: false,
                  },
                  {
                    name: "🔍 Referrer",
                    value: referrer,
                    inline: false,
                  },
                  {
                    name: "⏰ Timestamp",
                    value: new Date().toLocaleString(),
                    inline: false,
                  },
                  {
                    name: linkData?.referralCode ? "💰 REFERRAL BONUS" : "💡 PRO TIP",
                    value: linkData?.referralCode
                      ? "This click is also counting for your referrer! Use the referral system to earn DOUBLE PROFITS!"
                      : "Use the referral system to DOUBLE YOUR PROFITS! When people use your referral link, their clicks count for you too!",
                    inline: false,
                  },
                ],
                footer: {
                  text: "© 2025 Shockify — All Rights Reserved.",
                  icon_url:
                    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
                },
              },
            ],
          }),
        })

        if (!webhookResponse.ok) {
          console.error(`Webhook error: ${webhookResponse.status} ${await webhookResponse.text()}`)
        } else {
          console.log(`Successfully sent webhook notification for ID: ${id}`)
        }
      } catch (webhookError) {
        console.error("Error sending webhook notification:", webhookError)
      }
    } else {
      console.warn("No webhook URL found for click processing")
    }

    // Return HTML with script to update localStorage
    // This helps synchronize the click count across different browser sessions
    return new NextResponse(
      `
  <!DOCTYPE html>
  <html>
    <head>
      <title>Processing Click</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <script>
        try {
          localStorage.setItem("clickCount_${id}", "${newCount}");
          if (window.clickCounters) {
            window.clickCounters["${id}"] = ${newCount};
          }
          console.log("Updated click count for ${id} to ${newCount}");
          
          // Broadcast the click event to other tabs
          try {
            const broadcastChannel = new BroadcastChannel('click_updates');
            broadcastChannel.postMessage({
              id: "${id}",
              count: ${newCount}
            });
          } catch (e) {
            console.error("Error broadcasting click update:", e);
          }
        } catch (e) {
          console.error("Error updating click count:", e);
        }
        
        // Redirect to home page after a short delay
        setTimeout(() => {
          window.location.href = "/";
        }, 1500);
      </script>
      <style>
        body {
          font-family: Arial, sans-serif;
          background-color: #000;
          color: #fff;
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
          margin: 0;
          padding: 20px;
          text-align: center;
        }
        .message {
          background-color: rgba(139, 92, 246, 0.1);
          border: 1px solid rgba(139, 92, 246, 0.3);
          border-radius: 8px;
          padding: 20px;
          max-width: 400px;
        }
        h2 {
          color: #a855f7;
          margin-top: 0;
        }
      </style>
    </head>
    <body>
      <div class="message">
        <h2>Click Registered!</h2>
        <p>Your click has been counted. Thank you for your support!</p>
        <p>Redirecting to home page...</p>
      </div>
    </body>
  </html>
`,
      {
        headers: {
          "Content-Type": "text/html",
        },
      },
    )
  } catch (error) {
    console.error("Error processing click:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Mock function to get geolocation info
async function getGeoInfo(ip: string) {
  // In a real implementation, you would use a geolocation API
  // For this example, we'll return mock data
  return {
    location: "United States",
    city: "New York",
    country: "US",
    region: "NY",
  }
}

// Function to extract device info from user agent
function getDeviceInfo(userAgent: string) {
  if (!userAgent) return "Unknown Device"

  // Simple detection logic
  if (userAgent.includes("iPhone") || userAgent.includes("iPad")) {
    return "iOS Device"
  } else if (userAgent.includes("Android")) {
    return "Android Device"
  } else if (userAgent.includes("Windows")) {
    return "Windows PC"
  } else if (userAgent.includes("Mac")) {
    return "Mac"
  } else if (userAgent.includes("Linux")) {
    return "Linux"
  } else {
    return "Unknown Device"
  }
}
