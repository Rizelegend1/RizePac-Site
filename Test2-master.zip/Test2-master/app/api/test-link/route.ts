import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Missing ID parameter" }, { status: 400 })
    }

    // This is a diagnostic endpoint to test if links are working correctly
    return NextResponse.json({
      success: true,
      message: `Link test successful for ID: ${id}`,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Error testing link:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
