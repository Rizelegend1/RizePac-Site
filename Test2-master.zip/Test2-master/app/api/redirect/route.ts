import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.redirect(new URL("https://shockify.lol", request.url))
    }

    // In a real implementation, you would fetch the webhook URL from a database
    // For this example, we'll use environment variables
    const webhookUrl = process.env.DISCORD_WEBHOOK_URL

    // Send notification to the webhook if available
    if (webhookUrl) {
      try {
        await fetch(webhookUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            embeds: [
              {
                title: "New Link Click (Server)",
                description: `Someone clicked a Shockify link (ID: ${id})`,
                color: 10181046, // Purple color
                fields: [
                  {
                    name: "User Agent",
                    value: request.headers.get("user-agent") || "Unknown",
                    inline: false,
                  },
                  {
                    name: "IP Address",
                    value: request.headers.get("x-forwarded-for") || "Unknown",
                    inline: false,
                  },
                  {
                    name: "Referrer",
                    value: request.headers.get("referer") || "Direct",
                    inline: false,
                  },
                ],
                footer: {
                  text: "Shockify Link System",
                },
                timestamp: new Date().toISOString(),
              },
            ],
          }),
        })
      } catch (error) {
        console.error("Failed to send webhook notification:", error)
      }
    }

    // Redirect to the client-side redirect page which will handle the click counting
    return NextResponse.redirect(new URL(`/redirect?id=${id}`, request.url))
  } catch (error) {
    console.error("Redirect error:", error)
    return NextResponse.redirect(new URL("https://shockify.lol", request.url))
  }
}
