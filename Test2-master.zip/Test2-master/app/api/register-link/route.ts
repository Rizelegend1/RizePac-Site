import { type NextRequest, NextResponse } from "next/server"

// In a production app, this would use a database
// For this example, we'll use an in-memory store
const linkRegistry = new Map<
  string,
  {
    webhookUrl: string
    referralCode?: string
    referrals: string[]
    clicksFromReferrals: number
    totalEarnings: number
    gamepassLink?: string
  }
>()

export async function POST(request: NextRequest) {
  try {
    const { userId, webhookUrl, referralCode, gamepassLink } = await request.json()

    if (!userId || !webhookUrl) {
      return NextResponse.json({ error: "Missing required parameters" }, { status: 400 })
    }

    // Store the link in our registry with referral info
    linkRegistry.set(userId, {
      webhookUrl,
      referralCode,
      referrals: [],
      clicksFromReferrals: 0,
      totalEarnings: 0,
      gamepassLink,
    })

    // If this user was referred by someone, add them to the referrer's referrals list
    if (referralCode && linkRegistry.has(referralCode)) {
      const referrerData = linkRegistry.get(referralCode)!
      referrerData.referrals.push(userId)

      // Calculate potential earnings from this new referral
      referrerData.totalEarnings += 2000 // 2000 Robux per referral

      linkRegistry.set(referralCode, referrerData)

      // Send an enhanced notification about the earning potential
      try {
        await fetch("/api/send-webhook", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            webhookUrl: referrerData.webhookUrl,
            embed: {
              title: "💰 NEW INCOME STREAM ACTIVATED! 💰",
              description:
                "Someone has created a link using your referral code! Your passive income network is growing!",
              color: 5763719, // Green color
              fields: [
                {
                  name: "💎 DOUBLE PROFIT SYSTEM",
                  value:
                    "Every click they receive will **ALSO COUNT FOR YOU**! This is how the richest Shockify users make THOUSANDS of Robux with minimal effort!",
                  inline: false,
                },
                {
                  name: "💰 Your Network",
                  value: `You now have **${referrerData.referrals.length}** referrals in your network!`,
                  inline: true,
                },
                {
                  name: "💵 Potential Earnings",
                  value: `**${referrerData.totalEarnings.toLocaleString()}** Robux from referrals alone!`,
                  inline: true,
                },
                {
                  name: "🔄 MULTIPLICATION EFFECT",
                  value: "The more people you refer, the faster you'll reach 100 clicks! Keep growing your network!",
                  inline: false,
                },
              ],
              footer: {
                text: "© 2025 Shockify — All Rights Reserved.",
                icon_url:
                  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
              },
            },
          }),
        })
      } catch (error) {
        console.error("Error sending enhanced referral notification:", error)
      }
    }

    console.log(`Registered link for user ID: ${userId}${referralCode ? ` with referral code: ${referralCode}` : ""}`)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error registering link:", error)
    return NextResponse.json({ error: "Failed to register link" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const userId = searchParams.get("id")

    if (!userId) {
      return NextResponse.json({ error: "Missing ID parameter" }, { status: 400 })
    }

    const linkData = linkRegistry.get(userId)

    if (!linkData) {
      return NextResponse.json({ error: "Link not found" }, { status: 404 })
    }

    return NextResponse.json({
      webhookUrl: linkData.webhookUrl,
      referralCode: linkData.referralCode,
      referrals: linkData.referrals,
      gamepassLink: linkData.gamepassLink,
    })
  } catch (error) {
    console.error("Error retrieving link:", error)
    return NextResponse.json({ error: "Failed to retrieve link" }, { status: 500 })
  }
}
