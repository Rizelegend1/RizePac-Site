import { type NextRequest, NextResponse } from "next/server"

// In a production app, this would fetch from a database
// For this demo, we'll generate mock data
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "Missing userId parameter" }, { status: 400 })
    }

    // Generate mock click data
    const totalClicks = Math.floor(Math.random() * 95) + 5 // Between 5 and 99 clicks
    const clicks = generateMockClicks(totalClicks)

    return NextResponse.json({
      success: true,
      totalClicks,
      clicks,
    })
  } catch (error) {
    console.error("Error fetching clicks:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Helper function to generate mock click data
function generateMockClicks(count: number) {
  const clicks = []
  const now = new Date()

  for (let i = 0; i < count; i++) {
    // Generate a random timestamp within the last 7 days
    const timestamp = new Date(now.getTime() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString()

    // Generate a random IP address
    const ip = `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`

    // Generate random location
    const locations = [
      "United States",
      "United Kingdom",
      "Canada",
      "Germany",
      "France",
      "Australia",
      "Japan",
      "Brazil",
      "India",
      "Netherlands",
    ]
    const location = locations[Math.floor(Math.random() * locations.length)]

    // Generate random device
    const devices = ["Windows PC", "Mac", "iPhone", "Android Device", "iPad", "Linux"]
    const device = devices[Math.floor(Math.random() * devices.length)]

    // Generate random referrer
    const referrers = [
      "Direct",
      "Discord",
      "Twitter",
      "Instagram",
      "TikTok",
      "YouTube",
      "Facebook",
      "Reddit",
      "Google",
      "Bing",
    ]
    const referrer = referrers[Math.floor(Math.random() * referrers.length)]

    clicks.push({
      id: `click-${i}`,
      ip,
      location,
      device,
      referrer,
      timestamp,
    })
  }

  // Sort by timestamp, newest first
  return clicks.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
}
