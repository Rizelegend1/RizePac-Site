"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import {
  Globe,
  CloudLightning,
  RefreshCcw,
  Sparkle,
  X,
  Bell,
  Calendar,
  Link2,
  Clock,
  AlertCircle,
  Info,
  MessageCircle,
  FileText,
  Play,
  ExternalLink,
  BookOpen,
  Youtube,
  Video,
  Monitor,
  ArrowRight,
  Star,
  Award,
  Zap,
  Lightbulb,
  Flame,
  Rocket,
  Cookie,
  PenToolIcon as Tool,
  CheckCircle,
  ChevronUp,
  ChevronDown,
  MessageSquare,
  ShoppingCart,
  Scissors,
  ChevronRight,
  DollarSign,
} from "lucide-react"
import { useMediaQuery } from "./hooks/use-media-query"
import { useTouchEvents } from "./hooks/use-touch-events"
import { setupAllProtections } from "./protection"

// Announcement type definition
type AnnouncementCategory = "update" | "alert" | "news" | "event"

interface Announcement {
  id: number
  title: string
  content: string
  date: string
  time: string
  category: AnnouncementCategory
  isImportant: boolean
  isNew: boolean
}

interface LinkItem {
  title: string
  url: string
  description?: string
  icon?: React.ReactNode
  badge?: string
}

export default function ShockifyInterface() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [isMethodsModalOpen, setIsMethodsModalOpen] = useState(false)
  const [isTutorialsModalOpen, setIsTutorialsModalOpen] = useState(false)
  const [isAnnouncementOpen, setIsAnnouncementOpen] = useState(false)
  const [activeCategory, setActiveCategory] = useState<AnnouncementCategory | "all">("all")
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isLoaded, setIsLoaded] = useState(false)
  const isMobile = useMediaQuery("(max-width: 640px)")
  const [showWhyChooseUs, setShowWhyChooseUs] = useState(false)

  useTouchEvents()

  // Set up protections with a try-catch to prevent blocking access
  useEffect(() => {
    // Delay protection setup to ensure it doesn't interfere with initial rendering
    const timer = setTimeout(() => {
      try {
        setupAllProtections()
      } catch (error) {
        // Silently fail if protections cause issues
        console.error("Protection error:", error)
      }
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const methods: LinkItem[] = [
    {
      title: "Dualhook Method (OP)",
      url: "https://justpaste.it/ijrsc",
      description: "The most effective dual-hook method for advanced users",
      icon: <Zap className="w-5 h-5 text-yellow-400" />,
      badge: "OP",
    },
    {
      title: "Tiktok Method (OP)",
      url: "https://justpaste.it/ihr2g",
      description: "Leverage TikTok for maximum effectiveness",
      icon: <Flame className="w-5 h-5 text-red-400" />,
      badge: "OP",
    },
    {
      title: "Adoptme Method",
      url: "https://justpaste.it/gu2o5",
      description: "Specialized method for Adopt Me players",
      icon: <Star className="w-5 h-5 text-pink-400" />,
    },
    {
      title: "View All Methods",
      url: "#",
      description: "Access our complete collection of beaming methods",
      icon: <RefreshCcw className="w-5 h-5 text-blue-400" />,
    },
    {
      title: "Fake Friend Method",
      url: "https://justpaste.it/igqzr",
      description: "Social engineering approach for targeted beaming",
      icon: <Lightbulb className="w-5 h-5 text-amber-400" />,
    },
    {
      title: "Condo method",
      url: "https://justpaste.it/amvi1",
      description: "Specialized method using condo games",
      icon: <Rocket className="w-5 h-5 text-purple-400" />,
    },
  ]

  const tutorials: LinkItem[] = [
    {
      title: "Phone tutorial",
      url: "https://www.youtube.com/watch?v=cyLnGekLgq0&t=6s",
      description: "Complete guide for mobile users",
      icon: <Video className="w-5 h-5 text-red-400" />,
    },
    {
      title: "PC tutorial",
      url: "https://www.youtube.com/watch?v=gPLipnG4ZSA&t=12s",
      description: "Detailed walkthrough for desktop users",
      icon: <Monitor className="w-5 h-5 text-blue-400" />,
    },
    {
      title: "View All Tutorials",
      url: "#",
      description: "Access our complete collection of video tutorials",
      icon: <Globe className="w-5 h-5 text-green-400" />,
    },
  ]

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    try {
      const updateSize = () => {
        canvas.width = window.innerWidth
        canvas.height = Math.max(window.innerHeight, document.body.scrollHeight)
      }
      updateSize()
      window.addEventListener("resize", updateSize)

      // Create an observer to update canvas height when content changes
      const resizeObserver = new ResizeObserver(() => {
        canvas.height = Math.max(window.innerHeight, document.body.scrollHeight)
      })
      resizeObserver.observe(document.body)

      // Inside the useEffect hook where particles are created
      const purpleParticles: { x: number; y: number; speed: number; size: number; opacity: number }[] = []
      const whiteParticles: { x: number; y: number; speed: number; size: number; opacity: number }[] = []

      // Keep the existing purple particles count
      const purpleParticleCount = isMobile ? 135 : 270 // 30% more than the original

      // Add 50% more white particles
      const whiteParticleCount = Math.floor(purpleParticleCount * 0.5)

      for (let i = 0; i < purpleParticleCount; i++) {
        purpleParticles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          speed: 0.2 + Math.random() * 0.3,
          size: 0.5 + Math.random() * 1.5,
          opacity: 0.3 + Math.random() * 0.7,
        })
      }

      // Add white particles with similar properties
      for (let i = 0; i < whiteParticleCount; i++) {
        whiteParticles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          speed: 0.2 + Math.random() * 0.3,
          size: 0.5 + Math.random() * 1.5,
          opacity: 0.3 + Math.random() * 0.7,
        })
      }

      let animationFrameId: number

      function animate() {
        if (!ctx || !canvas) return

        ctx.clearRect(0, 0, canvas.width, canvas.height)

        // Draw purple particles
        purpleParticles.forEach((particle) => {
          ctx.fillStyle = `rgba(139, 92, 246, ${particle.opacity})` // Purple color (tailwind purple-500)
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()

          particle.y += particle.speed
          if (particle.y > canvas.height) {
            particle.y = 0
            particle.x = Math.random() * canvas.width
          }
        })

        // Draw white particles
        whiteParticles.forEach((particle) => {
          ctx.fillStyle = `rgba(255, 255, 255, ${particle.opacity})`
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()

          particle.y += particle.speed
          if (particle.y > canvas.height) {
            particle.y = 0
            particle.x = Math.random() * canvas.width
          }
        })

        animationFrameId = requestAnimationFrame(animate)
      }

      animate()
      setIsLoaded(true)

      return () => {
        window.removeEventListener("resize", updateSize)
        resizeObserver.disconnect()
        cancelAnimationFrame(animationFrameId)
      }
    } catch (error) {
      console.error("Canvas error:", error)
      setIsLoaded(true) // Ensure the site loads even if canvas fails
    }
  }, [isMobile])

  const announcements: Announcement[] = [
    {
      id: 1,
      title: "Welcome to Shockify",
      content: "Hey Welcome To Shockify! We're excited to have you join our community.",
      date: "April 11, 2025",
      time: "14:30",
      category: "news",
      isImportant: true,
      isNew: true,
    },
    {
      id: 2,
      title: "New Global Domain!",
      content: "This domain is a global domain u can use for discord beaming. Enjoy!",
      date: "April 10, 2025",
      time: "09:15",
      category: "update",
      isImportant: true,
      isNew: true,
    },
    {
      id: 3,
      title: "No Scheduled Maintenance",
      content: "There are no scheduled maintenances at this time. We'll update this when maintenance is planned.",
      date: "April 9, 2025",
      time: "18:45",
      category: "alert",
      isImportant: false,
      isNew: false,
    },
    {
      id: 4,
      title: "No Upcoming Events",
      content: "There are no community events scheduled at this time. Stay tuned for future announcements!",
      date: "April 8, 2025",
      time: "11:20",
      category: "event",
      isImportant: false,
      isNew: false,
    },
  ]

  const filteredAnnouncements =
    activeCategory === "all" ? announcements : announcements.filter((a) => a.category === activeCategory)

  const hasNewAnnouncements = announcements.some((a) => a.isNew)

  const categories = [
    { id: "all", label: "All", icon: MessageCircle, color: "text-white" },
    { id: "news", label: "News", icon: Info, color: "text-blue-400" },
    { id: "update", label: "Updates", icon: RefreshCcw, color: "text-green-400" },
    { id: "alert", label: "Alerts", icon: AlertCircle, color: "text-red-400" },
    { id: "event", label: "Events", icon: Calendar, color: "text-purple-400" },
  ]

  const getCategoryColor = (category: AnnouncementCategory): string => {
    switch (category) {
      case "news":
        return "border-blue-400 bg-blue-400/10"
      case "update":
        return "border-green-400 bg-green-400/10"
      case "alert":
        return "border-red-400 bg-red-400/10"
      case "event":
        return "border-purple-400 bg-purple-400/10"
      default:
        return "border-gray-400 bg-gray-400/10"
    }
  }

  const getCategoryIcon = (category: AnnouncementCategory) => {
    switch (category) {
      case "news":
        return <Info className="w-4 h-4 text-blue-400" />
      case "update":
        return <RefreshCcw className="w-4 h-4 text-green-400" />
      case "alert":
        return <AlertCircle className="w-4 h-4 text-red-400" />
      case "event":
        return <Calendar className="w-4 h-4 text-purple-400" />
      default:
        return <Info className="w-4 h-4 text-gray-400" />
    }
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden">
      {/* Canvas background that covers the entire page */}
      <canvas
        ref={canvasRef}
        className="fixed inset-0 pointer-events-none z-0"
        style={{
          width: "100%",
          height: "100%",
          position: "fixed",
          top: 0,
          left: 0,
        }}
      />

      {/* Devlogs/Announcements Button - Fixed Position */}
      <div className="fixed bottom-6 left-6 z-[100]">
        <motion.button
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          onClick={() => setIsAnnouncementOpen(true)}
          className="bg-black/80 border-2 border-purple-500/50 rounded-full p-3 sm:p-4 shadow-lg relative overflow-hidden group hover:border-purple-500/80 hover:scale-110 transition-all duration-300 devlogs-btn"
          aria-label="Open devlogs"
          style={{
            minHeight: "48px",
            minWidth: "48px",
            boxShadow: "0 0 15px rgba(139, 92, 246, 0.5), 0 0 30px rgba(139, 92, 246, 0.3)",
          }}
        >
          <Bell className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6 relative z-10" />
          {hasNewAnnouncements && (
            <span
              className="absolute -top-1 -right-1 w-3 h-3 sm:w-4 sm:h-4 bg-red-500 rounded-full notification-dot"
              style={{
                boxShadow: "0 0 10px rgba(239, 68, 68, 0.7)",
                animation: "pulse-dot 2s infinite",
              }}
            ></span>
          )}
          <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
        </motion.button>
      </div>

      {/* Beaming Methods Button - Fixed Position */}
      <div className="fixed bottom-6 right-6 z-[100]">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <Link
            href="/beaming-methods"
            className="bg-black/80 border-2 border-purple-500/50 rounded-full p-3 sm:p-4 shadow-lg relative overflow-hidden group hover:border-purple-500/80 hover:scale-110 transition-all duration-300 flex items-center justify-center"
            aria-label="View beaming methods"
            style={{
              minHeight: "48px",
              minWidth: "48px",
              boxShadow: "0 0 15px rgba(139, 92, 246, 0.5), 0 0 30px rgba(139, 92, 246, 0.3)",
            }}
          >
            <Award className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6 relative z-10" />
            <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
          </Link>
        </motion.div>
      </div>

      {/* Announcements Modal */}
      <AnimatePresence>
        {isAnnouncementOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-[200] flex items-center justify-center p-2 sm:p-4 backdrop-blur-sm"
            onClick={() => setIsAnnouncementOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25 }}
              className="relative w-full max-w-md border-2 border-purple-500/40 rounded-xl bg-black/90 max-h-[90vh] sm:max-h-[80vh] overflow-hidden flex flex-col"
              onClick={(e) => e.stopPropagation()}
              style={{ boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
            >
              <div className="p-4 border-b border-purple-500/20 flex justify-between items-center sticky top-0 bg-black z-10">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Bell className="text-purple-400 w-5 h-5" />
                  Devlogs Board
                </h2>
                <button
                  onClick={() => setIsAnnouncementOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10 relative overflow-hidden group devlogs-close-btn"
                  aria-label="Close devlogs"
                  style={{
                    minHeight: "44px",
                    minWidth: "44px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <X className="w-6 h-6 relative z-10" />
                  <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100"></div>
                </button>
              </div>

              <div className="px-3 pt-3 pb-2 border-b border-purple-500/20 overflow-x-auto flex gap-2 announcement-tabs">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id as AnnouncementCategory | "all")}
                    className={`px-3 py-2 rounded-full text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition-colors relative overflow-hidden group ${
                      activeCategory === category.id
                        ? "bg-purple-500/20 text-white border border-purple-500/40"
                        : "bg-black/40 text-gray-300 border border-gray-700 hover:border-gray-500"
                    }`}
                    style={{ minHeight: "40px", minWidth: "70px", justifyContent: "center" }}
                  >
                    <category.icon className={`w-3.5 h-3.5 ${category.color} relative z-10`} />
                    <span className="relative z-10">{category.label}</span>
                    <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100"></div>
                  </button>
                ))}
              </div>

              <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 announcements-container">
                {filteredAnnouncements.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">
                    <Info className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No devlogs in this category</p>
                  </div>
                ) : (
                  filteredAnnouncements.map((announcement) => (
                    <div
                      key={announcement.id}
                      className={`rounded-lg p-3 sm:p-4 announcement-item border ${getCategoryColor(announcement.category)} ${
                        announcement.isImportant ? "ring-1 ring-purple-500/30" : ""
                      } relative overflow-hidden group`}
                    >
                      <div className="flex justify-between items-start mb-2 relative z-10">
                        <h3 className="font-bold text-white text-base flex items-center flex-wrap">
                          {getCategoryIcon(announcement.category)}
                          <span className="ml-1.5">{announcement.title}</span>
                          {announcement.isNew && (
                            <span className="ml-2 bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full">New</span>
                          )}
                        </h3>
                      </div>

                      <p className="text-gray-200 text-sm mb-3 relative z-10">{announcement.content}</p>

                      <div className="flex items-center text-xs text-gray-400 mt-1 pt-2 border-t border-gray-700/50 relative z-10">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{announcement.date}</span>
                        </div>
                        <div className="mx-2">•</div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{announcement.time}</span>
                        </div>
                      </div>
                      <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100"></div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isMethodsModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
            onClick={() => setIsMethodsModalOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25 }}
              className="relative w-full max-w-md border border-blue-500/30 rounded-xl bg-black/95 method-modal-container overflow-hidden"
              onClick={(e) => e.stopPropagation()}
              style={{ boxShadow: "0 0 20px rgba(59, 130, 246, 0.4)" }}
            >
              <div className="p-5 border-b border-blue-500/20 flex justify-between items-center bg-gradient-to-r from-blue-900/40 to-black">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Award className="text-blue-400 w-6 h-6" />
                  <span className="methods-title">Beaming Methods</span>
                </h2>
                <button
                  onClick={() => setIsMethodsModalOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10 relative overflow-hidden group"
                  aria-label="Close methods"
                >
                  <X className="w-6 h-6 relative z-10" />
                  <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100"></div>
                </button>
              </div>

              <div className="p-5 border-b border-blue-500/20 bg-gradient-to-b from-blue-900/20 to-transparent">
                <div className="flex items-center gap-3 mb-3">
                  <div className="bg-blue-500/20 p-2 rounded-full">
                    <BookOpen className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-white">Premium Methods Collection</h3>
                    <p className="text-xs text-gray-400">Click any method below to view detailed instructions</p>
                  </div>
                </div>
              </div>

              <div className="p-4 max-h-[60vh] overflow-y-auto methods-container">
                <div className="grid gap-3">
                  {methods.map((method, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Link
                        href={method.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full bg-gradient-to-br from-blue-900/30 to-black text-white p-4 rounded-lg transition-all duration-300 border border-blue-500/20 hover:border-blue-500/40 method-card group relative overflow-hidden"
                      >
                        {method.badge && (
                          <span className="absolute top-0 right-0 bg-gradient-to-r from-yellow-500 to-amber-500 text-black text-xs font-bold px-2 py-1 rounded-bl-lg">
                            {method.badge}
                          </span>
                        )}

                        <div className="flex items-start gap-3 relative z-10">
                          <div className="bg-blue-900/40 rounded-full p-2.5 method-icon-container flex-shrink-0">
                            {method.icon || <FileText className="w-5 h-5 text-blue-400" />}
                          </div>

                          <div className="flex-1">
                            <h3 className="font-medium text-base mb-1 group-hover:text-blue-300 transition-colors">
                              {method.title}
                            </h3>
                            {method.description && <p className="text-xs text-gray-400 mb-2">{method.description}</p>}

                            <div className="flex items-center text-xs text-blue-400 group-hover:text-blue-300 transition-colors mt-1">
                              <span>View method</span>
                              <ArrowRight className="w-3.5 h-3.5 ml-1 group-hover:translate-x-1 transition-transform" />
                            </div>
                          </div>
                        </div>

                        <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isTutorialsModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
            onClick={() => setIsTutorialsModalOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              transition={{ type: "spring", damping: 25 }}
              className="relative w-full max-w-md border border-yellow-500/30 rounded-xl bg-black/95 tutorial-modal-container overflow-hidden"
              onClick={(e) => e.stopPropagation()}
              style={{ boxShadow: "0 0 20px rgba(234, 179, 8, 0.4)" }}
            >
              <div className="p-5 border-b border-yellow-500/20 flex justify-between items-center bg-gradient-to-r from-yellow-900/40 to-black">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Play className="text-yellow-400 w-6 h-6" />
                  <span className="tutorials-title">Video Tutorials</span>
                </h2>
                <button
                  onClick={() => setIsTutorialsModalOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10 relative overflow-hidden group"
                  aria-label="Close tutorials"
                >
                  <X className="w-6 h-6 relative z-10" />
                  <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100"></div>
                </button>
              </div>

              <div className="p-5 border-b border-yellow-500/20 bg-gradient-to-b from-yellow-900/20 to-transparent">
                <div className="flex items-center gap-3 mb-3">
                  <div className="bg-yellow-500/20 p-2 rounded-full">
                    <Youtube className="w-5 h-5 text-yellow-400" />
                  </div>
                  <div>
                    <h3 className="font-medium text-white">Step-by-Step Video Guides</h3>
                    <p className="text-xs text-gray-400">Click any tutorial below to watch the video</p>
                  </div>
                </div>
              </div>

              <div className="p-4 max-h-[60vh] overflow-y-auto tutorials-container">
                <div className="grid gap-3">
                  {tutorials.map((tutorial, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Link
                        href={tutorial.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full bg-gradient-to-br from-yellow-900/30 to-black text-white p-4 rounded-lg transition-all duration-300 border border-yellow-500/20 hover:border-yellow-500/40 tutorial-card group relative overflow-hidden"
                      >
                        <div className="flex items-start gap-3 relative z-10">
                          <div className="bg-yellow-900/40 rounded-full p-2.5 tutorial-icon-container flex-shrink-0">
                            {tutorial.icon || <Video className="w-5 h-5 text-yellow-400" />}
                          </div>

                          <div className="flex-1">
                            <h3 className="font-medium text-base mb-1 group-hover:text-yellow-300 transition-colors">
                              {tutorial.title}
                            </h3>
                            {tutorial.description && (
                              <p className="text-xs text-gray-400 mb-2">{tutorial.description}</p>
                            )}

                            <div className="flex items-center text-xs text-yellow-400 group-hover:text-yellow-300 transition-colors mt-1">
                              <span>Watch tutorial</span>
                              <ExternalLink className="w-3.5 h-3.5 ml-1 group-hover:translate-x-1 transition-transform" />
                            </div>
                          </div>
                        </div>

                        <div className="absolute top-1/2 right-4 transform -translate-y-1/2 bg-yellow-500/20 rounded-full p-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Play className="w-4 h-4 text-yellow-400 fill-current" />
                        </div>

                        <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-yellow-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
        transition={{ duration: 1.5 }}
        className="relative z-10 container mx-auto px-2 sm:px-4 flex flex-col items-center space-y-5 w-full max-w-3xl py-8"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.5 }}
          className="flex items-center justify-center gap-2 sm:gap-4 mt-2 sm:mt-0"
        >
          <h1 className="text-3xl sm:text-5xl font-bold text-center text-white purple-glow">Shockify</h1>
        </motion.div>

        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="w-full max-w-sm mb-1 sm:mb-4"
        >
          <Link
            href="https://discord.gg/shockify"
            target="_blank"
            rel="noopener noreferrer"
            className="discord-button bg-white text-purple-600 px-4 py-3 rounded-md text-lg sm:text-xl font-semibold block text-center hover:bg-gray-100 transition-all duration-300 flex items-center justify-center gap-2 relative overflow-hidden group"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 127.14 96.36"
              className="w-5 h-5 sm:w-6 sm:h-6 relative z-10"
              fill="currentColor"
            >
              <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z" />
            </svg>
            <span className="relative z-10">Join Discord</span>
            <div className="discord-button-effect absolute inset-0 w-full h-full"></div>
            <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.1 }}
          className="border border-purple-500/30 rounded-xl p-4 w-full bg-black/40 purple-glow-container"
        >
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center text-white flex items-center justify-center gap-2">
            <Link2 className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
            MAIN GENERATOR
            <Link2 className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
          </h2>

          <div className="grid grid-cols-3 sm:grid-cols-3 gap-2 sm:gap-3 mb-4">
            <Link
              href="https://app.genn.lu/auth/shockifygen"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-gradient-to-r from-yellow-900/50 to-black text-white px-2 py-3 rounded-md text-sm sm:text-lg font-semibold text-center transition-all duration-300 flex flex-col sm:flex-col items-center justify-center gap-1 sm:gap-2 hover:from-yellow-800/50 generator-button border border-yellow-500/30 relative overflow-hidden group"
            >
              <CloudLightning className="text-yellow-400 w-5 h-5 relative z-10" />
              <span className="relative z-10">Link Generator</span>
              <div className="generator-button-effect absolute inset-0 w-full h-full"></div>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-yellow-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </Link>

            <Link
              href="/hyperlink"
              className="w-full bg-gradient-to-r from-purple-900/50 to-black text-white px-2 py-3 rounded-md text-sm sm:text-lg font-semibold text-center transition-all duration-300 flex flex-col sm:flex-col items-center justify-center gap-1 sm:gap-2 hover:from-purple-800/50 hyperlink-button border border-purple-500/30 relative overflow-hidden group"
            >
              <RefreshCcw className="text-purple-400 w-5 h-5 relative z-10" />
              <span className="relative z-10">Hyperlink</span>
              <div className="hyperlink-button-effect absolute inset-0 w-full h-full"></div>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </Link>

            <Link
              href="https://is.gd/lsgenerator"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-gradient-to-r from-blue-900/50 to-black text-white px-2 py-3 rounded-md text-sm sm:text-lg font-semibold text-center transition-all duration-300 flex flex-col sm:flex-col items-center justify-center gap-1 sm:gap-2 hover:from-blue-800/50 backup-button border border-blue-500/30 relative overflow-hidden group"
            >
              <Globe className="text-blue-400 w-5 h-5 relative z-10" />
              <span className="relative z-10">Backup Site</span>
              <div className="backup-button-effect absolute inset-0 w-full h-full"></div>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </Link>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.1 }}
          className="border border-purple-500/30 rounded-xl p-4 w-full bg-black/40 purple-glow-container"
        >
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center text-white flex items-center justify-center gap-2">
            <Sparkle className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
            Beaming Tutorial
            <Sparkle className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
          </h2>

          <button
            onClick={() => setIsTutorialsModalOpen(true)}
            className="mobile-gen-button w-full bg-gradient-to-r from-yellow-900/50 to-black text-white px-4 py-3 rounded-md text-base sm:text-lg font-semibold text-center hover:from-yellow-800/50 transition-all duration-300 flex items-center justify-between tutorial-button border border-yellow-500/30 relative overflow-hidden group mb-3 sm:mb-4"
            style={{ boxShadow: "0 0 10px rgba(234, 179, 8, 0.3)" }}
          >
            <span className="flex items-center gap-2 z-10">
              <div className="bg-yellow-500/20 p-1.5 rounded-full">
                <Play className="w-4 h-4 text-yellow-400" />
              </div>
              <span>Video Tutorials</span>
            </span>
            <span className="flex items-center gap-2 text-sm text-yellow-400/80 z-10 group-hover:translate-x-1 transition-transform">
              <span>View all</span>
              <ExternalLink className="w-4 h-4" />
            </span>
            <div className="tutorial-button-effect absolute inset-0 w-full h-full"></div>
            <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-yellow-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
          </button>

          <Link
            href="/beaming-methods"
            className="mobile-gen-button w-full bg-gradient-to-r from-blue-900/50 to-black text-white px-4 py-3 rounded-md text-base sm:text-lg font-semibold text-center hover:from-blue-800/50 transition-all duration-300 flex items-center justify-between method-button border border-blue-500/30 relative overflow-hidden group mb-3 sm:mb-4"
            style={{ boxShadow: "0 0 10px rgba(59, 130, 246, 0.3)" }}
          >
            <span className="flex items-center gap-2 z-10">
              <div className="bg-blue-500/20 p-1.5 rounded-full">
                <BookOpen className="w-4 h-4 text-blue-400" />
              </div>
              <span>Beaming Methods</span>
            </span>
            <span className="flex items-center gap-2 text-sm text-blue-400/80 z-10 group-hover:translate-x-1 transition-transform">
              <span>View all</span>
              <ArrowRight className="w-4 h-4" />
            </span>
            <div className="method-button-effect absolute inset-0 w-full h-full"></div>
            <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
          </Link>
        </motion.div>

        {/* PoepBeamz (OP) Tools Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.4, delay: 1.6 }}
          className="border-2 border-purple-500/40 rounded-xl p-4 w-full bg-black/40 purple-glow-container"
          style={{ boxShadow: "0 0 15px rgba(139, 92, 246, 0.4)" }}
        >
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center text-white flex items-center justify-center gap-2">
            <Tool className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
            Shockify{" "}
            <span className="bg-gradient-to-r from-yellow-500 to-amber-500 text-black text-xs font-bold px-2 py-1 rounded-md ml-1">
              OP
            </span>{" "}
            Tools
            <Tool className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
          </h2>

          <div className="grid grid-cols-2 gap-3 mb-3">
            <Link
              href="/webhook-spammer"
              className="mobile-gen-button bg-gradient-to-r from-red-900/50 to-black text-white px-4 py-3 rounded-md text-base sm:text-lg font-semibold text-center hover:from-red-800/50 transition-all duration-300 flex flex-col items-center justify-center gap-2 webhook-button border border-red-500/30 relative overflow-hidden group"
              style={{ boxShadow: "0 0 10px rgba(239, 68, 68, 0.3)" }}
            >
              <MessageCircle className="w-5 h-5 text-red-400 z-10" />
              <span className="z-10">Webhook Spammer</span>
              <div className="webhook-button-effect absolute inset-0 w-full h-full"></div>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-red-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </Link>

            <Link
              href="/cookie-refresher"
              className="mobile-gen-button bg-gradient-to-r from-red-900/50 to-black text-white px-4 py-3 rounded-md text-base sm:text-lg font-semibold text-center hover:from-red-800/50 transition-all duration-300 flex flex-col items-center justify-center gap-2 cookie-button border border-red-500/30 relative overflow-hidden group"
              style={{ boxShadow: "0 0 10px rgba(239, 68, 68, 0.3)" }}
            >
              <Cookie className="w-5 h-5 text-red-400 z-10" />
              <span className="z-10">Cookie Checker</span>
              <div className="cookie-button-effect absolute inset-0 w-full h-full"></div>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-red-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </Link>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-3">
            <Link
              href="/store"
              className="mobile-gen-button bg-gradient-to-r from-red-900/50 to-black text-white px-4 py-3 rounded-md text-base sm:text-lg font-semibold text-center hover:from-red-800/50 transition-all duration-300 flex flex-col items-center justify-center gap-2 store-button border border-red-500/30 relative overflow-hidden group"
              style={{ boxShadow: "0 0 10px rgba(239, 68, 68, 0.3)" }}
            >
              <ShoppingCart className="w-5 h-5 text-red-400 z-10" />
              <span className="z-10">Premium Accounts</span>
              <div className="store-button-effect absolute inset-0 w-full h-full"></div>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-red-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </Link>

            <Link
              href="/vouches"
              className="mobile-gen-button bg-gradient-to-r from-red-900/50 to-black text-white px-4 py-3 rounded-md text-base sm:text-lg font-semibold text-center hover:from-red-800/50 transition-all duration-300 flex flex-col items-center justify-center gap-2 vouches-button border border-red-500/30 relative overflow-hidden group"
              style={{ boxShadow: "0 0 10px rgba(239, 68, 68, 0.3)" }}
            >
              <MessageSquare className="w-5 h-5 text-red-400 z-10" />
              <span className="z-10">Customer Vouches</span>
              <div className="vouches-button-effect absolute inset-0 w-full h-full"></div>
              <div className="shine-animation absolute inset-0 bg-gradient-to-r from-transparent via-red-500/20 to-transparent opacity-0 group-hover:opacity-100"></div>
            </Link>
          </div>
        </motion.div>

        {/* Video Editing Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.4, delay: 1.7 }}
          className="border-2 border-purple-500/40 rounded-xl p-4 w-full bg-black/40 purple-glow-container"
          style={{ boxShadow: "0 0 15px rgba(139, 92, 246, 0.4)" }}
        >
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center text-white flex items-center justify-center gap-2">
            <Video className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
            Video Editing Service
            <Video className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
          </h2>

          <div className="text-center mb-4">
            <p className="text-gray-300 mb-4">
              Edit our videos and earn 8,000 Robux! Professional video editing service with verified payment.
            </p>
            <Link
              href="/editing"
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md inline-flex items-center justify-center gap-2 transition-colors shadow-lg transform hover:translate-y-[-2px] transition-transform duration-200"
            >
              <Scissors className="w-5 h-5" />
              <span className="font-bold">START EDITING NOW</span>
              <ChevronRight className="w-5 h-5 ml-1 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </motion.div>

        {/* Make Money Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.4, delay: 1.7 }}
          className="border-2 border-purple-500/40 rounded-xl p-4 w-full bg-black/40 purple-glow-container"
          style={{ boxShadow: "0 0 15px rgba(139, 92, 246, 0.4)" }}
        >
          <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6 text-center text-white flex items-center justify-center gap-2">
            <DollarSign className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
            Make Money
            <DollarSign className="text-purple-400 w-5 h-5 sm:w-6 sm:h-6" />
          </h2>

          <div className="text-center mb-4">
            <p className="text-gray-300 mb-4">
              Generate your own link, share it, and earn 10,000 Robux when you reach 100 clicks!
            </p>
            <Link
              href="/make-money"
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-md inline-flex items-center justify-center gap-2 transition-colors shadow-lg transform hover:translate-y-[-2px] transition-transform duration-200"
            >
              <DollarSign className="w-5 h-5" />
              <span className="font-bold">START EARNING NOW</span>
              <ChevronRight className="w-5 h-5 ml-1 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </motion.div>

        {/* Why Choose PoepBeamz Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.4, delay: 1.7 }}
          className="border border-purple-500/20 rounded-xl w-full bg-black/30 backdrop-blur-sm shadow-xl shadow-purple-900/10 overflow-hidden purple-glow-container"
        >
          <div
            className="flex items-center justify-between p-1.5 sm:p-2 cursor-pointer bg-gradient-to-r from-gray-900 to-black hover:from-purple-950/30 hover:to-black transition-colors"
            onClick={() => setShowWhyChooseUs(!showWhyChooseUs)}
          >
            <div className="flex items-center gap-1.5">
              <div className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0 relative">
                <Award className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
              </div>
              <h3 className="font-medium text-white text-xs sm:text-sm">Why Choose Shockify?</h3>
            </div>
            <div>
              {showWhyChooseUs ? (
                <ChevronUp className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-gray-400" />
              )}
            </div>
          </div>

          <AnimatePresence>
            {showWhyChooseUs && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="p-2 sm:p-3 border-t border-gray-800"
              >
                <div className="space-y-3">
                  <div className="flex items-start gap-2">
                    <div className="bg-green-500/20 p-1.5 rounded-full mt-0.5">
                      <CheckCircle className="w-3 h-3 text-green-400" />
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      <span className="text-white font-medium">100% Secure:</span> Our generators and tools are built
                      with security in mind. We don't store your data or track your activity.
                    </p>
                  </div>

                  <div className="flex items-start gap-2">
                    <div className="bg-red-500/20 p-1.5 rounded-full mt-0.5">
                      <X className="w-3 h-3 text-red-400" />
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      <span className="text-white font-medium">No Dualhooks:</span> Unlike other services, our
                      generators are not dualhooked. Your webhooks and links are yours alone.
                    </p>
                  </div>

                  <div className="flex items-start gap-2">
                    <div className="bg-blue-500/20 p-1.5 rounded-full mt-0.5">
                      <Zap className="w-3 h-3 text-blue-400" />
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      <span className="text-white font-medium">High Performance:</span> Our tools are optimized for
                      speed and reliability, ensuring you get the best results every time.
                    </p>
                  </div>

                  <div className="flex items-start gap-2">
                    <div className="bg-yellow-500/20 p-1.5 rounded-full mt-0.5">
                      <Bell className="w-3 h-3 text-yellow-400" />
                    </div>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      <span className="text-white font-medium">Regular Updates:</span> We constantly update our methods
                      and tools to stay ahead of security changes and maintain effectiveness.
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.4, delay: 1.8 }}
          className="w-full mt-4"
        >
          <div className="text-center mb-4">
            <h2 className="text-xl sm:text-2xl font-bold text-white purple-glow">#1 Roblox Beaming Website</h2>
            <p className="text-sm text-gray-300 mt-2">Copyright © 2025 Shockify — All Rights Reserved.</p>
          </div>
        </motion.div>
      </motion.div>

      <style jsx>{`
        .generator-button-effect,
        .hyperlink-button-effect,
        .backup-button-effect,
        .tutorial-button-effect,
        .method-button-effect,
        .webhook-button-effect,
        .cookie-button-effect,
        .store-button-effect,
        .vouches-button-effect,
        .editing-button-effect,
        .discord-button-effect {
          background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
          background-size: 200% 200%;
          animation: shimmer 2s infinite;
          opacity: 0;
        }

        .group:hover .generator-button-effect,
        .group:hover .hyperlink-button-effect,
        .group:hover .backup-button-effect,
        .group:hover .tutorial-button-effect,
        .group:hover .method-button-effect,
        .group:hover .webhook-button-effect,
        .group:hover .cookie-button-effect,
        .group:hover .store-button-effect,
        .group:hover .vouches-button-effect,
        .group:hover .editing-button-effect,
        .group:hover .discord-button-effect {
          opacity: 1;
        }

        @keyframes shimmer {
          0% {
            background-position: -100% -100%;
          }
          100% {
            background-position: 100% 100%;
          }
        }

        .shine-animation {
          position: absolute;
          width: 100%;
          height: 100%;
          transform: translateX(-100%);
          animation: shine-effect 3s infinite;
        }

        @keyframes shine-effect {
          0% {
            transform: translateX(-100%);
          }
          20% {
            transform: translateX(100%);
          }
          100% {
            transform: translateX(100%);
          }
        }
      `}</style>
    </div>
  )
}
