export function setupAllProtections() {
  // Prevent right-click
  document.addEventListener("contextmenu", (event) => {
    event.preventDefault()
  })

  // Prevent inspect element
  document.addEventListener("keydown", (event) => {
    if (
      event.key === "F12" ||
      (event.ctrlKey && event.shiftKey && (event.key === "I" || event.key === "C" || event.key === "J"))
    ) {
      event.preventDefault()
    }
  })

  // Disable console logging
  if (typeof console !== "undefined") {
    ;(console as any).log = () => {}
    ;(console as any).warn = () => {}
    ;(console as any).error = () => {}
    ;(console as any).assert = () => {}
    ;(console as any).clear = () => {}
    ;(console as any).count = () => {}
    ;(console as any).countReset = () => {}
    ;(console as any).debug = () => {}
    ;(console as any).dir = () => {}
    ;(console as any).dirxml = () => {}
    ;(console as any).group = () => {}
    ;(console as any).groupCollapsed = () => {}
    ;(console as any).groupEnd = () => {}
    ;(console as any).info = () => {}
    ;(console as any).profile = () => {}
    ;(console as any).profileEnd = () => {}
    ;(console as any).table = () => {}
    ;(console as any).time = () => {}
    ;(console as any).timeEnd = () => {}
    ;(console as any).timeLog = () => {}
    ;(console as any).timeStamp = () => {}
    ;(console as any).trace = () => {}
  }
}
