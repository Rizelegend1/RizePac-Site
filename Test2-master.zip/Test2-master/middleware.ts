import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Pattern for user IDs (matches the format from generateUserId)
const USER_ID_PATTERN = /^[a-z]+-[a-z]+-\d{3}$/

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Skip middleware for all paths except those that match our exact pattern
  // This ensures normal site navigation works correctly

  // If it's the root path or has multiple segments, don't process
  if (pathname === "/" || pathname.substring(1).includes("/")) {
    return NextResponse.next()
  }

  // Skip middleware for static assets, API routes, and files
  if (
    pathname.startsWith("/_next/") ||
    pathname.startsWith("/api/") ||
    pathname.includes(".") ||
    pathname === "/favicon.ico"
  ) {
    return NextResponse.next()
  }

  // Extract the potential user ID from the path (remove leading slash)
  const potentialUserId = pathname.substring(1)

  // Only process if this exactly matches our user ID pattern
  if (USER_ID_PATTERN.test(potentialUserId)) {
    console.log(`Processing user ID: ${potentialUserId}`)

    // This is a user-generated link, process the click
    const url = new URL("/api/process-click", request.url)
    url.searchParams.set("id", potentialUserId)

    // Get IP address from headers
    const ip = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "127.0.0.1"
    url.searchParams.set("ip", ip)

    // Get user agent
    const userAgent = request.headers.get("user-agent") || "Unknown"
    url.searchParams.set("userAgent", userAgent)

    // Get referrer if available
    const referrer = request.headers.get("referer") || "Direct"
    url.searchParams.set("referrer", referrer)

    // Process the click asynchronously (fire and forget)
    // We can't use await in middleware, so we'll use a fire-and-forget approach
    fetch(url.toString()).catch((err) => console.error("Error processing click:", err))

    // Redirect to the main site
    return NextResponse.redirect(new URL("/", request.url))
  }

  // For any other path, let Next.js handle it normally
  return NextResponse.next()
}

// Configure the middleware to run only on specific paths
export const config = {
  matcher: [
    // Only run on root-level paths that don't have file extensions
    // This ensures we don't interfere with static assets or nested routes
    "/((?!api|_next/static|_next/image|favicon.ico).*)",
  ],
}
