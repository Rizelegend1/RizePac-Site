"use client"

import { useEffect, useRef } from "react"

export function PurpleParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    try {
      const updateSize = () => {
        canvas.width = window.innerWidth
        canvas.height = window.innerHeight
      }
      updateSize()
      window.addEventListener("resize", updateSize)

      // Create particles
      const particles = []
      const particleCount = 200

      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: 0.5 + Math.random() * 2.5,
          speed: 0.1 + Math.random() * 0.3,
          vx: Math.random() * 0.2 - 0.1,
          vy: Math.random() * 0.2 - 0.1,
          color: Math.random() > 0.3 ? "139, 92, 246" : "255, 255, 255", // Purple or white
          opacity: 0.2 + Math.random() * 0.5,
        })
      }

      let animationFrameId

      function animate() {
        if (!ctx || !canvas) return

        ctx.clearRect(0, 0, canvas.width, canvas.height)

        particles.forEach((particle) => {
          // Update position
          particle.x += particle.vx
          particle.y += particle.vy + particle.speed

          // Add some random movement
          particle.vx += (Math.random() - 0.5) * 0.01
          particle.vy += (Math.random() - 0.5) * 0.01

          // Boundary check
          if (particle.x < 0) particle.x = canvas.width
          if (particle.x > canvas.width) particle.x = 0
          if (particle.y < 0) particle.y = canvas.height
          if (particle.y > canvas.height) particle.y = 0

          // Draw particle
          ctx.fillStyle = `rgba(${particle.color}, ${particle.opacity})`
          ctx.beginPath()
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2)
          ctx.fill()
        })

        // Draw connections between particles
        ctx.lineWidth = 0.3
        for (let i = 0; i < particles.length; i++) {
          const p1 = particles[i]

          for (let j = i + 1; j < particles.length; j++) {
            const p2 = particles[j]
            const dx = p1.x - p2.x
            const dy = p1.y - p2.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < 100) {
              const opacity = (1 - distance / 100) * 0.6
              ctx.strokeStyle = `rgba(139, 92, 246, ${opacity})`
              ctx.beginPath()
              ctx.moveTo(p1.x, p1.y)
              ctx.lineTo(p2.x, p2.y)
              ctx.stroke()
            }
          }
        }

        animationFrameId = requestAnimationFrame(animate)
      }

      animate()

      return () => {
        window.removeEventListener("resize", updateSize)
        cancelAnimationFrame(animationFrameId)
      }
    } catch (error) {
      console.error("Canvas error:", error)
    }
  }, [])

  return (
    <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-0 w-full h-full" aria-hidden="true" />
  )
}

export default PurpleParticleCanvas
