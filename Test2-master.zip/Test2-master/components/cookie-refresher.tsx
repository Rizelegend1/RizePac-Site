"use client"

import type React from "react"

import { useState, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  ArrowLeft,
  RefreshCw,
  Copy,
  Check,
  AlertCircle,
  Info,
  User,
  Calendar,
  Crown,
  History,
  Shield,
  DollarSign,
  Loader2,
  XCircle,
  Users,
  Heart,
  Award,
  Briefcase,
  Box,
  Clock,
  Gamepad,
  Mail,
  Phone,
  Lock,
  Tag,
  Ban,
} from "lucide-react"
import NextLink from "next/link"
import Image from "next/image"
import { checkRobloxCookie } from "@/app/api/cookie-actions"
import { RedParticleCanvas } from "./red-particle-canvas"

// Helper function to format date
function formatDate(dateString: string) {
  if (!dateString) return "Unknown"
  const date = new Date(dateString)
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })
}

// Helper function to format account age
function formatAccountAge(days: number) {
  if (days < 30) return `${days} day${days !== 1 ? "s" : ""}`

  const months = Math.floor(days / 30)
  if (months < 12) return `${months} month${months !== 1 ? "s" : ""}`

  const years = Math.floor(days / 365)
  const remainingMonths = Math.floor((days % 365) / 30)

  if (remainingMonths === 0) return `${years} year${years !== 1 ? "s" : ""}`
  return `${years} year${years !== 1 ? "s" : ""}, ${remainingMonths} month${remainingMonths !== 1 ? "s" : ""}`
}

// Helper function to format large numbers
function formatNumber(num: number) {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M"
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + "K"
  }
  return num.toString()
}

// Helper function to format time ago
function formatTimeAgo(dateString: string) {
  if (!dateString) return "Unknown"

  const date = new Date(dateString)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffSecs = Math.floor(diffMs / 1000)
  const diffMins = Math.floor(diffSecs / 60)
  const diffHours = Math.floor(diffMins / 60)
  const diffDays = Math.floor(diffHours / 24)

  if (diffDays > 30) {
    return formatDate(dateString)
  } else if (diffDays > 0) {
    return `${diffDays} day${diffDays !== 1 ? "s" : ""} ago`
  } else if (diffHours > 0) {
    return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`
  } else if (diffMins > 0) {
    return `${diffMins} minute${diffMins !== 1 ? "s" : ""} ago`
  } else {
    return "Just now"
  }
}

// Update the interface for CookieInfo to include all possible data
interface CookieInfo {
  success: boolean
  message: string
  cookie?: string
  originalCookie?: string
  accountSummary?: {
    username: string
    userId: number
    robuxBalance: number
    isPremium: boolean
    created: string | null
    accountAge: number
    profilePictureUrl: string | null
    displayName: string | null
    description: string
    friendsCount: number
    followersCount: number
    isBanned: boolean
    lastOnline: string | null
    onlineStatus?: number
    lastLocation?: string | null
  }
  securityInfo?: {
    twoStepEnabled: boolean
    emailVerified: boolean
    phoneVerified: boolean
    pinEnabled: boolean
    authenticatorEnabled?: boolean
    passkeysEnabled?: boolean
    ageVerified?: boolean
    accountLanguage?: string
  }
  groupsInfo?: {
    count: number
    groups: Array<{
      id: number
      name: string
      role: string
      rank: number
    }>
  }
  inventoryInfo?: {
    canView: boolean
    itemCount: number
    limitedItems: Array<{
      name: string
      assetId: number
      recentAveragePrice: number
    }>
    estimatedValue: number
  }
  badgesInfo?: {
    totalBadges: number
    recentBadges: Array<{
      name: string
      description: string
      awardedDate: string
    }>
  }
  robuxSummary?: {
    spent: number
    received: number
    pendingRobux: number
    totalReceived?: number
    totalSpent?: number
  }
  gameInfo?: {
    favoriteGames: Array<{
      name: string
      placeId: number
      visits: number
    }>
    recentlyPlayed: Array<any>
  }
  developerInfo?: {
    isVerifiedDeveloper: boolean
    createdGames: Array<any>
  }
  specialItems?: {
    hasKorblox: boolean
    hasHeadless: boolean
  }
  recentlyPlayedGames?: Array<any>
  favoriteGames?: Array<any>
  gamePasses?: Array<any>
}

export default function CookieRefresher() {
  const [cookie, setCookie] = useState("")
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [result, setResult] = useState<CookieInfo | null>(null)
  const [copied, setCopied] = useState(false)
  const [activeSection, setActiveSection] = useState("account")
  const [error, setError] = useState<string | null>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const resultTextareaRef = useRef<HTMLTextAreaElement>(null)

  // Handle cookie refresh
  const handleRefresh = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!cookie.trim()) {
      setResult({
        success: false,
        message: "Please enter a Roblox cookie",
      })
      return
    }

    setIsRefreshing(true)
    setResult(null)

    try {
      const formData = new FormData()
      formData.append("cookie", cookie)

      const response = await checkRobloxCookie(formData)
      setResult(response)
    } catch (error) {
      console.error("Error checking cookie:", error)
      setError("An error occurred while checking the cookie. Please try again.")
      setResult({
        success: false,
        message: "An error occurred while checking the cookie. Please try again.",
      })
    } finally {
      setIsRefreshing(false)
    }
  }

  // Handle copy to clipboard
  const handleCopy = () => {
    if (result?.cookie) {
      navigator.clipboard
        .writeText(result.cookie)
        .then(() => {
          setCopied(true)
          setTimeout(() => setCopied(false), 2000)
        })
        .catch((err) => {
          console.error("Failed to copy: ", err)
          // Fallback to the old method if clipboard API fails
          if (resultTextareaRef.current) {
            resultTextareaRef.current.select()
            document.execCommand("copy")
            setCopied(true)
            setTimeout(() => setCopied(false), 2000)
          }
        })
    }
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-hidden py-4 sm:py-6 px-2 sm:px-4">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 to-black"></div>
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-20"></div>
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-red-500 to-transparent opacity-20"></div>
        <RedParticleCanvas />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 container mx-auto px-2 sm:px-4 flex flex-col items-center space-y-4 w-full max-w-3xl"
      >
        <div className="w-full flex justify-between items-center mb-1">
          <NextLink href="/" className="text-red-400 hover:text-red-300 transition-colors flex items-center gap-2">
            <ArrowLeft className="w-5 h-5" />
            Back to Main Page
          </NextLink>

          <div className="flex items-center">
            <Image
              src="/poepbeamz-new-logo.png"
              alt="Poepbeamz Logo"
              width={32}
              height={32}
              className="object-contain"
            />
          </div>
        </div>

        <div className="w-full">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="flex items-center justify-center gap-2 sm:gap-4 mt-1 sm:mt-0 mb-4"
          >
            <h1 className="text-xl sm:text-2xl font-bold text-center text-white red-glow">Roblox Cookie Checker</h1>
          </motion.div>
        </div>

        {/* Error message */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="w-full bg-red-900/50 border border-red-500/50 rounded-lg p-3 flex items-center gap-2"
            >
              <XCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
              <div>
                <p className="text-red-200 text-sm">{error}</p>
                <button
                  onClick={() => setError(null)}
                  className="text-red-300 text-xs underline mt-1 hover:text-red-200"
                >
                  Dismiss
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="border border-red-500/30 rounded-xl p-4 sm:p-5 w-full bg-black/40 red-glow-container backdrop-blur-sm"
        >
          <form onSubmit={handleRefresh} className="space-y-4">
            <div>
              <label htmlFor="cookie" className="block text-sm font-medium text-gray-300 mb-1">
                Enter your Roblox cookie
              </label>
              <textarea
                ref={textareaRef}
                id="cookie"
                value={cookie}
                onChange={(e) => setCookie(e.target.value)}
                placeholder="_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_..."
                className="w-full bg-black/60 border border-gray-700 rounded-lg p-2.5 focus:outline-none focus:border-red-500 transition-colors min-h-[100px] text-sm font-mono backdrop-blur-sm"
                disabled={isRefreshing}
              />
              <p className="mt-1 text-xs text-gray-400">
                Your cookie is processed securely and is never stored or shared with third parties.
              </p>
            </div>

            <div className="flex justify-center cookie-button">
              <button
                type="submit"
                disabled={isRefreshing || !cookie.trim()}
                className={`${
                  isRefreshing || !cookie.trim()
                    ? "bg-gray-700 cursor-not-allowed"
                    : "bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600"
                } text-white px-5 py-2.5 rounded-md text-base font-semibold flex items-center gap-2 transition-all duration-300 relative overflow-hidden`}
              >
                {isRefreshing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Checking...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-5 h-5" />
                    Check Cookie
                  </>
                )}
                <div className="cookie-button-effect absolute inset-0"></div>
              </button>
            </div>
          </form>

          {result && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              transition={{ duration: 0.3 }}
              className="mt-6 space-y-3"
            >
              <div
                className={`p-3 rounded-lg border ${
                  result.success
                    ? "border-green-500/50 bg-green-900/20 text-green-200"
                    : "border-red-500/50 bg-red-900/20 text-red-200"
                }`}
              >
                <p className="text-sm flex items-center gap-2">
                  {result.success ? (
                    <Check className="w-4 h-4 flex-shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  )}
                  {result.message}
                </p>
              </div>

              {/* New Cookie Section - Moved above user info */}
              {result.success && result.cookie && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-2"
                >
                  <div className="flex justify-between items-center">
                    <label className="block text-sm font-medium text-gray-300">
                      Cookie Status: <span className="text-green-400">(Valid)</span>
                    </label>
                    <button
                      onClick={handleCopy}
                      className="text-gray-400 hover:text-red-400 transition-colors p-1.5 rounded-md bg-black/40 flex items-center gap-1.5"
                      title="Copy to clipboard"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4" /> Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" /> Copy Cookie
                        </>
                      )}
                    </button>
                  </div>
                  <div
                    className="w-full bg-black/60 border border-green-500/30 rounded-lg p-2.5 focus:outline-none transition-colors text-sm font-mono backdrop-blur-sm cursor-pointer overflow-auto max-h-[120px]"
                    onClick={handleCopy}
                    title="Click to copy"
                  >
                    <textarea
                      ref={resultTextareaRef}
                      value={result.cookie || result.originalCookie}
                      readOnly
                      className="w-full bg-transparent border-none focus:outline-none resize-none"
                      onClick={(e) => e.stopPropagation()}
                    />
                  </div>
                  <p className="text-xs text-gray-400">
                    Click anywhere in the box above to copy the cookie. This cookie is valid.
                  </p>
                </motion.div>
              )}

              {/* Robux Summary Section */}
              {result.success && result.accountSummary && result.accountSummary.robuxBalance !== undefined && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="p-4 bg-black/20 rounded-lg border border-red-500/30"
                >
                  <h3 className="text-lg font-semibold mb-3 text-red-400">Robux Summary</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="bg-black/30 p-3 rounded-lg border border-green-500/20">
                      <p className="text-gray-400 text-sm">Total Balance</p>
                      <p className="text-green-500 font-bold text-xl">
                        {result.accountSummary.robuxBalance.toLocaleString()} R$
                      </p>
                    </div>

                    {result.robuxSummary?.pendingRobux !== undefined && (
                      <div className="bg-black/30 p-3 rounded-lg border border-yellow-500/20">
                        <p className="text-gray-400 text-sm">Pending Robux</p>
                        <p className="text-yellow-500 font-bold text-xl">
                          {result.robuxSummary.pendingRobux.toLocaleString()} R$
                        </p>
                      </div>
                    )}

                    {result.robuxSummary?.totalReceived !== undefined && (
                      <div className="bg-black/30 p-3 rounded-lg border border-blue-500/20">
                        <p className="text-gray-400 text-sm">Total Received</p>
                        <p className="text-blue-500 font-bold text-xl">
                          {result.robuxSummary.totalReceived.toLocaleString()} R$
                        </p>
                      </div>
                    )}

                    {result.inventoryInfo?.estimatedValue !== undefined && result.inventoryInfo.estimatedValue > 0 && (
                      <div className="bg-black/30 p-3 rounded-lg border border-purple-500/20">
                        <p className="text-gray-400 text-sm">Limiteds Value</p>
                        <p className="text-purple-500 font-bold text-xl">
                          {result.inventoryInfo.estimatedValue.toLocaleString()} R$
                        </p>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {result.success && result.accountSummary && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.1 }}
                  className="border border-gray-700 rounded-lg p-4 bg-black/60 backdrop-blur-sm"
                >
                  {/* Section Tabs */}
                  <div className="flex overflow-x-auto pb-2 gap-2 mb-4 border-b border-gray-700">
                    <button
                      onClick={() => setActiveSection("account")}
                      className={`px-3 py-1.5 text-xs font-medium rounded-t-md flex items-center gap-1.5 whitespace-nowrap ${
                        activeSection === "account"
                          ? "bg-red-500/20 text-red-300 border-t border-l border-r border-red-500/30"
                          : "bg-gray-800/50 text-gray-300 border-t border-l border-r border-gray-700 hover:bg-gray-700/30"
                      }`}
                    >
                      <User className="w-3.5 h-3.5" />
                      Account
                    </button>
                    <button
                      onClick={() => setActiveSection("security")}
                      className={`px-3 py-1.5 text-xs font-medium rounded-t-md flex items-center gap-1.5 whitespace-nowrap ${
                        activeSection === "security"
                          ? "bg-red-500/20 text-red-300 border-t border-l border-r border-red-500/30"
                          : "bg-gray-800/50 text-gray-300 border-t border-l border-r border-gray-700 hover:bg-gray-700/30"
                      }`}
                    >
                      <Shield className="w-3.5 h-3.5" />
                      Security
                    </button>
                    <button
                      onClick={() => setActiveSection("social")}
                      className={`px-3 py-1.5 text-xs font-medium rounded-t-md flex items-center gap-1.5 whitespace-nowrap ${
                        activeSection === "social"
                          ? "bg-red-500/20 text-red-300 border-t border-l border-r border-red-500/30"
                          : "bg-gray-800/50 text-gray-300 border-t border-l border-r border-gray-700 hover:bg-gray-700/30"
                      }`}
                    >
                      <Users className="w-3.5 h-3.5" />
                      Social
                    </button>
                    <button
                      onClick={() => setActiveSection("inventory")}
                      className={`px-3 py-1.5 text-xs font-medium rounded-t-md flex items-center gap-1.5 whitespace-nowrap ${
                        activeSection === "inventory"
                          ? "bg-red-500/20 text-red-300 border-t border-l border-r border-red-500/30"
                          : "bg-gray-800/50 text-gray-300 border-t border-l border-r border-gray-700 hover:bg-gray-700/30"
                      }`}
                    >
                      <Box className="w-3.5 h-3.5" />
                      Inventory
                    </button>
                    <button
                      onClick={() => setActiveSection("games")}
                      className={`px-3 py-1.5 text-xs font-medium rounded-t-md flex items-center gap-1.5 whitespace-nowrap ${
                        activeSection === "games"
                          ? "bg-red-500/20 text-red-300 border-t border-l border-r border-red-500/30"
                          : "bg-gray-800/50 text-gray-300 border-t border-l border-r border-gray-700 hover:bg-gray-700/30"
                      }`}
                    >
                      <Gamepad className="w-3.5 h-3.5" />
                      Games
                    </button>
                  </div>

                  {/* Account Section */}
                  {activeSection === "account" && (
                    <div>
                      <div className="flex flex-col sm:flex-row gap-4 items-center sm:items-start">
                        {/* Profile Picture and Avatar */}
                        <div className="flex flex-col items-center gap-2">
                          {result.accountSummary.profilePictureUrl && (
                            <div className="relative w-24 h-24 rounded-full overflow-hidden border-2 border-red-500/50">
                              <Image
                                src={result.accountSummary.profilePictureUrl || "/placeholder.svg?height=96&width=96"}
                                alt={result.accountSummary.username}
                                width={96}
                                height={96}
                                className="object-cover"
                                onError={(e) => {
                                  e.currentTarget.src = "/placeholder.svg?height=96&width=96"
                                }}
                              />
                              {result.accountSummary.isBanned && (
                                <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                                  <Ban className="w-10 h-10 text-red-500" />
                                </div>
                              )}
                              {result.accountSummary.isPremium && (
                                <div className="absolute bottom-0 right-0 bg-yellow-500 rounded-full p-1">
                                  <Crown className="w-4 h-4 text-black" />
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* User Info */}
                        <div className="flex-1 text-center sm:text-left">
                          <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
                            <h3 className="text-lg font-semibold text-white">
                              {result.accountSummary.displayName || result.accountSummary.username}
                            </h3>
                            {result.accountSummary.displayName !== result.accountSummary.username &&
                              result.accountSummary.username && (
                                <span className="text-gray-400 text-sm">@{result.accountSummary.username}</span>
                              )}
                            {result.accountSummary.isPremium && (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-yellow-400 bg-yellow-900/30 px-2 py-0.5 rounded-full">
                                <Crown className="w-3 h-3" /> Premium
                              </span>
                            )}
                            {result.accountSummary.isBanned && (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-red-400 bg-red-900/30 px-2 py-0.5 rounded-full">
                                <Ban className="w-3 h-3" /> Banned
                              </span>
                            )}
                          </div>

                          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-2 justify-center sm:justify-start">
                            <div className="flex items-center gap-1.5 text-xs text-gray-300">
                              <User className="w-3.5 h-3.5 text-gray-400" />
                              <span>ID: {result.accountSummary.userId}</span>
                            </div>

                            {result.accountSummary.created && (
                              <div className="flex items-center gap-1.5 text-xs text-gray-300">
                                <Calendar className="w-3.5 h-3.5 text-gray-400" />
                                <span>Joined: {formatDate(result.accountSummary.created)}</span>
                              </div>
                            )}

                            {result.accountSummary.accountAge !== undefined && result.accountSummary.accountAge > 0 && (
                              <div className="flex items-center gap-1.5 text-xs text-gray-300">
                                <History className="w-3.5 h-3.5 text-gray-400" />
                                <span>Account Age: {formatAccountAge(result.accountSummary.accountAge)}</span>
                              </div>
                            )}

                            {result.accountSummary.lastOnline && (
                              <div className="flex items-center gap-1.5 text-xs text-gray-300">
                                <Clock className="w-3.5 h-3.5 text-gray-400" />
                                <span>Last Online: {formatTimeAgo(result.accountSummary.lastOnline)}</span>
                              </div>
                            )}

                            {result.accountSummary.robuxBalance !== undefined && (
                              <div className="flex items-center gap-1.5 text-xs">
                                <DollarSign className="w-3.5 h-3.5 text-green-500" />
                                <span>{formatNumber(result.accountSummary.robuxBalance)} Robux</span>
                              </div>
                            )}
                          </div>

                          {result.accountSummary.description && (
                            <div className="mt-3 text-sm text-gray-300 bg-black/30 p-2 rounded border border-gray-700">
                              <p>{result.accountSummary.description || "No description"}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Security Section */}
                  {activeSection === "security" && result.securityInfo && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white">Security Information</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-1">Two-Step Verification</p>
                          <p className="text-sm font-medium flex items-center gap-1.5">
                            {result.securityInfo.twoStepEnabled ? (
                              <span className="text-green-400 flex items-center gap-1.5">
                                <Check className="w-4 h-4" /> Enabled
                              </span>
                            ) : (
                              <span className="text-red-400 flex items-center gap-1.5">
                                <AlertCircle className="w-4 h-4" /> Disabled
                              </span>
                            )}
                          </p>
                        </div>

                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-1">Email Verification</p>
                          <p className="text-sm font-medium flex items-center gap-1.5">
                            {result.securityInfo.emailVerified ? (
                              <span className="text-green-400 flex items-center gap-1.5">
                                <Mail className="w-4 h-4" /> Verified
                              </span>
                            ) : (
                              <span className="text-red-400 flex items-center gap-1.5">
                                <AlertCircle className="w-4 h-4" /> Not Verified
                              </span>
                            )}
                          </p>
                        </div>

                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-1">Phone Verification</p>
                          <p className="text-sm font-medium flex items-center gap-1.5">
                            {result.securityInfo.phoneVerified ? (
                              <span className="text-green-400 flex items-center gap-1.5">
                                <Phone className="w-4 h-4" /> Verified
                              </span>
                            ) : (
                              <span className="text-red-400 flex items-center gap-1.5">
                                <AlertCircle className="w-4 h-4" /> Not Verified
                              </span>
                            )}
                          </p>
                        </div>

                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-1">PIN Lock</p>
                          <p className="text-sm font-medium flex items-center gap-1.5">
                            {result.securityInfo.pinEnabled ? (
                              <span className="text-green-400 flex items-center gap-1.5">
                                <Lock className="w-4 h-4" /> Enabled
                              </span>
                            ) : (
                              <span className="text-red-400 flex items-center gap-1.5">
                                <AlertCircle className="w-4 h-4" /> Disabled
                              </span>
                            )}
                          </p>
                        </div>
                      </div>

                      <div className="mt-4 p-3 bg-black/30 rounded-lg border border-yellow-500/20">
                        <h4 className="text-sm font-medium text-yellow-400 mb-2 flex items-center gap-1.5">
                          <Info className="w-4 h-4" /> Security Assessment
                        </h4>
                        <div className="space-y-2">
                          <p className="text-xs text-gray-300">
                            {!result.securityInfo.twoStepEnabled && (
                              <span className="block text-red-300 mb-1">
                                • Two-step verification is not enabled, making the account vulnerable to unauthorized
                                access.
                              </span>
                            )}
                            {!result.securityInfo.emailVerified && (
                              <span className="block text-red-300 mb-1">
                                • Email is not verified, which limits account recovery options.
                              </span>
                            )}
                            {!result.securityInfo.phoneVerified && (
                              <span className="block text-red-300 mb-1">
                                • Phone is not verified, reducing account security and recovery options.
                              </span>
                            )}
                            {!result.securityInfo.pinEnabled && (
                              <span className="block text-red-300 mb-1">
                                • PIN lock is not enabled, which could allow unauthorized purchases.
                              </span>
                            )}
                            {result.securityInfo.twoStepEnabled &&
                              result.securityInfo.emailVerified &&
                              result.securityInfo.phoneVerified &&
                              result.securityInfo.pinEnabled && (
                                <span className="block text-green-300">
                                  • This account has good security measures in place.
                                </span>
                              )}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Social Section */}
                  {activeSection === "social" && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white">Social Information</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-1">Friends</p>
                          <p className="text-lg font-medium text-white flex items-center gap-1.5">
                            <Users className="w-4 h-4 text-blue-400" />
                            {formatNumber(result.accountSummary?.friendsCount || 0)}
                          </p>
                        </div>

                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-1">Followers</p>
                          <p className="text-lg font-medium text-white flex items-center gap-1.5">
                            <Heart className="w-4 h-4 text-red-400" />
                            {formatNumber(result.accountSummary?.followersCount || 0)}
                          </p>
                        </div>

                        {result.groupsInfo && (
                          <div className="p-3 bg-black/30 rounded-lg border border-gray-800 sm:col-span-2">
                            <p className="text-xs text-gray-400 mb-1">Groups</p>
                            <p className="text-lg font-medium text-white flex items-center gap-1.5">
                              <Briefcase className="w-4 h-4 text-yellow-400" />
                              {result.groupsInfo.count || 0}
                            </p>
                            {result.groupsInfo.groups && result.groupsInfo.groups.length > 0 && (
                              <div className="mt-2 max-h-32 overflow-y-auto">
                                <div className="text-xs text-gray-400 grid grid-cols-2 gap-x-2 gap-y-1">
                                  {result.groupsInfo.groups.slice(0, 6).map((group, index) => (
                                    <div key={index} className="truncate">
                                      {group.name} ({group.role})
                                    </div>
                                  ))}
                                  {result.groupsInfo.groups.length > 6 && (
                                    <div className="text-gray-500">+{result.groupsInfo.groups.length - 6} more</div>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Inventory Section */}
                  {activeSection === "inventory" && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white">Inventory Information</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {result.inventoryInfo && (
                          <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                            <p className="text-xs text-gray-400 mb-1">Collectibles</p>
                            <p className="text-lg font-medium text-white flex items-center gap-1.5">
                              <Box className="w-4 h-4 text-purple-400" />
                              {result.inventoryInfo.canView
                                ? formatNumber(result.inventoryInfo.itemCount || 0)
                                : "Private"}
                            </p>
                          </div>
                        )}

                        {result.badgesInfo && (
                          <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                            <p className="text-xs text-gray-400 mb-1">Badges</p>
                            <p className="text-lg font-medium text-white flex items-center gap-1.5">
                              <Award className="w-4 h-4 text-yellow-400" />
                              {formatNumber(result.badgesInfo.totalBadges || 0)}
                            </p>
                          </div>
                        )}

                        {result.inventoryInfo?.limitedItems && result.inventoryInfo.limitedItems.length > 0 && (
                          <div className="p-3 bg-black/30 rounded-lg border border-gray-800 sm:col-span-2">
                            <p className="text-xs text-gray-400 mb-1">Limited Items</p>
                            <div className="mt-2">
                              <div className="text-xs text-gray-300">
                                <div className="grid grid-cols-1 gap-2">
                                  {result.inventoryInfo.limitedItems.map((item, index) => (
                                    <div
                                      key={index}
                                      className="flex justify-between items-center p-2 bg-black/40 rounded border border-gray-700"
                                    >
                                      <span className="truncate">{item.name}</span>
                                      <span className="text-green-400 whitespace-nowrap">
                                        {item.recentAveragePrice.toLocaleString()} R$
                                      </span>
                                    </div>
                                  ))}
                                </div>
                                {result.inventoryInfo.estimatedValue > 0 && (
                                  <div className="mt-2 flex justify-between items-center p-2 bg-black/40 rounded border border-purple-500/30">
                                    <span className="font-medium">Total Value:</span>
                                    <span className="text-purple-400 font-medium">
                                      {result.inventoryInfo.estimatedValue.toLocaleString()} R$
                                    </span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        )}

                        {result.badgesInfo?.recentBadges && result.badgesInfo.recentBadges.length > 0 && (
                          <div className="p-3 bg-black/30 rounded-lg border border-gray-800 sm:col-span-2">
                            <p className="text-xs text-gray-400 mb-1">Recent Badges</p>
                            <div className="mt-2">
                              <div className="text-xs text-gray-300">
                                <div className="grid grid-cols-1 gap-2">
                                  {result.badgesInfo.recentBadges.map((badge, index) => (
                                    <div key={index} className="p-2 bg-black/40 rounded border border-gray-700">
                                      <div className="font-medium">{badge.name}</div>
                                      <div className="text-gray-400 text-xs mt-1">{badge.description}</div>
                                      {badge.awardedDate && (
                                        <div className="text-gray-500 text-xs mt-1">
                                          Awarded: {formatDate(badge.awardedDate)}
                                        </div>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Games Section */}
                  {activeSection === "games" && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white">Games Information</h3>

                      {/* Recently Played Games */}
                      {result.recentlyPlayedGames && result.recentlyPlayedGames.length > 0 ? (
                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-2">Recently Played Games</p>
                          <div className="space-y-2">
                            {result.recentlyPlayedGames.slice(0, 5).map((game, index) => (
                              <div key={index} className="p-2 bg-black/40 rounded border border-gray-700">
                                <div className="font-medium text-sm">{game.name}</div>
                                <div className="text-gray-400 text-xs mt-1 flex items-center gap-2">
                                  {game.placeId && (
                                    <span className="flex items-center gap-1">
                                      <Tag className="w-3 h-3" /> ID: {game.placeId}
                                    </span>
                                  )}
                                  {game.visits && (
                                    <span className="flex items-center gap-1">
                                      <Users className="w-3 h-3" /> {formatNumber(game.visits)} visits
                                    </span>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800 text-center">
                          <p className="text-sm text-gray-400">No recently played games found</p>
                        </div>
                      )}

                      {/* Favorite Games */}
                      {result.gameInfo?.favoriteGames && result.gameInfo.favoriteGames.length > 0 ? (
                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-2">Favorite Games</p>
                          <div className="space-y-2">
                            {result.gameInfo.favoriteGames.map((game, index) => (
                              <div key={index} className="p-2 bg-black/40 rounded border border-gray-700">
                                <div className="font-medium text-sm">{game.name}</div>
                                <div className="text-gray-400 text-xs mt-1 flex items-center gap-2">
                                  <span className="flex items-center gap-1">
                                    <Tag className="w-3 h-3" /> ID: {game.placeId}
                                  </span>
                                  <span className="flex items-center gap-1">
                                    <Users className="w-3 h-3" /> {formatNumber(game.visits)} visits
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800 text-center">
                          <p className="text-sm text-gray-400">No favorite games found</p>
                        </div>
                      )}

                      {/* Game Passes */}
                      {result.gamePasses && result.gamePasses.length > 0 && (
                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-2">Game Passes</p>
                          <div className="space-y-2">
                            {result.gamePasses.slice(0, 5).map((pass, index) => (
                              <div key={index} className="p-2 bg-black/40 rounded border border-gray-700">
                                <div className="font-medium text-sm">{pass.name}</div>
                              </div>
                            ))}
                            {result.gamePasses.length > 5 && (
                              <p className="text-xs text-gray-500 text-center">
                                +{result.gamePasses.length - 5} more passes
                              </p>
                            )}
                          </div>
                        </div>
                      )}

                      {/* Created Games */}
                      {result.developerInfo?.createdGames && result.developerInfo.createdGames.length > 0 && (
                        <div className="p-3 bg-black/30 rounded-lg border border-gray-800">
                          <p className="text-xs text-gray-400 mb-2">Created Games</p>
                          <div className="space-y-2">
                            {result.developerInfo.createdGames.map((game, index) => (
                              <div key={index} className="p-2 bg-black/40 rounded border border-gray-700">
                                <div className="font-medium text-sm">{game.name}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </motion.div>
              )}
            </motion.div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="border border-red-500/30 rounded-xl p-3 sm:p-4 w-full bg-black/40 red-glow-container backdrop-blur-sm"
        >
          <div className="flex items-start gap-2">
            <Info className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium text-white mb-1">What is this tool for?</h3>
              <p className="text-sm text-gray-300">
                This tool checks if your Roblox cookie still works. It validates if your cookie is still valid and
                displays comprehensive account information including security settings, premium status, and Robux
                balance.
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>

      <style jsx global>{`
        .red-glow {
          text-shadow: 0 0 10px rgba(239, 68, 68, 0.7), 0 0 20px rgba(239, 68, 68, 0.5);
        }

        .red-glow-container {
          box-shadow: 0 0 15px rgba(239, 68, 68, 0.3);
        }

        .cookie-button-effect {
          background: radial-gradient(circle at center, rgba(220, 38, 38, 0.3) 0%, transparent 70%);
          opacity: 0;
          transition: opacity 0.3s ease;
        }

        .cookie-button:hover .cookie-button-effect {
          opacity: 1;
        }
      `}</style>
    </div>
  )
}
