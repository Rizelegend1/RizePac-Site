"use client"
import Link from "next/link"
import { ExternalLink } from "lucide-react"

interface EmbeddedMessageProps {
  title: string
  description: string
  linkText: string
  linkUrl: string
  color?: string
  showFooter?: boolean
}

export default function EmbeddedMessage({
  title = "Shockify",
  description = "Shockify The Number 1 Beaming Site!",
  linkText = "Shockify ( link )",
  linkUrl = "https://shockify.lol",
  color = "#ffffff",
  showFooter = true,
}: EmbeddedMessageProps) {
  return (
    <div className="max-w-md mx-auto my-4">
      {/* Discord-like message container */}
      <div className="bg-[#36393f] rounded-md overflow-hidden shadow-lg">
        {/* Message header */}
        <div className="p-4 pb-0">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-bold">
              S
            </div>
            <div>
              <div className="font-medium text-white">Shockify Bot</div>
              <div className="text-[#b9bbbe] text-sm">
                Today at {new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </div>
            </div>
          </div>
          <div className="mt-2 text-white">{title}</div>
        </div>

        {/* Embed container */}
        <div className="px-4 py-2">
          <div className="flex">
            {/* Left border with specified color */}
            <div className="w-1 bg-white rounded-l-md mr-3"></div>

            {/* Embed content */}
            <div className="flex-1">
              <div className="text-white font-medium">{description}</div>

              <div className="mt-2 flex items-center text-[#00aff4] hover:underline">
                <Link href={linkUrl} target="_blank" className="flex items-center gap-1">
                  {linkText}
                  <ExternalLink size={14} />
                </Link>
              </div>
            </div>
          </div>
          {/* Add copyright footer if showFooter is true */}
          {showFooter && (
            <div className="mt-2 pt-2 border-t border-[#4f545c] text-[#b9bbbe] text-xs">
              © 2025 Shockify — All Rights Reserved.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
